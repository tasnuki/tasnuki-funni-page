

print('workey')

local scp_item_spawn_amount = 12
local offset = Vector(0,0, 6)


local itemlist = {
    items = {
        {class = 'item_healthkit', hitchance = 6},
        {class = 'item_healthvial', hitchance = 3}
    }
}



hook.Add('PlayerSay', 'scpitemsayhook', function(pl, text)
    if pl:IsAdmin() then
        if text == '!itemstock' then
            SpawnItems()
        end

        if text == '!itemclear' then
            ClearItems()
        end

        if string.StartsWith(text, '!itemcount') then
            local args = string.Split(text, ' ')
            scp_item_spawn_amount = tonumber(args[2])
            print(scp_item_spawn_amount)
        end
    end
end)


function SpawnItems()
    for i=0, scp_item_spawn_amount do

        local class = table.Random(itemlist.items)
        print('[spawning] class is ', class.class)
        PrintTable(class)
        local roll = math.random(0,10)

        if roll > class.hitchance then
            class = table.Random(itemlist.items)
            print('[spawning] did not pass roll, class is now ', class.class)
        end

        local nav = table.Random(navmesh.GetAllNavAreas())
        local pos = nav:GetRandomPoint()

        local ent = ents.Create(class.class)
        ent:Spawn()
        ent:SetPos(pos + Vector(0,0,offset))
        ent:SetAngles(Angle(0, math.random(-120, 120), 0))
        ent:SetName('scp_spawned_item')

        print('item spawned (', class.class,'),pos is ',pos, ' items spawned = ', i) 


    end
end

function ClearItems()
    local cleared = 0
    for _,item in ipairs(ents.FindByName('scp_spawned_item')) do
        if IsValid(item) then
            item:Remove()
            cleared = cleared + 1
        end
    end

    print('[spawning] items cleared = ', cleared)
end
