if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Greg (r1)"
ENT.Category = "greghunt"
ENT.Models = {"models/monk.mdl"}
ENT.Skins = {0}
ENT.ModelScale = 1
ENT.CollisionBounds = Vector(10, 10, 72)
ENT.BloodColor = BLOOD_COLOR_RED
ENT.RagdollOnDeath = false

-- Stats --
ENT.SpawnHealth = 5000
ENT.HealthRegen = 0
ENT.MinPhysDamage = 0
ENT.MinFallDamage = 0
--

-- Sounds --
ENT.OnSpawnSounds = {}
ENT.OnIdleSounds = {}
ENT.IdleSoundDelay = 2
ENT.ClientIdleSounds = true
ENT.OnDamageSounds = {}
ENT.DamageSoundDelay = 0.25
ENT.OnDeathSounds = {}
ENT.OnDownedSounds = {}
ENT.Footsteps = {}


--custom
ENT.SFX_Twitch = {
    'physics/body/body_medium_break2.wav',
    'physics/body/body_medium_break3.wav',
    'physics/body/body_medium_break4.wav'
}

ENT.SFX_Headshot = {
    'greghunt/npc/greg/headshot1.wav',
    'greghunt/npc/greg/headshot2.wav'
}

ENT.VO_changeenemy = {
    'vo/ravenholm/monk_death07.wav',
    'vo/ravenholm/madlaugh01.wav',
    'vo/ravenholm/madlaugh02.wav',
    'vo/ravenholm/madlaugh03.wav',
    'vo/ravenholm/madlaugh04.wav',
    'vo/ravenholm/monk_blocked03.wav',
    'vo/ravenholm/monk_coverme01.wav',
    'vo/ravenholm/monk_coverme04.wav',
    'vo/ravenholm/monk_kill11.wav'
}

ENT.VO_afterstun = {
    'vo/ravenholm/cartrap_better.wav',
    'vo/ravenholm/shotgun_hush.wav',
    'vo/ravenholm/shotgun_theycome.wav',
    'vo/ravenholm/monk_danger03.wav'
}

ENT.VO_spot = {
    'vo/ravenholm/bucket_thereyouare.wav',
    'vo/ravenholm/firetrap_lookout.wav',
    'vo/ravenholm/firetrap_vigil.wav',
    'vo/ravenholm/firetrap_welldone.wav',
    'vo/ravenholm/madlaugh01.wav',
    'vo/ravenholm/madlaugh02.wav',
    'vo/ravenholm/madlaugh03.wav',
    'vo/ravenholm/madlaugh04.wav',
    'vo/ravenholm/monk_kill08.wav',
}

ENT.VO_chasing = {
    'vo/ravenholm/madlaugh01.wav',
    'vo/ravenholm/madlaugh02.wav',
    'vo/ravenholm/madlaugh03.wav',
    'vo/ravenholm/madlaugh04.wav',
}

ENT.VO_rant = {
   'vo/ravenholm/monk_rant01.wav',
   'vo/ravenholm/monk_rant02.wav',
   'vo/ravenholm/monk_rant03.wav',
   'vo/ravenholm/monk_rant04.wav',
   'vo/ravenholm/monk_rant05.wav',
   'vo/ravenholm/monk_rant06.wav',
   'vo/ravenholm/monk_rant07.wav',
   'vo/ravenholm/monk_rant08.wav',
   'vo/ravenholm/monk_rant09.wav',
   'vo/ravenholm/monk_rant10.wav',
   'vo/ravenholm/monk_rant11.wav',
   'vo/ravenholm/monk_rant12.wav',
   'vo/ravenholm/monk_rant13.wav',
   'vo/ravenholm/monk_rant14.wav',
   'vo/ravenholm/monk_rant15.wav',
   'vo/ravenholm/monk_rant16.wav',
   'vo/ravenholm/monk_rant17.wav',
   'vo/ravenholm/monk_rant18.wav',
   'vo/ravenholm/monk_rant19.wav',
   'vo/ravenholm/monk_rant20.wav',
   'vo/ravenholm/monk_rant21.wav',
   'vo/ravenholm/monk_rant22.wav',
}

ENT.VO_goheal = {
    'vo/ravenholm/monk_coverme05.wav',
    'vo/ravenholm/monk_givehealth01.wav',
}

ENT.VO_injured = {
    'vo/ravenholm/monk_pain01.wav',
    'vo/ravenholm/monk_pain02.wav',
    'vo/ravenholm/monk_pain03.wav',
    'vo/ravenholm/monk_pain04.wav',
    'vo/ravenholm/monk_pain07.wav',
}

ENT.VO_killed = {
    'vo/ravenholm/monk_kill03.wav',
    'vo/ravenholm/monk_kill09.wav',
    'vo/ravenholm/monk_kill10.wav',
    'vo/ravenholm/monk_kill11.wav',
    'vo/ravenholm/monk_mourn01.wav',
    'vo/ravenholm/monk_mourn02.wav',
    'vo/ravenholm/monk_mourn04.wav',
    'vo/ravenholm/monk_mourn05.wav',
    'vo/ravenholm/monk_mourn07.wav',
    'vo/ravenholm/madlaugh04.wav',
    'vo/ravenholm/madlaugh03.wav',
}

ENT.GhostShit = {
    'ambient/voices/playground_memory.wav',
    'ambient/voices/squeal1.wav',
    'ambeint/alarms/warningbell1.wav',
    'ambient/creatures/town_moan1.wav',
    'ambient/creatures/town_child_scream1.wav',
    'ambient/creatures/town_scared_breathing2.wav',
    'ambient/creatures/town_scared_breathing21.wav',
    'ambient/levels/streetwar/gunship_distant2.wav',
    'ambient/levels/streetwar/gunship_distant2.wav',
    'ambient/levels/citadel/strange_talk9.wav'
}

--

-- AI --
ENT.Omniscient = false
ENT.SpotDuration = 10
ENT.RangeAttackRange = 500
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0
-- custom
ENT.Ignore_sounds = false
ENT.Omni = true
--


-- Relationships --
ENT.Factions = {"GREG"}
ENT.Frightening = true
ENT.AllyDamageTolerance = 0.33
ENT.AfraidDamageTolerance = 0.33
ENT.NeutralDamageTolerance = 0.33

-- Locomotion --
ENT.Acceleration = 1000
ENT.Deceleration = 1000
ENT.JumpHeight = 50
ENT.StepHeight = 20
ENT.MaxYawRate = 180
ENT.DeathDropHeight = 200

-- Animations --
ENT.IdleAnims = {
    'LineIdle01',
    'LineIdle02',
    'LineIdle03',
    'LineIdle04'
}

ENT.NoticeGestures = {
    "G_twoopen_midsharp",
    "G_oneopen_highpointsharp",
    "g_Fist",
    "g_Raise_Gun_Chop"
}


ENT.WalkAnimation = ACT_WALK
ENT.WalkAnimRate = 1
ENT.RunAnimation = 'run_all_panicked'
ENT.RunAnimRate = 1
ENT.IdleAnimation = 'LineIdle01'
ENT.IdleAnimRate = 1
ENT.JumpAnimation = ACT_JUMP
ENT.JumpAnimRate = 1

-- Movements --
ENT.UseWalkframes = false
ENT.WalkSpeed = 100
ENT.RunSpeed = 350

-- Climbing --
ENT.ClimbLedges = true
ENT.ClimbLedgesMaxHeight = 256
ENT.ClimbLedgesMinHeight = 32
ENT.LedgeDetectionDistance = 20
ENT.ClimbProps = false
ENT.ClimbLadders = false
ENT.ClimbLaddersUp = true
ENT.LaddersUpDistance = 20
ENT.ClimbLaddersUpMaxHeight = math.huge
ENT.ClimbLaddersUpMinHeight = 0
ENT.ClimbLaddersDown = false
ENT.LaddersDownDistance = 20
ENT.ClimbLaddersDownMaxHeight = math.huge
ENT.ClimbLaddersDownMinHeight = 0
ENT.ClimbSpeed = 60
ENT.ClimbUpAnimation = 'run_protected_all'
ENT.ClimbDownAnimation = 'run_protected_all'
ENT.ClimbAnimRate = 10
ENT.ClimbOffset = Vector(0, 0, 0)

-- Detection --
ENT.EyeBone = "ValveBiped.Bip01_Head1"
ENT.EyeOffset = Vector(0, 0, 0)
ENT.EyeAngle = Angle(0, 0, 0)
ENT.SightFOV = 110
ENT.SightRange = 9000
ENT.MinLuminosity = 0.1
ENT.MaxLuminosity = 1
ENT.HearingCoefficient = 5

-- Weapons --
ENT.UseWeapons = true
ENT.Weapons = {'weapon_crowbar', 'weapon_annabelle', 'weapon_stunstick'}
ENT.WeaponAccuracy = 1
ENT.WeaponAttachment = "Anim_Attachment_RH"
ENT.DropWeaponOnDeath = false
ENT.AcceptPlayerWeapons = false

-- Possession --
ENT.PossessionEnabled = false
ENT.PossessionPrompt = false
ENT.PossessionCrosshair = false
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {}
ENT.PossessionBinds = {}



--#################[CUSTOM VARS]#################--
ENT.HeadAngle = Angle(0,0,0)
ENT.HeadAngle_random = Angle(math.random(-80,80), math.random(-80,80), math.random(-80,80))
ENT.HeadAngle_set = false
ENT.HeadAngle_timer = 2

ENT.Patrolling = false
ENT.Chasing = false


--speaking
ENT.CurrentSpeak = 'nil'
ENT.Speaking = false
ENT.VoicePitch = math.random(90, 105)
ENT.ChaseSpeakTimer = 8
ENT.IdleSpeakTimer = math.random(15, 40)

--wander
ENT.LastEnemyPos = Vector(0,0,0)
ENT.FoundEnemy = false
ENT.Hiding = false


--combat
ENT.CanStun = true
ENT.StunCooldown = 10
ENT.MeleeDamage = 7
ENT.Combat_strat = math.random(1,2)
ENT.HasHealSpot = false
ENT.HealSpotPos = Vector(0,0,0)
ENT.GoingHealing = false
ENT.CanHeal = true
ENT.HealCooldown = 180

ENT.normalmaterial = "models/monk/monk_sheet.vmt"
ENT.invisiblematerial = "models/shadertest/shader3.vmt"



--map related
ENT.MapEventCooldown = math.random(60, 400)

--#################[SHARED REALM FUNCTIONS]#################--
function ENT:ChangeHeadAngle()
    if self.Combat_strat == 1 then
        self.HeadAngle_set = false
        self:ResetHeadAngle()
        return
    end

    if self.Hiding == true then
        self.HeadAngle_set = false
        return
    end
    local speed = math.pow(0.25, (FrameTime() * game.GetTimeScale()) / 0.05)
    self.HeadAngle_set = false
    self.HeadAngle_random = Angle(math.random(-80,80), math.random(-80,80), math.random(-80,80))
    -- self.HeadAngle = sine(0.25, self.HeadAngle, self.HeadAngle_random)
    for i=0, 200 do
        self.HeadAngle = sine(speed, self.HeadAngle, self.HeadAngle_random)
        self:SetPoseParameter('body_yaw', self.HeadAngle.yaw)
        --print(self.HeadAngle.yaw)
    end

    --print(self.HeadAngle.yaw)

    --visual stuff
    self:EmitSound(table.Random(self.SFX_Twitch), 60, math.random(90, 115), 0.8, CHAN_STATIC)
    local spos = self:GetPos()
    local trs = util.TraceLine({start=spos + Vector(0,0,64), endpos=spos + Vector(32, 0,-128), filter=self})
    util.Decal("Blood", trs.HitPos + trs.HitNormal, trs.HitPos - trs.HitNormal)
    ParticleEffectAttach('blood_impact_red_01_goop', PATTACH_POINT_FOLLOW, self, 1)

    local randomplayer = table.Random(player.GetAll())
    self:SetEyeTarget(randomplayer:GetShootPos())

  end

  function ENT:ResetHeadAngle()
    self:SetPoseParameter('body_yaw', 0)
  end


if SERVER then
--#################[]#################--

  function ENT:CustomInitialize() 
    local angry = true
    if angry then
        self:SetDefaultRelationship(D_HT)
    end
    --#################[VISUALS]#################--
    --light
    local light_ent = ents.Create('light_dynamic')
    local light_name = 'greg_light'..self:EntIndex()
    light_ent:Spawn()
    light_ent:SetName(light_name)
    for k,v in ipairs(ents.FindByName('greg_light'..self:EntIndex())) do
        if IsValid(v) then
            v:SetPos(self:GetPos() + (self:GetUp() * 64) + (self:GetForward() * 16))
            v:SetParent(self, 'forward')
            v:Fire('Brightness', '1')
            v:Fire('Color', '202 16 16')
            v:Fire('Distance', '200')
            v:Fire('style', '1')
            v:Fire('TurnOn')     
        end
    end
    self:FlashlightState('off')
    self:SelectWeapon('weapon_crowbar')

    PrintTable(self:GetAttachments())

    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_Spine'), Angle(0,26,0))
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_Head1'), Angle(0,26,0))
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_L_Thigh'), Angle(0,-26,0))
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_R_UpperArm'), Angle(90,-26,26))

    self:ManipulateBoneScale(self:LookupBone('ValveBiped.Bip01_L_UpperArm'), Vector(1.5,1.5,1.5))
    self:ManipulateBoneScale(self:LookupBone('ValveBiped.Bip01_R_UpperArm'), Vector(1.5,1.5,1.5))

    self:SetColor(Color(200,200,200,255))


    self:SetFlexScale(5.0)
    self:SetFlexWeight(42, 0.9)
    --self:SetFlexWeight(38, 3)
    self:SetFlexWeight(12, 4)
    self:SetFlexWeight(13, 4)
    self:SetFlexWeight(10, -1)
    self:SetFlexWeight(11, -1)
    for i=0, self:GetFlexNum() - 1 do
        print(i, ' - ',self:GetFlexName(i))
    end
    --#################[]#################--



    --#################[SPAWNING]#################--
    local sp_enabled = true
    if sp_enabled then
        local random_mesh = table.Random(navmesh.GetAllNavAreas())
        local mesh_pos = random_mesh:GetRandomPoint()

        if mesh_pos == nil then
            return
        end

        self:SetPos(mesh_pos)

        PrintMessage(HUD_PRINTTALK, 'GREG has joined the game.')
        EmitSound('ambient/creatures/town_zombie_call1.wav', Entity(1):GetPos(), 0, CHAN_AUTO, 1.0, -1, 0, 80, 13)
    end

    if self.HasHealSpot == false then
        self.HasHealSpot = true
        self.HealSpotPos = self:RandomPos(math.random(600,1000))
    end
    --#################[]#################--

  end
  function ENT:CustomThink() 
    --#################[LITTLE STATES]#################--
    --ignore sounds
    if self.Ignore_sounds == true then
        self.HearingCoefficient = 0.0
    else
        self.HearingCoefficient = 5.0
    end

    --know where enemies are at
    if self.Omni == true then
        self.Omniscient = true
    else
        self.Omniscient = false
    end

    --stun cooldown
    if self.CanStun == false and timer.Exists('greg_Stun') == false then
        timer.Create('greg_Stun', self.StunCooldown, 1, function() 
            if not self:IsValid() then
                return
            end
            self.CanStun = true
        end)
    end

    --chase speak cooldown
    if self.Chasing == true and timer.Exists('greg_Chase') == false then
        timer.Create('greg_Chase', self.ChaseSpeakTimer, 1, function() 
            if not self:IsValid() then
                return
            end
            self:Speak(table.Random(self.VO_chasing))
        end)
        
    end

    --heal cooldown
    if self.CanHeal == false and timer.Exists('greg_Heal') == false then
        timer.Create('greg_Heal', self.HealCooldown, 1, function() 
            if not self:IsValid() then
                return
            end
            self.CanHeal = true
        end)
    end

    if self.Chasing == false then
        timer.Remove('greg_Chase')
        self.Ignore_sounds = false

        if timer.Exists('greg_Rant') == false then
            timer.Create('greg_Rant', self.IdleSpeakTimer, 1, function() 
                if not self:IsValid() then
                    return 
                end
                if self.Hiding == true then
                    return
                end
                self:Speak(table.Random(self.VO_rant))
                self.IdleSpeakTimer = math.random(15,40)
            end)
        end
    end

    if self.Chasing == true then
        self.Ignore_sounds = true
    end


    --talking
    if self.CurrentSpeak != 'nil' then
        self:SetFlexWeight(39, math.random(-1, 0.8))
    end





    --#################[]#################--
    --print(self.Patrolling)

    --#################[VISUAL STUFF]#################--
    if self.HeadAngle_set == false then
        self.HeadAngle_set = true
        
        timer.Create('greg_HeadTimer', self.HeadAngle_timer, 1, function() 
            if not self:IsValid() then
                return
            end
            self:ChangeHeadAngle()
        end)

    end

    
    if self.Patrolling == true then
        self.HeadAngle_timer = 6
    end

    if self.Patrolling == false and self.Chasing == false then
        self.HeadAngle_timer = 2
    end

    if self.Chasing == true then
        self.HeadAngle_timer = 0.4
    end

    --#################[]#################--


    --#################[FUNCTIONS]#################--
    self:OpenDoors()
    --#################[]#################--





    --#################[COMBAT RELATED STATES]#################--
    if self.Combat_strat == 1 then
        
    end


    --get closer and teleport away (setup)
    if self.Combat_strat == 2 then
        self.RangeAttackRange = 200
    end

    --gun
    if self.Combat_strat == 1 then
        self.RangeAttackRange = 400
    end

    --just teleport away
    if self.Combat_strat == 3 then
        self:TeleportAway()
    end




     --#################[]#################--



     --#################[MAP RELATED]#################--

    if timer.Exists('greg_Map') == false then
        timer.Create('greg_Map', self.MapEventCooldown, 1, function()
            self:DoMapEvents()
            self.MapEventCooldown = math.random(60, 400)
        end)
    end



     --#################[]#################--
    
  end

  function sine(f,from,to)
    return Lerp(math.ease.InSine(f), from, to)
  end

  function ENT:Speak(line, spook) 
    if self.Speaking == true then
        return
    end
    local dsp = 1
    if spook == false or spook == nil then
        dsp = 1
    end
    if spook == true then
        dsp = 4
    end
    local voiceline = line
    self.CurrentSpeak = voiceline
    local voiceline_dur = SoundDuration(voiceline)
    self:EmitSound(voiceline, 75, self.VoicePitch, 1.0, CHAN_VOICE, 0, dsp)
    self.Speaking = true


    timer.Create('greg_Speak', voiceline_dur, 1, function() 
        if not self:IsValid() then
            return
        end
        self.Speaking = false
        self.CurrentSpeak = 'nil'
    end)
  end

  function ENT:ForceSpeak(line, spook)
    if self.Speaking == true then
        self.Speaking = false
        self:StopSound(self.CurrentSpeak)
        self.CurrentSpeak = 'nil'
        if timer.Exists('greg_Speak') == true then
            timer.Remove('greg_Speak')
        end
    end
    local dsp = 1
    if spook == false or spook == nil then
        dsp = 1
    end
    if spook == true then
        dsp = 4
    end
    local voiceline = line
    self.CurrentSpeak = voiceline
    local voiceline_dur = SoundDuration(voiceline)
    self:EmitSound(voiceline, 85, self.VoicePitch, 1.0, CHAN_VOICE, 0, dsp)
    self.Speaking = true


    timer.Create('greg_Speak', voiceline_dur, 1, function() 
        if not self:IsValid() then
            return
        end
        self.Speaking = false
        self.CurrentSpeak = 'nil'
    end)

  end

  function ENT:FlashlightState(state)
    local read = string.lower(state)
    if read == 'on' then
        for _,light in ipairs(ents.FindByName('greg_light'..self:EntIndex())) do
            if IsValid(light) then
                light:Fire('TurnOn')
            end
        end
    end

    if read == 'off' then
        for _,light in ipairs(ents.FindByName('greg_light'..self:EntIndex())) do
            if IsValid(light) then
                light:Fire('TurnOff')
            end
        end
    end
  end

  function ENT:OpenDoors()

    for _,ent in ipairs(ents.FindInCone(self:GetPos(), self:GetForward(), 127, 0.707)) do
        if ent:GetClass() == 'func_door' then
            ent:Fire('Open')
        end

        if ent:GetClass() == 'prop_door_rotating' then
            ent:Fire('Open')
        end
    end
    
  end

  function ENT:DoGesture()
    self:AddGestureSequence(self:LookupSequence(table.Random(self.NoticeGestures)), true)
  end

  function ENT:HealUp()
    local gain = math.random(500, 1000)
    self:Health(self:Health() + gain)
    self:EmitSound('items/medshot4.wav', 80, 100, 1.0, CHAN_AUTO)

    --reset
    self.GoingToHeal = false
    self.CanHeal = false
  end

  function ENT:ChangeCombatStrat()
    self.Combat_strat = math.random(1,6)
  end

  function ENT:TeleportAway()
    local random_mesh = table.Random(navmesh.GetAllNavAreas())
        local mesh_pos = random_mesh:GetRandomPoint()

        if mesh_pos == nil then
            self:ChangeCombatStrat()
            return
        end

        self:SetPos(mesh_pos)
        self:ChangeCombatStrat()
  end


  -- These hooks are called when the nextbot has an enemy (inside the coroutine)
  function ENT:OnMeleeAttack(enemy) 
    local dmg = DamageInfo()
    dmg:SetDamage(self.MeleeDamage)
    dmg:SetAttacker(self)
    dmg:SetInflictor(self)
    dmg:SetDamageType(DMG_BULLET)

    enemy:TakeDamageInfo(dmg)
    
    self:EmitSound('weapons/crowbar/crowbar_impact'..math.random(1,2)..'.wav', 75, math.random(98,105), 1.0, CHAN_WEAPON)
    enemy:EmitSound(table.Random(self.SFX_Twitch), 75, 110, 0.7, CHAN_STATIC)

    if enemy:IsPlayer() == true then
        enemy:ViewPunch(Angle(20,0,10))
        enemy:SetDSP(16)
        timer.Create('greg_muffle'..enemy:Nick(), 1, 1, function() 
            enemy:SetDSP(1)
        end)
    end

    self:PlaySequenceAndMove('swing', 2, self.FaceEnemy) 
  end

  function ENT:OnRangeAttack(enemy) 

    if self.Combat_strat == 2 then
        local which_pos = math.random(1,2)
        if which_pos == 1 then
            local navmesh_pos = navmesh.GetNearestNavArea(self:GetPos())
            local pos = navmesh_pos:GetRandomPoint()
            self:SetPos(pos)
            self:ChangeCombatStrat()
            return
        end

        if which_pos == 2 then
            local navmesh_pos = navmesh.GetNearestNavArea(enemy:GetPos())
            local pos = navmesh_pos:GetRandomPoint()
            self:SetPos(pos)
            self.Combat_strat = 1
            return
        end

    end

    if self.Combat_strat == 1 then
        self:EmitSound('items/ammo_pickup.wav', 100, 90, 1.0, CHAN_STATIC)
        self:ShootGunAttack()
    end

  end

  function ENT:ShootGunAttack()
    self:ForceSpeak('vo/ravenholm/shotgun_overhere.wav')
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_R_UpperArm'), Angle(0,0,0))
    self:ResetHeadAngle()
    self.HeadAngle_timer = 12
    self.Combat_strat = 0
    self:SelectWeapon('weapon_annabelle')
    --self:StripWeapon('weapon_crowbar')
    --self:Give('weapon_annabelle')
    self:PlaySequenceAndWait('IdleAngryToShoot', 0.6, self.FaceEnemy)
    bullet = {}
    bullet.Attacker = self
    bullet.Inflictor = self:GetWeapon()
    bullet.Damage = 20
    bullet.Force = 100
    bullet.Num = 1
    bullet.Tracer = 1
    bullet.Dir = self:GetForward()
    bullet.Src = self:GetShootPos()

    self:FireBullets(bullet)
    --self:PlaySequence('shoot_gun', 1.0, self.FaceEnemy)
    self:EmitSound('weapons/shotgun/shotgun_fire6.wav', 100, 100, 1.0, CHAN_WEAPON)
    self:ForceSpeak('vo/ravenholm/shotgun_catch.wav')
    self:PlaySequenceAndWait('ShootToIdleAngry', 1.0)
    self:EmitSound('items/ammo_pickup.wav', 75, 100, 1.0)
    self:SelectWeapon('weapon_crowbar')
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_R_UpperArm'), Angle(90,-26,26))
    self:ChangeCombatStrat()
  end


  function ENT:OnContact(ent)
    if ent:GetClass() == 'prop_physics' then
        local physprop = ent:GetPhysicsObject()
		physprop:Wake()
		physprop:SetVelocity(self:GetForward() * 800)
    end
  end


  function ENT:OnChaseEnemy(enemy) 
    self.WalkAnimation = ACT_WALK
    self:SetEyeTarget(enemy:GetShootPos())
    self.Chasing = true
    self.GoingToHeal = false
    

    if timer.Exists('greg_ChaseStrat') == false then
        timer.Create('greg_ChaseStrat', 10, 1, function() 
            if not self:IsValid() then
                return
            end
            local chance_to_trigger = 9
            local chance = math.random(0.1, 0.9) * 10
            if chance > chance_to_trigger then
                self:ChangeCombatStrat()
            end
        end)
    end
  end
  function ENT:OnAvoidEnemy(enemy) end

  -- These hooks are called while the nextbot is patrolling (inside the coroutine)
  function ENT:OnReachedPatrol(pos)
    self.Patrolling = false
    if self.Hiding == false then 
        self.IdleAnimation = table.Random(self.IdleAnims)
    else
        self.IdleAnimation = 'crouchidlehide'
    end
    self:FlashlightState('off')

    if self.GoingToHeal == true then
        self:HealUp()
    end

    if self.Hiding == false then
        self:Wait(math.random(3, 7)) 
    else
        self:Wait(math.random(10, 30))
    end
  end 
  function ENT:OnPatrolUnreachable(pos) end
  function ENT:OnPatrolling(pos) 
    --self:ResetHeadAngle()
    self.Patrolling = true
  end

  -- These hooks are called when the current enemy changes (outside the coroutine)
  function ENT:OnNewEnemy(enemy) 
    self.CombatStrat = math.random(1,2)
    self:ChangeHeadAngle()
    self.HeadAngle_timer = 0.4
    self:ForceSpeak(table.Random(self.VO_spot))

    self:FlashlightState('on')
    self:EmitSound('items/flashlight1.wav', 75, 80, 1.0, CHAN_AUTO, 0)


    self.FoundEnemy = true
    self.LastEnemyPos = enemy:GetPos()

    self:DoGesture()
    
  end
  function ENT:OnEnemyChange(oldEnemy, newEnemy)
    self.CombatStrat = math.random(1,2)
    self:ForceSpeak(table.Random(self.VO_changeenemy))
    self:DoGesture()
  end
  function ENT:OnLastEnemy(enemy) 
    self.Chasing = false
  end

  -- Those hooks are called inside the coroutine
  function ENT:OnSpawn() end
  function ENT:OnIdle()
    self:SetFlexWeight(42, math.random(0,4))
    self:IdleChoicers()
  end

  function ENT:OnOtherKilled(victim,info)
    local attacker = info:GetAttacker()
    if attacker == self then
        self:Speak(table.Random(self.VO_killed))
    end
  end

  function ENT:OnRemove()
    timer.Remove('greg_Map')
  end

  function ENT:IdleChoicers()
    self.WalkAnimation = ACT_WALK
    self.Hiding = false
    local rng_reroll_chance = math.random(1,10)
    self.Chasing = false
    if self:GetMaterial() == self.invisiblematerial then
        self:SetMaterial()
    end


    --first let's see if my health is good
    if self:Health() < 2000 then
        print('my health sucks')
        self:Speak(table.Random(self.VO_injured))
        if self.HasHealSpot == true and self.CanHeal == true then
            print('go heal pls')
            self.GoingToHeal = true
            self:AddPatrolPos(self.HealSpotPos)
            self:ForceSpeak(table.Random(self.VO_goheal))
            return
        end
    end


    local rng_choice = math.random(1,6)
    print(rng_choice)
    --just wander
    if rng_choice == 1 then
        self:AddPatrolPos(self:RandomPos(math.random(1000,4600)))
        return
    end

    --go to last seen enemy spot
    if rng_choice == 2 then
        if not self.FoundEnemy then
            self:IdleChoicers()
        end
        if self:GetPos() == self.LastEnemyPos then
            self:IdleChoicers()
            return
        end
        self:AddPatrolPos(self.LastEnemyPos)
        return
    end

    --spot random player and go
    if rng_choice == 3 then
        if rng_reroll_chance > 6 then
            self:IdleChoicers()
            return
        end

        local randomplayer = table.Random(player.GetAll())
        self:SpotEntity(randomplayer)
        return
    end

    --pick nearest spot near a player and go there
    if rng_choice == 4 then
        if rng_reroll_chance > 7 then
            self:IdleChoicers()
            return
        end
        local randomplayer = table.Random(player.GetAll())
        local navmesh_area = navmesh.GetNearestNavArea(randomplayer:GetPos())
        local navmesh_pos = navmesh_area:GetRandomPoint()

        self:AddPatrolPos(navmesh_pos)
        return
    end

    --pick nearest spot near a player and go there but silently
    if rng_choice == 5 then
        if rng_reroll_chance > 7 then
            self:IdleChoicers()
            return
        end
        local randomplayer = table.Random(player.GetAll())
        local navmesh_area = navmesh.GetNearestNavArea(randomplayer:GetPos())
        local navmesh_pos = navmesh_area:GetRandomPoint()
        self.Hiding = true
        self.WalkAnimation = 'crouchRUNALL1'
        self:SetMaterial(self.invisiblematerial)
        self:AddPatrolPos(navmesh_pos)
        return
    end

    --go hide
    if rng_choice == 6 then
        local area = table.Random(navmesh.GetAllNavAreas())
        local hidingspot = table.Random(area:GetHidingSpots(math.random(1,8)))
        print(hidingspot)
        if hidingspot == nil then
            self:IdleChoicers()
            return
        end
        self.Hiding = true
        self.WalkAnimation = 'Crouch_walk_all'
        self.IdleAnimation = 'crouchidlehide'

        self:AddPatrolPos(hidingspot)
        return
    end


  end

  function ENT:DoMapEvents()
    local event_id = math.random(1,3)

    if event_id == 1 then
        local randomplayer = table.Random(player.GetAll())
        local nav = navmesh.GetNearestNavArea(randomplayer:GetPos() + Vector(math.random(100, 500),0,0))
        if nav == nil then
            nav = navmesh.GetNearestNavArea(randomplayer:GetPos() - Vector(math.random(100, 500),0,0))
        end

        if nav == nil then
            return
        end

        local pos = nav:GetRandomPoint()
        EmitSound(table.Random(self.VO_chasing), pos, -1, CHAN_AUTO, math.random(0.2, 1.0), 75, 0, self.VoicePitch)
    end

    if event_id == 2 then
        local filter = RecipientFilter()

        local randomplayer = table.Random(player.GetAll())
        filter:AddPlayer(randomplayer)
        local nav = navmesh.GetNearestNavArea(randomplayer:GetPos() + Vector(math.random(100, 500),0,0))
        if nav == nil then
            nav = navmesh.GetNearestNavArea(randomplayer:GetPos() - Vector(math.random(100, 500),0,0))
        end

        if nav == nil then
            return
        end

        local pos = nav:GetRandomPoint()
        EmitSound(table.Random(self.GhostShit), pos, -1, CHAN_AUTO, math.random(0.1, 0.3), 75, 0, math.random(80, 105), 1, filter)
        filter:RemoveAllPlayers()
    end

    if event_id == 3 then
        local sillyman = ents.Create('npc_gh_playermimic_drg')
        sillyman:Spawn()
    end
  end

  function ENT:HandleStuck()
    self:TeleportAway()
  end


  -- Called outside the coroutine
  function ENT:OnTakeDamage(dmg, hitgroup)
    self:SpotEntity(dmg:GetAttacker())
  end
  function ENT:OnFatalDamage(dmg, hitgroup) end
  
  -- Called inside the coroutine
  function ENT:OnTookDamage(dmg, hitgroup) 
    print(dmg)
    local damage = dmg:GetDamage()
    print(damage)
    if hitgroup == HITGROUP_HEAD then
        self:AddGestureSequence(self:LookupSequence("gesture_shoot_rpg", true))
        if self:GetMaterial() == self.invisiblematerial then
            self:SetMaterial()
        end
        --ParticleEffectAttach('blood_advisor_pierce_spray_b', PATTACH_POINT_FOLLOW, self, 1)
        self:EmitSound(table.Random(self.SFX_Headshot), 90, 100, 1.0, CHAN_AUTO)
        if self.CanStun == true then
            self.CanStun = false
            self:ForceSpeak('vo/ravenholm/monk_death07.wav', false)
            self:PlaySequenceAndWait('cower', 0.6)
            self:ForceSpeak(table.Random(self.VO_afterstun))
        end
    end

  end
  function ENT:OnDeath(dmg, hitgroup) 
    self:StopSound(self.CurrentSpeak)
    local funniprop_pos = self:GetPos()
    PrintMessage(HUD_PRINTTALK, 'GREG has left the game (Disconnect by User).')
    local funniprop = ents.Create('prop_physics')
    funniprop:SetModel('models/props_c17/FurnitureToilet001a.mdl')
    funniprop:Spawn()
    funniprop:SetPos(funniprop_pos + funniprop:GetUp()*64)


    for _,mimics in ipairs(ents.FindByClass('npc_gh_playermimic_drg')) do
        if IsValid(mimics) then
            mimics:Remove()
        end
    end
  end
  function ENT:OnDowned(dmg, hitgroup) end

else

  function ENT:CustomInitialize() end
  function ENT:CustomThink() end
  function ENT:CustomDraw() end

end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)