if not DrGBase then return end -- return if DrGBase isn't installed

ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- ai --
ENT.state = 0
ENT.state_timer = 0
ENT.state_timer_max = 500
ENT.can_attack = true 

--ENT.health = 600
--ENT.lastdamage = 0


ENT.normalmaterial = "models/monk/monk_sheet.vmt"
ENT.invisiblematerial = "models/shadertest/shader3.vmt"

ENT.invistimer = 0
ENT.invistimer_max = 200
ENT.state_invisible = false

ENT.feartimer = 0
ENT.feartimer_max = 200
ENT.state_afraid = false
ENT.fear_on_cooldown = false
ENT.featimer_cooldown_max = ENT.feartimer_max*2

ENT.healspot1_pos = 0,0,0
ENT.has_heal_spot1 = false
ENT.healspot2_pos = 0,0,0
ENT.has_heal_spot2 = false 
ENT.has_all_heal_spots = false
ENT.state_goingtoheal = false

ENT.has_favspot_1 = false
ENT.has_favspot_2 = false
ENT.has_favspot_3 = false 
ENT.has_favspot_4 = false 
ENT.favspot1_pos = 0,0,0
ENT.favspot2_pos = 0,0,0
ENT.favspot3_pos = 0,0,0
ENT.favspot4_pos = 0,0,0
ENT.favspotamount = 0
ENT.favspot_1_visited = 0
ENT.favspot_2_visited = 0
ENT.favspot_3_visited = 0 
ENT.favspot_4_visited = 0
ENT.favspots_visits_max = 69

ENT.state_stalking = false
ENT.stalkingtimer = 0
ENT.stalkingtimer_max = 6969
ENT.stalking_is_on_cooldown = false 
ENT.stalkingtimer_cooldown = 6969
ENT.stalkingtimer_hit_max = 6969
ENT.stalkingtimer_hit = 0
ENT.state_stalking_gonnahit = false
ENT.state_stalking_will_evade = 0


ENT.combat_approach_id = 0 
ENT.combat_chasetimer = 0
ENT.combat_chasetimer_goal = 69420
ENT.combat_chase_teleports = 0
ENT.combat_chase_teleports_goal = 2

ENT.combat_hitandrun_hits_goal = 0
ENT.combat_hitandrun_hits = 0
ENT.state_combat_hitandrun = false
ENT.combat_hitandrun_gonnarunawaylikeabitch = false
ENT.combat_hitandrun_run_before_tptmr = 420
ENT.combat_target = ""
ENT.combat_escape_times = 0
ENT.combat_escape_times_goal = 2





ENT.map_is_on_krot = false
ENT.krot_current_floor = 0
ENT.state_krot_taking_elevator = false 
--elevators floor 1
/*
ENT.map_unique_spot1 = -11770.651367, -6048.771484, 4160.216797
ENT.map_unique_spot2 = -12619.213867, -5790.219238, 4159.408691
--elevators floor 2
ENT.map_unique_spot3 = 1284.752075, -3741.041016, 1662.590332
ENT.map_unique_spot4 = 451.175049, -3483.547119, 1663.186890
ENT.map_unique_spot5 = 2639.871338, -4192.049316, 1661.501831
--elevators floor 3
ENT.map_unique_spot6 = 3036.983154, -511.664337, 62.654045
ENT.map_unique_spot7 = 1935.166626, 227.664841, 261.970367
*/

ENT.map_is_on_sr = false
ENT.sr_asteroid_id = 0

ENT.shadows_spawned = 0



ENT.ReachedGoalAnimations = {
    "Startle_behind",
    "Sit_Ground_to_idle",
    "LineIdle01",
    "LineIdle02",
    "LineIlde03",
    "LineIlde04"
}

ENT.WalkingAnimations = {
    "pace_all",
    ACT_WALK

}


-- Misc --
ENT.PrintName = "GREG (oldj)"
ENT.Category = "greghunt"
ENT.Models = {"models/monk.mdl"}
ENT.Skins = {0}
ENT.ModelScale = 1.0
ENT.CollisionBounds = Vector(10, 10, 72)
ENT.BloodColor = BLOOD_COLOR_RED
ENT.RagdollOnDeath = true

-- Stats --
ENT.SpawnHealth = 14069
ENT.HealthRegen = 0
ENT.MinPhysDamage = 10
ENT.MinFallDamage = 10

-- Sounds --
ENT.OnSpawnSounds = {}
ENT.OnIdleSounds = {
    "vo/ravenholm/monk_rant01.wav",
    "vo/ravenholm/monk_rant02.wav",
    "vo/ravenholm/monk_rant03.wav",
    "vo/ravenholm/monk_rant04.wav",
    "vo/ravenholm/monk_rant05.wav",
    "vo/ravenholm/monk_rant06.wav",
    "vo/ravenholm/monk_rant07.wav",
    "vo/ravenholm/monk_rant08.wav",
    "vo/ravenholm/monk_rant09.wav",
    "vo/ravenholm/monk_rant10.wav",
    "vo/ravenholm/monk_rant11.wav",
    "vo/ravenholm/monk_rant12.wav",
    "vo/ravenholm/monk_rant13.wav",
    "vo/ravenholm/monk_rant14.wav",
    "vo/ravenholm/monk_rant15.wav",
    "vo/ravenholm/monk_rant16.wav",
    "vo/ravenholm/monk_rant17.wav",
    "vo/ravenholm/monk_rant18.wav",
    "vo/ravenholm/monk_rant19.wav",
    "vo/ravenholm/monk_rant20.wav",
    "vo/ravenholm/monk_rant21.wav",
    "vo/ravenholm/monk_rant22.wav",
    "vo/ravenholm/monk_death07.wav"
}
ENT.IdleSoundDelay = 100, 400
ENT.ClientIdleSounds = false
ENT.OnDamageSounds = {
    "vo/ravenholm/monk_pain01.wav",
    "vo/ravenholm/monk_pain01.wav",
    "vo/ravenholm/monk_pain03.wav",
    "vo/ravenholm/monk_pain04.wav",
    "vo/ravenholm/monk_pain05.wav",
    "vo/ravenholm/monk_pain06.wav",
    "vo/ravenholm/monk_pain07.wav",
    "vo/ravenholm/monk_pain08.wav",
    "vo/ravenholm/monk_pain09.wav",
    "vo/ravenholm/monk_pain10.wav",
    "vo/ravenholm/monk_pain11.wav",
    "vo/ravenholm/monk_pain12.wav"
}
ENT.DamageSoundDelay = 0.25
ENT.OnDeathSounds = {}
ENT.OnDownedSounds = {}
ENT.Footsteps = {}

-- AI --
ENT.Omniscient = false
ENT.SpotDuration = 10
ENT.RangeAttackRange = 0
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 5000

-- Relationships --
ENT.Factions = {"GREG"}
ENT.Frightening = false
ENT.AllyDamageTolerance = 0.33
ENT.AfraidDamageTolerance = 0.33
ENT.NeutralDamageTolerance = 0.33

-- Locomotion --
ENT.Acceleration = 1000
ENT.Deceleration = 0
ENT.JumpHeight = 50
ENT.StepHeight = 20
ENT.MaxYawRate = 250
ENT.DeathDropHeight = 200

-- Animations --
ENT.WalkAnimation = "walk_all_moderate"
ENT.WalkAnimRate = 1.0
ENT.RunAnimation = ACT_RUN
ENT.RunAnimRate = 1.2
ENT.IdleAnimation = "LineIdle01"
ENT.IdleAnimRate = 1
ENT.JumpAnimation = ACT_JUMP
ENT.JumpAnimRate = 1

-- Movements --
ENT.UseWalkframes = false
ENT.WalkSpeed = 100
ENT.RunSpeed = 390

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbLedgesMaxHeight = math.huge
ENT.ClimbLedgesMinHeight = 0
ENT.LedgeDetectionDistance = 20
ENT.ClimbProps = false
ENT.ClimbLadders = true
ENT.ClimbLaddersUp = true
ENT.LaddersUpDistance = 20
ENT.ClimbLaddersUpMaxHeight = math.huge
ENT.ClimbLaddersUpMinHeight = 0
ENT.ClimbLaddersDown = true
ENT.LaddersDownDistance = 20
ENT.ClimbLaddersDownMaxHeight = math.huge
ENT.ClimbLaddersDownMinHeight = 0
ENT.ClimbSpeed = 60
ENT.ClimbUpAnimation = ACT_JUMP
ENT.ClimbDownAnimation = ACT_JUMP
ENT.ClimbAnimRate = 1
ENT.ClimbOffset = Vector(0, 0, 0)

-- Detection --
ENT.EyeBone = "ValveBiped.Bip01_Head1"
ENT.EyeOffset = Vector(0, 0, 0)
ENT.EyeAngle = Angle(0, 0, 0)
ENT.SightFOV = 150
ENT.SightRange = 9000
ENT.MinLuminosity = 0
ENT.MaxLuminosity = 1
ENT.HearingCoefficient = 1

-- Weapons --
ENT.UseWeapons = false
ENT.Weapons = {}
ENT.WeaponAccuracy = 1
ENT.WeaponAttachment = "Anim_Attachment_RH"
ENT.DropWeaponOnDeath = false
ENT.AcceptPlayerWeapons = true

-- Possession --
ENT.PossessionEnabled = false
ENT.PossessionPrompt = true
ENT.PossessionCrosshair = false
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {}
ENT.PossessionBinds = {}

if SERVER then

  function ENT:CustomInitialize() 
    util.PrecacheSound("greghunt/npc/greg/anim_swing.wav")
    util.PrecacheSound("greghunt/npc/greg/anim_hit1.wav")
    util.PrecacheSound("greghunt/npc/greg/animtv_hitconnect_crunch1.wav")
  end
  function ENT:CustomThink() 

    ----print(self:GetPos())

    self:OpenDoor()
    --self.health = self:Health()
    self.featimer_cooldown_max = self.feartimer_max*6 + 4000
    self.stalkingtimer_cooldown = self.stalkingtimer_max*2+math.random(1000, 3000)


    if self.favspot_1_visited > self.favspots_visits_max then self.has_favspot_1 = false self.favspot_1_visited = 0 end
    if self.favspot_2_visited > self.favspots_visits_max then self.has_favspot_2 = false self.favspot_2_visited = 0 end
    if self.favspot_3_visited > self.favspots_visits_max then self.has_favspot_3 = false self.favspot_3_visited = 0 end
    if self.favspot_4_visited > self.favspots_visits_max then self.has_favspot_4 = false self.favspot_4_visited = 0 end

    ----print(self.featimer_cooldown_max)
    if self.state_invisible == true then --invis timer
        self.invistimer = self.invistimer + 1
        self:RemoveAllDecals()
        if self.invistimer >= self.invistimer_max then
            self.invistimer = 0
            self:GoVisible()
            self.state_invisible = false
        end
    end


    if self.state_afraid == true and self.fear_on_cooldown == false then --afraid timer
        self.feartimer = self.feartimer + 1
        if self.feartimer >= self.feartimer_max then
            self.feartimer = 0
            self:MakeAngry()
            self.state = 0
            self.fear_on_cooldown = true
        end
    end
    if self.fear_on_cooldown == true then 
        self.feartimer = self.feartimer + 1
        ----print('TMR - fear cooldown = ', self.feartimer, ' goal is ', self.featimer_cooldown_max)
        if self.feartimer >= self.feartimer_max then
            self.feartimer = 0
            self.fear_on_cooldown = false

            --print('monster - fear cooldowned')
        end
    end


    if self.state_stalking == true then
        self.MeleeAttackRange = 2048
        self.can_attack = false
        self:SetMaterial("models/shadertest/shader3.vmt")
        self:DrawShadow(false)


        self.stalkingtimer = self.stalkingtimer + 1
        if self.stalkingtimer > self.stalkingtimer_max then
            self.stalking_is_on_cooldown = true 
            self.stalkingtimer = 0
            self.state_stalking = false 
            self.can_attack = true
            self:GoVisible()
            --print('monster stopped stalking')
        end
    end

    if self.state_stalking == false and self.stalking_is_on_cooldown == true then
        self.stalkingtimer = self.stalkingtimer + 1
        if self.stalkingtimer > self.stalkingtimer_cooldown then 
            self.stalking_is_on_cooldown = false
            --print('monster can stalk again if he wishes')
        end

        if self.state_stalking_gonnahit == true then 
            self.stalkingtimer_hit = self.stalkingtimer_hit + 1
            if self.stalkingtimer_hit > self.stalkingtimer_hit_max then 
                self.state_stalking = false
                self.stalking_is_on_cooldown = true
                self:GoVisible()
                self.state_stalking_will_evade = math.random(1,2)
                self.can_attack = true 
            end
        end
    end



    if self.state_stalking == false then self.MeleeAttackRange = 40 self.ReachEnemyRange = 20 end

    if self.state_combat_hitandrun == true then 
        if self.combat_hitandrun_hits >= self.combat_hitandrun_hits_goal then 
            self.state_combat_hitandrun = false
            if self.combat_hitandrun_gonnarunawaylikeabitch == true then 
                self.state_combat_hitandrun_run = true
            end
        end
    end

    if self.state_combat_hitandrun_run == true then 
        self:Retreat()
        self.state_afraid = true 
        self:GoInvisible()
        self.combat_hitandrun_run_before_tptmr = self.combat_hitandrun_run_before_tptmr + 1
        if self.combat_hitandrun_run_before_tptmr > 300 then 
            self.combat_hitandrun_gonnarunawaylikeabitch = false 
            self.state_combat_hitandrun_run = false
            self.combat_hitandrun_run_before_tptmr = 0
            self:Combat_reposition()
            self.fear_on_cooldown = true 
            self.state_afraid = false 
            self:MakeAngry()
            self:ChangeUpCombatApproach()
        end
    end

    
  end

  function ENT:GoInvisible()
    self.state_invisible = true 
    self.invistimer_max = math.random(200, 500)
    --print('monster - went invisible, timer = ', self.invistimer_max)
    self:SetMaterial("models/shadertest/shader3.vmt")
    self:DrawShadow(false)
    self:RemoveAllDecals()
  end

  function ENT:GoVisible()
    --print('monster - now visible')
    if self.state_stalking == false then self:SetMaterial("models/humans/corpse1_player.vmt") end
    self:DrawShadow(true)
  end




  function ENT:Fataldamach()
    if self:Health() < 1000 then
        if self.combat_escape_times < self.combat_escape_times_goal then 
            self.combat_escape_times = self.combat_escape_times + 1
            if self.map_is_on_sr == true then
                self:SR_Asteroid_swap()
            else
                self:TeleportToFavSpot()
            end
        end
    end
  end

  function ENT:Retreat()
    if self.state_afraid == false and self.fear_on_cooldown == false then
        --print('monster - afraid of players, timer = ', self.feartimer_max)
        self.state_afraid = true
        self.can_attack = false 
        --self.fear_on_cooldown = true 
        self.feartimer_max = math.random(800, 2500)
        self:SetDefaultRelationship(D_FR)
        --self:AddPatrolPos(self:RandomPos(math.random(300,4500)))


    end
  end

  function ENT:MakeAngry()
    --print('monster - hate players')
    self:SetDefaultRelationship(D_HT)
    self.state_afraid = false
    self.SightRange = 9000
    self.SightFOV = 150
    self:ChangeUpCombatApproach()
  end

  function ENT:ChangeUpCombatApproach()
    local max = 5
    self.combat_approach_id = math.random(1,max)
  end

  function ENT:GoHeal()
    local whichspot = math.random(1,2)
    --print('monster - gotta go heal, spot ', whichspot, ' selected')
    if whichspot == 1 and self.has_heal_spot1 == true then
        self:AddPatrolPos(self.healspot1_pos)
        self.state_goingtoheal = true 
        --print('monster - heal spot 1 found')
    end

    if whichspot == 2 and self.has_heal_spot2 == true then
        self:AddPatrolPos(self.healspot2_pos)
        self.state_goingtoheal = true
        --print('monster - heal spot 2 found')
    end
  end

  function ENT:ShouldIHeal()
    if self.state_goingtoheal == true then
        local healthgain = math.random(20, 1200)
        self.state_goingtoheal = false 
        self:SetHealth(self:Health()+healthgain)
        --print('gained ', healthgain, ' from heal')
    end
  end

  function ENT:VisitFavSpot()
    local which_fav_spot_we_visit = math.random(1,4)
    --print('monster wants to visit fav spot ', which_fav_spot_we_visit)

    if which_fav_spot_we_visit == 1 and self.has_favspot_1 == true then
        self:AddPatrolPos(self.favspot1_pos)
        self.favspot_1_visited = self.favspot_1_visited + 1
        --print('fav spot 1 found')
    end

    if which_fav_spot_we_visit == 2 and self.has_favspot_2 == true then
        self:AddPatrolPos(self.favspot2_pos)
        self.favspot_2_visited = self.favspot_2_visited + 1
        --print('fav spot 2 found')
    end

    if which_fav_spot_we_visit == 3 and self.has_favspot_3 == true then
        self:AddPatrolPos(self.favspot3_pos)
        self.favspot_3_visited = self.favspot_3_visited + 1
        --print('fav spot 3 found')
    end

    if which_fav_spot_we_visit == 4 and self.has_favspot_4 == true then
        self:AddPatrolPos(self.favspot4_pos)
        self.favspot_4_visited = self.favspot_4_visited + 1
        --print('fav spot 4 found')
    end

  end

  function ENT:Stalk()
    if self.stalking_is_on_cooldown == false and self.state_stalking == false then
        --print('monster is now stalking')
        self.state_stalking = true 
        self.stalkingtimer_max = math.random(3000, 9000)
        self.MeleeAttackRange = 2048
        self.ReachEnemyRange = 2048
        self.can_attack = false 
    end
  end

  --//=================COMBAT FUNCTIONS=================\\--

  function ENT:Combat_Stalk_n_hit()
    self.stalkingtimer = 0
    self.stalkingtimer_max = math.random(2000,4000)
    self.stalking_is_on_cooldown = false 
    self.state_stalking = true
    self.state_stalking_gonnahit = true
    self.stalkingtimer_hit_max = math.random(450, 1240)

  end

  function ENT:Combat_Hit_n_run()
    self.can_attack = true 
    self.combat_hitandrun_hits = 0
    self.combat_hitandrun_hits_goal = math.random(1,3)
    self.state_combat_hitandrun = true 
    if self.combat_hitandrun_gonnarunawaylikeabitch == true then 
        self.combat_hitandrun_hits_goal = 1 
    end
  end

  function ENT:Combat_reposition()
    local repos = self:RandomPos(math.random(500, 4000))
    self.can_attack = true
    self:SetPos(repos)
    self:ChangeUpCombatApproach()
  end

  function ENT:Combat_spawn_clone()
    self.can_attack = true
    self:SpawnShadowClone(1)
    self:ChangeUpCombatApproach()
  end

  --//==================================\\--

  function ENT:TeleportToFavSpot()
    local spot = math.random(1,4)
    if spot == 1 then
        self:SetPos(self.favspot1_pos)
        self.favspot_1_visited = self.favspot_1_visited + 1
    end

    if spot == 2 then 
        self:SetPos(self.favspot2_pos)
        self.favspot_2_visited = self.favspot_2_visited + 1
    end

    if spot == 3 then 
        self:SetPos(self.favspot3_pos)
        self.favspot_3_visited = self.favspot_3_visited + 1
    end

    if spot == 4 then 
        self:SetPos(self.favspot4_pos)
        self.favspot_4_visited = self.favspot_4_visited + 1
    end
  end

  --//=================DICE ROLLS=================\\--

  function ENT:DiceRoll_visitfavspot()
    local dice = math.random(0,10)
    local dice_goal = 4
    --print('monster rolled dice to visit fav spot:', dice)

    if dice > dice_goal then 
        self:VisitFavSpot()
        dice = 0
        --print('monster visiting fav spot called')
    else
        --print('meh gonna explore')
        self:AddPatrolPos(self:RandomPos(math.random(300,7500)))
    end
  end

  function ENT:Diceroll_healspot()
    local dice = math.random(0,10)
    local dice_goal = 6
    --print('monster rolled heal spot dice:', dice, " , needed to be more than ", dice_goal)

    if dice > dice_goal then 
        --print('roll success!')
        if self.has_heal_spot1 == false then
            self:Mark_healspot1()
        else
            if self.has_heal_spot2 == false then 
                self:Mark_healspot2()
            end
            --print('monster - marked nothing')
        end
    end
  end

  function ENT:Diceroll_spawnclones()
    local dice = math.random(0,10)
    local dice_goal = math.random(6,7)

    --print("greg rolls for shadow clones: ", dice, " goal is ", dice_goal)

    if dice >= dice_goal then
        --print('shadow clone success!')
        self:SpawnShadowClone(2)
    end
  end

  --//=================BASIC FUNCTIONS=================\\--

  function ENT:Mark_healspot1()
    self.has_heal_spot1 = true 
    self.healspot1_pos = self:GetPos()
    --print('monster - marked heal spot 1')
  end

  function ENT:Mark_healspot2()
    self.has_heal_spot2 = true 
    self.healspot2_pos = self:GetPos()
    self.has_all_heal_spots = true 
    --print('monster - marked heal spot 2')
  end

  function ENT:Diceroll_favspot()
    local dice = math.random(0,10)
    local dice_goal = 4
    --print('monster rolled ', dice, ' on fav spot, goal is ', dice_goal)

    if dice > dice_goal then 
        --print('roll success!')
        dice = 0
        if self.has_favspot_1 == false then self:Mark_favspot1()
        else
            if self.has_favspot_2 == false then self:Mark_favspot2()
            else
                if self.has_favspot_3 == false then self:Mark_favspot3()
                else
                    if self.has_favspot_4 == false then self:Mark_favspot4() end
                end
            end
        end
    end 
  end

  function ENT:Mark_favspot1()
    self.favspot1_pos = self:GetPos()
    self.favspotamount = self.favspotamount + 1
    self.has_favspot_1 = true
    --print('monster marked fav spot 1')
    self.favspots_visits_max = math.random(1, 3)
  end

  function ENT:Mark_favspot2()
    self.favspot2_pos = self:GetPos()
    self.favspotamount = self.favspotamount + 1
    self.has_favspot_2 = true
    --print('monster marked fav spot 2')
    self.favspots_visits_max = math.random(1, 3)
  end

  function ENT:Mark_favspot3()
    self.favspot3_pos = self:GetPos()
    self.favspotamount = self.favspotamount + 1
    self.has_favspot_3 = true
    --print('monster marked fav spot 3')
    self.favspots_visits_max = math.random(1, 3)
  end

  function ENT:Mark_favspot4()
    self.favspot4_pos = self:GetPos()
    self.favspotamount = self.favspotamount + 1
    self.has_favspot_4 = true
    --print('monster marked fav spot 4')
    self.favspots_visits_max = math.random(1, 3)
  end

  function ENT:ClearFavSpots()
    self.favspotamount = 0
    self.has_fav_spot1 = false
    self.has_fav_spot2 = false
    self.has_fav_spot3 = false
    self.has_fav_spot4 = false 
  end

  function ENT:ClearHealSpots()
    self.has_all_heal_spots = false 
    self.has_heal_spot1 = false
    self.has_heal_spot2 = false 
  end

  function ENT:SpawnShadowClone(spawntype)
    local clone = ents.Create("npc_gh_shadowgreg_drg")
    local clone_pos = self:GetPos()
    clone:Spawn()

    if spawntype == 1 then 
        clone_pos = self:GetPos()
        clone:SetPos(clone_pos)
    end

    if spawntype == 2 then
        clone_pos = self:RandomPos(math.random(100, 1000))
        clone:SetPos(clone_pos) 
    end
    
  end


  function ENT:TakeAElevator()
    local a = math.random(1,4)
    --print('greg teleported to spot ', a)
    self:GoInvisible()

    if a == 1 then self:SetPos(self.map_unique_spawnspot1) end
    if a == 2 then self:SetPos(self.map_unique_spawnspot2) end
    if a == 3 then self:SetPos(self.map_unique_spawnspot3) end
    if a == 4 then self:SetPos(self.map_unique_spawnspot4) end 
    /*
    self.state_krot_taking_elevator = true 
    if self.krot_current_floor == 0 then
        if a == 1 then self:AddPatrolPos(map_unique_spot1) end
        if a == 2 then self:AddPatrolPos(map_unique_spot2) end 
    end

    if self.krot_current_floor == 2 then
        if a == 1 then self:AddPatrolPos(map_unique_spot3) end
        if a == 2 then self:AddPatrolPos(map_unique_spot4) end 
    end

    if self.krot_current_floor == 3 then
        if a == 1 then self:AddPatrolPos(map_unique_spot6) end
        if a == 2 then self:AddPatrolPos(map_unique_spot7) end
    end
    */
  end

  function ENT:Diceroll_stalk()
    local dice = math.random(0,10)
    local dice_goal = 3
    --print('monster rolled for stalk: ', dice, " , goal is ", dice_goal)
    if dice > dice_goal then
        self:Stalk()
    end
  end

  function ENT:Diceroll_specialstates()
    local dice = math.random(0,10)
    local dice_goal = 2
    local specialstate_id = math.random(1,2)
    if dice >= dice_goal then 

        if specialstate_id == 1 then self:Diceroll_stalk() end
        if specialstate_id == 2 then self:DiceRoll_visitfavspot() end
    end
  end

  function ENT:Diceroll_elevators()
    if self.map_is_on_krot == true then 
        local a = math.random(0,10)
        local b = 6

        if a > b then 
            --print('greg elevator roll success')
            self:TakeAElevator()
        end
    end
  end

  function ENT:InitialFavSpots()
    self.favspot1_pos = self:GetPos(self:RandomPos(1000))
    self.favspot2_pos = self:GetPos(self:RandomPos(2500))
    self.favspot3_pos = self:GetPos(self:RandomPos(5000))
    self.favspot4_pos = self:GetPos(self:RandomPos(8000))
  end

  function ENT:OpenDoor() 
    for k,v in ipairs(ents.FindInCone(self:GetPos(), self:GetForward(), self.RangeAttackRange +50, math.cos( math.rad( 90 ) ))) do
		if IsValid(v) && IsValid(self) then
			if v:GetClass() == "prop_door_rotating" or v:GetClass() == "func_door" then
				v:Fire("Open")
				end
			end
		end
  end

  --//==================================\\--

  -- These hooks are called when the nextbot has an enemy (inside the coroutine)
  function ENT:OnMeleeAttack(enemy) 
    if self.state_stalking == true then 
        self:PlaySequenceAndMove("crouchidle_panicked4", 5, self.FaceEnemy)
    end

    if self.state_stalking_will_evade == 1 and self.state_stalking == false then
        self.state_stalking_will_evade = 0
        self:TeleportToFavSpot()
    end

    if self.can_attack == true then 
        self.combat_chasetimer = 0
        self:PlaySequenceAndMove("swing", 2)
        self:EmitSound("greghunt/npc/greg/anim_swing.wav", 80,math.random(93,109), 1.0)
        if self.state_combat_hitandrun == true then
            self.combat_hitandrun_hits = self.combat_hitandrun_hits + 1
        else
            if self.state_stalking == false then self:ChangeUpCombatApproach() end
        end
        self:Attack({
            damage = math.random(10,25),
            viewpunch = Angle(15, -15, 0),
            type = DMG_BULLET,range=128,angle=360,
        }, function(self, hit)
            self:EmitSound("greghunt/npc/greg/anim_hit1.wav", 80, math.random(93, 110), 1.0)
            self:EmitSound("greghunt/npc/greg/animtv_hitconnect_crunch1.wav", 80, math.random(94, 106), 0.9)
            if #hit == 0 then return end 
            if self:IsPossessed() then
                if IsValid(self) and IsValid(self:GetClosestEnemy()) then
                    if self:GetClosestEnemy().IsDrGNextbot then
                        self:GetClosestEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
                    else
                        self:GetClosestEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
                    end
                end
            else
                if IsValid(self) and IsValid(self:GetEnemy()) then
                    if self:GetEnemy().IsDrGNextbot then
                        self:GetEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
                    else
                        self:GetEnemy():SetVelocity( self:GetForward() * 120 +self:GetUp() * 50)
                    end
                end
            end
        end)
    end

  end
  function ENT:OnRangeAttack(enemy) end
  function ENT:OnChaseEnemy(enemy)
    self.state_goingtoheal = false  
    if self.state_stalking == false then 
        self.combat_chasetimer = self.combat_chasetimer + 1
        --print(self.combat_chasetimer)
        if self.combat_chasetimer >= self.combat_chasetimer_goal then 
            self.combat_chase_teleports = self.combat_chase_teleports + 1
            self:Combat_reposition()
            self.combat_chasetimer = 0
            self.combat_chasetimer_goal = math.random(100, 600)
        end

        if self.combat_chase_teleports >= self.combat_chase_teleports_goal then
            self.combat_chase_teleports = 0
            self.combat_chase_teleports_goal = math.random(1,10)
            if self.map_is_on_sr == true then
                self:SR_Asteroid_swap()
            end
        end

    end
  end
  function ENT:OnAvoidEnemy(enemy) 

  end

  function ENT:OnRemove()
    PrintMessage(HUD_PRINTTALK, 'Greg has left the game(Kicked from server)')
  end

  -- These hooks are called while the nextbot is patrolling (inside the coroutine)
  function ENT:OnReachedPatrol(pos)
    if self.has_all_heal_spots == false then 
        self:Diceroll_healspot()
    end

    if self.favspotamount < 4 then 
      self:Diceroll_favspot()
    else
        self:Diceroll_elevators()
        self:Diceroll_spawnclones()
        if self.map_is_on_sr == true then 
            self:SR_roll_Asteroid_swap()
        end
    end

    if self.state_krot_taking_elevator == true then 
        for k,v in ipairs(ents.FindInCone(self:GetPos(), self:GetForward(), self.RangeAttackRange +50, math.cos( math.rad( 90 ) ))) do
            if IsValid(v) && IsValid(self) then
                if v:GetClass() == "func_button" then
                    v:Fire("Use")
                    self.state_krot_taking_elevator = false 
                    end
                end
            end
    end

    self:ShouldIHeal() 

    self:GoVisible()

    self:PlaySequenceAndMove( table.Random(self.ReachedGoalAnimations),math.random(0.4,1))

    self:Wait(math.random(1, 3))
  end 
  function ENT:OnPatrolUnreachable(pos) end
  function ENT:OnPatrolling(pos) end

  -- These hooks are called when the current enemy changes (outside the coroutine)
  function ENT:OnNewEnemy(enemy)
    self.SpotDuration = math.random(10, 30)
    self:EmitSound( table.Random(self.OnIdleSounds),70,math.random(100,100))
    self:ChangeUpCombatApproach()
    self.combat_chasetimer = 0
    self.combat_chasetimer_goal = math.random(200, 800)
    self.combat_chase_teleports_goal = math.random(1, 10)
    if self.state_stalking == false then 
        self.can_attack = true 
    end
    --print(self.combat_chasetimer_goal)

    if self.combat_approach_id == 1 then
        self:Combat_Stalk_n_hit()
        --print('monster - gonna stalk for a bit and then try to go for hits')
    end

    if self.combat_approach_id == 2 then
        self:Combat_Hit_n_run()
        --print('monster - gonna hit a bit and then tp away')
    end

    if self.combat_approach_id == 3 then 
        self:Combat_Hit_n_run()
        self:GoInvisible()
        --print('monster - gonna slap bald head while invisible') 
    end

    if self.combat_approach_id == 4 then
        self:Combat_reposition()
    end

    if self.combat_approach_id == 5 then
        self:Combat_spawn_clone() 
    end


    local notice_gestures = {
        "G_twoopen_midsharp",
        "G_oneopen_highpointsharp",
        "g_Fist",
        "g_Raise_Gun_Chop"
    }

    self:AddGestureSequence(self:LookupSequence(table.Random(notice_gestures)), true)



  end
  function ENT:OnEnemyChange(oldEnemy, newEnemy) end
  function ENT:OnLastEnemy(enemy) end

  -- Those hooks are called inside the coroutine
  function ENT:OnSpawn()
    self:MapSupportCheck()
    
    --self:EmitSound("vo/ravenholm/monk_death01.wav")
    self:SetDefaultRelationship(D_HT)
    self.favspots_visits_max = math.random(1, 3)
    if self.panicked == false then
        self.RunAnimation  = ACT_RUN
    else
        self.RunAnimation  = "run_all_panicked"
    end


    PrintMessage(HUD_PRINTTALK, "Greg has joined the game.")

  end

  function ENT:MapSupportCheck()
    local spos1, spos2, spos3, spos4 = Vector(0,0,0)
    local map_supported = false 

    if game.GetMap() == "snukirepairs_sandbox" then
        self:EmitSound("ambient/creatures/town_zombie_call1.wav",0,100,1)
        map_supported = true
        self.map_is_on_sr = true 
        spos1 = Vector(-6261, 1584, -1855)
        spos2 = Vector(-6940, 8032, -1023)
        spos3 = Vector(7476, 9333, -1279)
        spos4 = Vector(-7110, 11017, -1023)

        local rngspawn = math.random(1,3)
        --print(rngspawn)
        if rngspawn == 1 then
            self:SetPos(spos1)
            self.sr_asteroid_id = 1
        end

        if rngspawn == 2 then
            self:SetPos(spos3)
            self.sr_asteroid_id = 2
        end

        if rngspawn == 3 then
            self:SetPos(spos2)
            self.sr_asteroid_id = 3
        end
    end

    if (game.GetMap() == 'rp_generators') then
        map_supported = true 
        self:EmitSound("ambient/creatures/town_zombie_call1.wav",0,100,1)
        spos1 = Vector(4224, -7335, 77)
        spos2 = Vector(3876, 3587, -266)
        spos3 = Vector(-6813, 936, -1025)
        spos4 = Vector(1161, -1991, -828)

        local spawn = math.random(1,4)
        if spawn == 1 then self:SetPos(spos1) end
        if spawn == 2 then self:SetPos(spos2) end
        if spawn == 3 then self:SetPos(spos3) end
        if spawn == 4 then self:SetPos(spos4) end
    end

    if map_supported == false then
        
        print('map not supported, doing iterations')
        local iterations = math.random(2, 8)
        for i=iterations, 0, -1 do
            local pos = self:RandomPos(math.random(5000, 10000))
            self:SetPos(pos)
            iterations = iterations - 1
            print('greg spawn iteration is ', i)
        end
        print('iterations done')
        --self:EmitSound("ambient/creatures/town_zombie_call1.wav",0,100,0.5)
    end

    self:InitialFavSpots()
  end

  

  function ENT:OnIdle()
    if self.state_goingtoheal == false then 
        if self.favspotamount > 0 then 
            self:DiceRoll_visitfavspot()
        else
            self:AddPatrolPos(self:RandomPos(math.random(900,4500)))
        end
    end
    if self:Health() < 1600 then
        self:GoHeal()
    end
  end



  -- Called outside the coroutine
  function ENT:OnTakeDamage(dmg, hitgroup)
    self:SpotEntity(dmg:GetAttacker())
    self:Fataldamach()
    self:AddGestureSequence(self:LookupSequence("gesture_shoot_rpg", true))
    --print('monster hp:', self:Health())

    if self.state_stalking == true then 
        self:GoVisible()
        self.state_stalking = false
        self.can_attack = true 
        self:ChangeUpCombatApproach()
    end
  end
  function ENT:OnFatalDamage(dmg, hitgroup) end
  


  --//=================ALTAR FUNCTIONS=================\\--







  --//=================SNUKI REPAIRS MAP FUNCTIONS=================\\--
  function ENT:SR_roll_Asteroid_swap()
    local dice = math.random(0, 10)
    local dice_goal = 8

    --print('greg rolled for asteroid swap = ', dice, " goal is ", dice_goal)

    if dice >= dice_goal then 
        self:SR_Asteroid_swap()
    end
  end

  function ENT:SR_Asteroid_swap()

    self:ClearFavSpots()
    self:ClearHealSpots()
    if self.sr_asteroid_id == 1 then 
        local rng = math.random(1,2)

        if rng == 1 then
            local spawnvector = Vector(7476, 9333, -1279) 
            self.sr_asteroid_id = 2
            self:SetPos(spawnvector)
            self:InitialFavSpots()
        end

        if rng == 2 then
            local spawnvector = Vector(-6940, 8032, -1023)
            self.sr_asteroid_id = 3
            self:SetPos(spawnvector)
            self:InitialFavSpots() 
        end
    end

    if self.sr_asteroid_id == 2 then
        local rng = math.random(1,2)
        
        if rng == 1 then
            local spawnvector = Vector(-6261, 1584, -1855) 
            self.sr_asteroid_id = 1
            self:SetPos(spawnvector)
            self:InitialFavSpots()
        end

        if rng == 2 then
            local spawnvector = Vector(-6940, 8032, -1023)
            self.sr_asteroid_id = 3
            self:SetPos(spawnvector)
            self:InitialFavSpots() 
        end
    end

    if self.sr_asteroid_id == 3 then
        local rng = math.random(1,2)
        
        if rng == 1 then
            local spawnvector = Vector(-6261, 1584, -1855) 
            self.sr_asteroid_id = 1
            self:SetPos(spawnvector)
            self:InitialFavSpots()
        end

        if rng == 2 then
            local spawnvector = Vector(7476, 9333, -1279) 
            self.sr_asteroid_id = 2
            self:SetPos(spawnvector)
            self:InitialFavSpots() 
        end 
    end

    --print('greg swapped asteroids, asteroid id is now ', self.sr_asteroid_id)
  end


  


  -- Called inside the coroutine
  function ENT:OnTookDamage(dmg, hitgroup) end
  function ENT:OnDeath(dmg, hitgroup) 
    self:EmitSound("vo/ravenholm/monk_death07.wav", 90,math.random(100, 105), 1.0)
    PrintMessage(HUD_PRINTTALK, "Greg has left the game(Disconnect by user.)")
  end
  function ENT:OnDowned(dmg, hitgroup) end

else

  function ENT:CustomInitialize() end
  function ENT:CustomThink() end
  function ENT:CustomDraw() end

end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)