AddCSLuaFile()

-- Defines the Entity's type, base, printable name, and author for shared access (both server and client)
ENT.Type = "anim" -- Sets the Entity type to 'anim', indicating it's an animated Entity.
ENT.Base = "base_gmodentity" -- Specifies that this Entity is based on the 'base_gmodentity', inheriting its functionality.
ENT.PrintName = "Greg Flashbang" -- The name that will appear in the spawn menu.
ENT.Author = "Your mom" -- The author's name for this Entity.
ENT.Category = "greghunt" -- The category for this Entity in the spawn menu.
ENT.Spawnable = true -- Specifies whether this Entity can be spawned by players in the spawn menu.

-- This will be called on both the Client and Server realms
function ENT:Initialize()
	-- Ensure code for the Server realm does not accidentally run on the Client
	if SERVER then
	    self:SetModel( "models/balloons/balloon_dog.mdl" ) -- Sets the model for the Entity.
        self:SetColor(Color(223,191,137))
	    self:PhysicsInit( SOLID_VPHYSICS ) -- Initializes physics for the Entity, making it solid and interactable.
	    self:SetMoveType( MOVETYPE_VPHYSICS ) -- Sets how the Entity moves, using physics.
	    self:SetSolid( SOLID_VPHYSICS ) -- Makes the Entity solid, allowing for collisions.
        self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
	    local phys = self:GetPhysicsObject() -- Retrieves the physics object of the Entity.
	    if phys:IsValid() then -- Checks if the physics object is valid.
	        phys:Wake() -- Activates the physics object, making the Entity subject to physics (gravity, collisions, etc.).
	    end





        self.ExplodeTimer = 2
        self.ExplodeTick = 0.4
        self.ExplodeTickTimer = 0
        self.TickSound = Sound('buttons/button2.wav')
        self:EmitSound(self.TickSound, 75, 200, 1.0)


        -- timer.Create('flashbang_boom_'..self:EntIndex(), self.ExplodeTimer, 1, function() 
        --     if not self:IsValid() then return end
        --     self:ExplodeFlash()
        -- end)

	end
end


function ENT:ExplodeFlash()
    self:EmitSound('greghunt/stuff/flashbang_explodey.wav', 80, math.random(95,105), 1.0, CHAN_WEAPON)
    

    if SERVER then
        for _,ent in ipairs(ents.FindInSphere(self:GetPos(), 384)) do
            if IsValid(ent) then
                if ent:IsPlayer() and ent:Alive() then
                    local distance = ent:GetPos():Distance(self:GetPos())
                    print('distance is ', distance)
                    local flashtime = 30 / distance * 10
                    if flashtime <= 0 then
                        flashtime = 0.5
                    end
                    if flashtime > 10 then
                        flashtime = 10
                    end
                    print('flashtime is ',flashtime)
                    local fadealpha = 255 / distance * 160
                    print('fadealpha is ', fadealpha)
                    ent:ScreenFade(SCREENFADE.IN, Color(144,144,144,fadealpha), 2, flashtime)
                    ent:ScreenFade(SCREENFADE.OUT, Color(144,144,144,fadealpha), 0.5, flashtime)
                    ent:SetDSP(16)
                    timer.Simple(flashtime, function() ent:SetDSP(1) end)
                end
            end
        end
        local spos = self:GetPos()
        local trs = util.TraceLine({start=spos + Vector(0,0,64), endpos=spos + Vector(32, 0,-128), filter=self})
        util.Decal("Scorch", trs.HitPos + trs.HitNormal, trs.HitPos - trs.HitNormal)
        self:Remove() 
    end
end

function ENT:Think()
    if SERVER then
        if timer.Exists('flashbang_boom_'..self:EntIndex()) == false then
            timer.Create('flashbang_boom_'..self:EntIndex(), self.ExplodeTimer, 1, function() 
                if not self:IsValid() then return end
                self:ExplodeFlash()
            end)
        end 

        --ticks
        if self.ExplodeTickTimer != self.ExplodeTick then
            self.ExplodeTickTimer = self.ExplodeTickTimer + 0.1
        end

        if self.ExplodeTickTimer >= self.ExplodeTick then
            self.ExplodeTickTimer = 0
            self.ExplodeTick = self.ExplodeTick - 0.2
            self:EmitSound(self.TickSound, 75, 200, 1.0, CHAN_ITEM)
        end
    end
end
-- This is a common technique for ensuring nothing below this line is executed on the Server
if not CLIENT then return end

-- Client-side draw function for the Entity
function ENT:Draw()
    self:DrawModel() -- Draws the model of the Entity. This function is called every frame.
end