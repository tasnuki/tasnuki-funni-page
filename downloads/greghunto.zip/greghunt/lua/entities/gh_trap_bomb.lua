AddCSLuaFile()

-- Defines the Entity's type, base, printable name, and author for shared access (both server and client)
ENT.Type = "anim" -- Sets the Entity type to 'anim', indicating it's an animated Entity.
ENT.Base = "base_gmodentity" -- Specifies that this Entity is based on the 'base_gmodentity', inheriting its functionality.
ENT.PrintName = "gregtrap(bomb)" -- The name that will appear in the spawn menu.
ENT.Author = "Your dog" -- The author's name for this Entity.
ENT.Category = "greghunt" -- The category for this Entity in the spawn menu.
ENT.Spawnable = true -- Specifies whether this Entity can be spawned by players in the spawn menu.

local bombmodels = {
    "models/props_junk/cardboard_box004a.mdl",
    "models/props_junk/PropaneCanister001a.mdl",
    "models/Items/car_battery01.mdl"
}

-- This will be called on both the Client and Server realms
function ENT:Initialize()
	-- Ensure code for the Server realm does not accidentally run on the Client
	if SERVER then
	    self:SetModel( table.Random(bombmodels)) -- Sets the model for the Entity.
	    self:PhysicsInit( SOLID_VPHYSICS ) -- Initializes physics for the Entity, making it solid and interactable.
	    self:SetMoveType( MOVETYPE_VPHYSICS ) -- Sets how the Entity moves, using physics.
	    self:SetSolid( SOLID_VPHYSICS ) -- Makes the Entity solid, allowing for collisions.
        self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
	    local phys = self:GetPhysicsObject() -- Retrieves the physics object of the Entity.
	    if phys:IsValid() then -- Checks if the physics object is valid.
	        phys:Wake() -- Activates the physics object, making the Entity subject to physics (gravity, collisions, etc.).
	    end
        self:SetUseType(SIMPLE_USE)

        self.DefuseHits = 6
        self.DefuseProgress = 0
        self.DefusePitch = 100
        self.DefuseSound = Sound('weapons/357/357_reload3.wav')
        self.CanDefuse = true

        self.BombRange = 200
        self.BombRangeIdle = 128
        self.BombDamage = 90
        self.TimeBeforeDet = 1
        self.DetTick = 0.5
        self.DetTimer = 0
        self.DetPitch = 100

        self.Activated = false
        -- if timer.Exists('greg_traps_bombtimer') == false then
        --     timer.Create('greg_traps_bombtimer', self.BombPingTime, 0, function() 

        --     end)
        -- end

	end
end


function ENT:Think()
    if SERVER then
        for _,ent in ipairs(ents.FindInSphere(self:GetPos(), self.BombRangeIdle)) do
            if ent:IsPlayer() and ent:Alive() and not ent:Crouching() then
                self:BombActivate()
            end
        end 


        if self.Activated then
            if self.DetTimer != self.DetTick then
                self.DetTimer = self.DetTimer + 0.2
            end

            if self.DetTimer >= self.DetTick then
                self.DetTimer = 0 
                self.DetTick = self.DetTick - 0.5
                self.DetPitch = self.DetPitch + 50
                self:EmitSound('buttons/blip1.wav', 75, self.DetPitch, 1.0, CHAN_ITEM)
            end
        end

    end
end

function ENT:BombActivate()
    if self.Activated then return end
    self.Activated = true
    self:EmitSound('buttons/button2.wav', 80, 150, 1.0, CHAN_ITEM)
    timer.Create('greg_trap_bomb_'..self:EntIndex(), self.TimeBeforeDet, 1, function() 
        if not self:IsValid() then return end
        self:BombExplode()
    end)
end

function ENT:BombExplode()
    local effectd = EffectData()
    effectd:SetOrigin(self:GetPos())
    util.BlastDamage(self, self, self:GetPos(), self.BombRange, self.BombDamage)
    util.Effect('Explosion', effectd)
    self:EmitSound('^weapons/explode'..math.random(3,5)..'.wav', 90, 100, 1.0, CHAN_STATIC)



    self:Remove()
end


function ENT:Use(pl)
    if self.Activated then return end


    if self.CanDefuse == false then 
        pl:EmitSound('weapons/357/357_reload1.wav', 60, 90, 0.6, CHAN_AUTO)
        self:ExplodeChance()
        return 
    end

    self.DefuseProgress = self.DefuseProgress + 1
    self.DefusePitch = self.DefusePitch + 10
    pl:EmitSound(self.DefuseSound, 60, self.DefusePitch, 0.6, CHAN_AUTO)

    self.CanDefuse = false

    CText(string.format('%d | %d', self.DefuseProgress, self.DefuseHits), Color(255,255,255), pl)

    if self.DefuseProgress >= self.DefuseHits then
        self:EmitSound('weapons/smg1/switch_burst.wav', 75, 100, 1.0, CHAN_AUTO)
        self:Remove()

        CText('Defused!', Color(130,230,123), pl)
    end



    timer.Simple(SoundDuration(self.DefuseSound), function() 
        if not self:IsValid() then return end
        self.CanDefuse = true
    end)
end

function ENT:ExplodeChance()
    local chance = math.random(0,10)

    if chance == 10 then
        self:BombActivate()
    end
end

function ENT:OnRemove()
    GTrapSubtract()
end
-- This is a common technique for ensuring nothing below this line is executed on the Server
if not CLIENT then return end

-- Client-side draw function for the Entity
function ENT:Draw()
    self:DrawModel() -- Draws the model of the Entity. This function is called every frame.
end