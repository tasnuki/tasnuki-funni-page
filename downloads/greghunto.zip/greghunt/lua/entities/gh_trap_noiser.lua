AddCSLuaFile()

-- Defines the Entity's type, base, printable name, and author for shared access (both server and client)
ENT.Type = "anim" -- Sets the Entity type to 'anim', indicating it's an animated Entity.
ENT.Base = "base_gmodentity" -- Specifies that this Entity is based on the 'base_gmodentity', inheriting its functionality.
ENT.PrintName = "gregtrap(noiser)" -- The name that will appear in the spawn menu.
ENT.Author = "Your Cat" -- The author's name for this Entity.
ENT.Category = "greghunt" -- The category for this Entity in the spawn menu.
ENT.Spawnable = true -- Specifies whether this Entity can be spawned by players in the spawn menu.

-- This will be called on both the Client and Server realms
function ENT:Initialize()
	-- Ensure code for the Server realm does not accidentally run on the Client
	if SERVER then
	    self:SetModel( "models/props_lab/reciever01b.mdl" ) -- Sets the model for the Entity.
	    self:PhysicsInit( SOLID_VPHYSICS ) -- Initializes physics for the Entity, making it solid and interactable.
	    self:SetMoveType( MOVETYPE_VPHYSICS ) -- Sets how the Entity moves, using physics.
	    self:SetSolid( SOLID_VPHYSICS ) -- Makes the Entity solid, allowing for collisions.
        self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
	    local phys = self:GetPhysicsObject() -- Retrieves the physics object of the Entity.
	    if phys:IsValid() then -- Checks if the physics object is valid.
	        phys:Wake() -- Activates the physics object, making the Entity subject to physics (gravity, collisions, etc.).
	    end


        self:SetUseType(SIMPLE_USE)

        self.DefuseHits = 12
        self.DefuseProgress = 0
        self.DefusePitch = 70
        self.DefuseSound = Sound('weapons/357/357_reload3.wav')
        self.CanDefuse = true

        self.Activated = false

        self.ActivationRange = 400
        self.Ticks = 0
        self.ActivationTick = 40
        self.ActiveTimer = 5

        self.SFX_Ticks = 0
        self.SFX_Ticks_goal = 2
        self.SFX_Pitch = 70
        self.TickSound = Sound('buttons/button8.wav')


        self.Called = false
        self.SpottedPlayer = nil
	end
end


function ENT:Think()
    if SERVER then
        if not self.Activated then
            if self.Called == true then return end 
            self:StopSound('ambient/machines/combine_terminal_loop1.wav')
            --print(self.Ticks)
            if self.Ticks < self.ActivationTick then
                self.Ticks = self.Ticks + 1
            end

            if self.Ticks >= self.ActivationTick then
                self.Activated = true
                self.Ticks = 0
                self:EmitSound('buttons/blip1.wav', 75, 150, 1.0, CHAN_STATIC)
                self:EmitSound('ambient/machines/combine_terminal_loop1.wav', 75, 150, 1.0, CHAN_STATIC)
            end

            if self.SFX_Ticks < self.SFX_Ticks_goal then
                self.SFX_Ticks = self.SFX_Ticks + 0.6
            end

            if self.SFX_Ticks >= self.SFX_Ticks_goal then
                self.SFX_Ticks = 0
                self.SFX_Ticks_goal = self.SFX_Ticks_goal - 0.1
                self:EmitSound(self.TickSound, 70, self.SFX_Pitch, 0.8, CHAN_ITEM)
                self.SFX_Pitch = self.SFX_Pitch + 2
            end
    end



    if self.Activated then

        for _,ent in ipairs(ents.FindInSphere(self:GetPos(), self.ActivationRange)) do
            if ent:IsPlayer() and ent:Alive() then
                if ent:GetVelocity():LengthSqr() > 50 then
                    if self.Called == true then return end
                    self:NoiseCall(ent)
                    return
                end
            end
        end


        if timer.Exists('greg_trap_noiser_'..self:EntIndex()) == false then
            timer.Create('greg_trap_noiser_'..self:EntIndex(), self.ActiveTimer, 1, function() 
                if not self:IsValid() then return end
                self.Activated = false
                self.SFX_Ticks_goal = 2
                self.SFX_Pitch = 70
                self:EmitSound('buttons/blip1.wav', 75, 150, 1.0, CHAN_STATIC)
            end)
        end

    end
    end
end


function ENT:NoiseCall(ent)
    if self.Called then return end
    for _,greggy in ipairs(ents.FindByClass('npc_gh_greg_drg')) do
        if IsValid(greggy) then
            greggy:SpotEntity(ent)
        end
    end


     self.Activated = false
                    self.SFX_Ticks_goal = 2
                    self.Called = true
                    self:EmitSound('buttons/blip1.wav', 75, 80, 1.0, CHAN_STATIC)
                    self:EmitSound('ambient/creatures/town_zombie_call1.wav', 100, 80, 1.0, CHAN_STATIC, SND_NOFLAGS, 55)

                    timer.Simple(self.ActiveTimer + 10, function() 
                        if not self:IsValid() then return end
                        self.Called = false
                    end)
end


function ENT:Use(pl)
    if self.Called then return end

    if self.Activated then 
        self:NoiseCall(pl)
        return 
    end


    if self.CanDefuse == false then 
        pl:EmitSound('weapons/357/357_reload1.wav', 60, 90, 0.6, CHAN_AUTO)
        self:ActivateChance(pl)
        return 
    end

    self.DefuseProgress = self.DefuseProgress + 1
    self.DefusePitch = self.DefusePitch + 5
    pl:EmitSound(self.DefuseSound, 60, self.DefusePitch, 0.6, CHAN_AUTO)

    self.CanDefuse = false

    CText(string.format('%d | %d', self.DefuseProgress, self.DefuseHits), Color(255,255,255), pl)

    if self.DefuseProgress >= self.DefuseHits then
        self:EmitSound('weapons/smg1/switch_burst.wav', 75, 100, 1.0, CHAN_AUTO)
        self:Remove()

        CText('Defused!', Color(130,230,123), pl)
    end



    timer.Simple(SoundDuration(self.DefuseSound), function() 
        if not self:IsValid() then return end
        self.CanDefuse = true
    end)
end

function ENT:ActivateChance(pl)
    local roll = math.random(0,10)
    
    if roll == 10 then
        self:NoiseCall(pl)
    end
end

function ENT:OnRemove()
    GTrapSubtract()

    self:StopSound('ambient/machines/combine_terminal_loop1.wav')
end

-- This is a common technique for ensuring nothing below this line is executed on the Server
if not CLIENT then return end

-- Client-side draw function for the Entity
function ENT:Draw()
    self:DrawModel() -- Draws the model of the Entity. This function is called every frame.
end