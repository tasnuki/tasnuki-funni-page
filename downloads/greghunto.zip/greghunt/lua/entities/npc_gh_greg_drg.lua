if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "Greg"
ENT.Category = "greghunt"
ENT.Models = {"models/monk.mdl"}
ENT.Skins = {0}
ENT.ModelScale = 1
ENT.CollisionBounds = Vector(10, 10, 72)
ENT.BloodColor = BLOOD_COLOR_RED
ENT.RagdollOnDeath = false

-- Stats --
ENT.SpawnHealth = 5000
ENT.HealthRegen = 0
ENT.MinPhysDamage = 0
ENT.MinFallDamage = 0
--

-- Sounds --
ENT.OnSpawnSounds = {}
ENT.OnIdleSounds = {}
ENT.IdleSoundDelay = 2
ENT.ClientIdleSounds = true
ENT.OnDamageSounds = {}
ENT.DamageSoundDelay = 0.25
ENT.OnDeathSounds = {}
ENT.OnDownedSounds = {}
ENT.Footsteps = {}


--custom
ENT.SFX_Twitch = {
    'greghunt/npc/greg/twitch1.wav',
    'greghunt/npc/greg/twitch2.wav',
    'greghunt/npc/greg/twitch3.wav',
    'greghunt/npc/greg/twitch4.wav'
}

ENT.SFX_Headshot = {
    'greghunt/npc/greg/headshot1.wav',
    'greghunt/npc/greg/headshot2.wav'
}

ENT.VO_changeenemy = {
    'vo/ravenholm/monk_death07.wav',
    'vo/ravenholm/madlaugh01.wav',
    'vo/ravenholm/madlaugh02.wav',
    'vo/ravenholm/madlaugh03.wav',
    'vo/ravenholm/madlaugh04.wav',
    'vo/ravenholm/monk_blocked03.wav',
    'vo/ravenholm/monk_coverme01.wav',
    'vo/ravenholm/monk_coverme04.wav',
    'vo/ravenholm/monk_kill11.wav'
}

ENT.VO_afterstun = {
    'vo/ravenholm/cartrap_better.wav',
    'vo/ravenholm/shotgun_hush.wav',
    'vo/ravenholm/shotgun_theycome.wav',
    'vo/ravenholm/monk_danger03.wav'
}

ENT.VO_afterstun_critical = {
    'vo/ravenholm/bucket_guardwell.wav',
    'vo/ravenholm/bucket_almost.wav',
    'vo/ravenholm/pyre_keepeye.wav',
    'vo/ravenholm/monk_pain04.wav'
}

ENT.VO_spot = {
    'vo/ravenholm/bucket_thereyouare.wav',
    'vo/ravenholm/firetrap_lookout.wav',
    'vo/ravenholm/firetrap_vigil.wav',
    'vo/ravenholm/firetrap_welldone.wav',
    'vo/ravenholm/madlaugh01.wav',
    'vo/ravenholm/madlaugh02.wav',
    'vo/ravenholm/madlaugh03.wav',
    'vo/ravenholm/madlaugh04.wav',
    'vo/ravenholm/monk_kill08.wav',
}

ENT.VO_chasing = {
    'vo/ravenholm/madlaugh01.wav',
    'vo/ravenholm/madlaugh02.wav',
    'vo/ravenholm/madlaugh03.wav',
    'vo/ravenholm/madlaugh04.wav',
}

ENT.VO_rant = {
   'vo/ravenholm/monk_rant01.wav',
   'vo/ravenholm/monk_rant02.wav',
   'vo/ravenholm/monk_rant03.wav',
   'vo/ravenholm/monk_rant04.wav',
   'vo/ravenholm/monk_rant05.wav',
   'vo/ravenholm/monk_rant06.wav',
   'vo/ravenholm/monk_rant07.wav',
   'vo/ravenholm/monk_rant08.wav',
   'vo/ravenholm/monk_rant09.wav',
   'vo/ravenholm/monk_rant10.wav',
   'vo/ravenholm/monk_rant11.wav',
   'vo/ravenholm/monk_rant12.wav',
   'vo/ravenholm/monk_rant13.wav',
   'vo/ravenholm/monk_rant14.wav',
   'vo/ravenholm/monk_rant15.wav',
   'vo/ravenholm/monk_rant16.wav',
   'vo/ravenholm/monk_rant17.wav',
   'vo/ravenholm/monk_rant18.wav',
   'vo/ravenholm/monk_rant19.wav',
   'vo/ravenholm/monk_rant20.wav',
   'vo/ravenholm/monk_rant21.wav',
   'vo/ravenholm/monk_rant22.wav',
}

ENT.VO_goheal = {
    'vo/ravenholm/monk_coverme05.wav',
    'vo/ravenholm/monk_givehealth01.wav',
}

ENT.VO_injured = {
    'vo/ravenholm/monk_pain01.wav',
    'vo/ravenholm/monk_pain02.wav',
    'vo/ravenholm/monk_pain03.wav',
    'vo/ravenholm/monk_pain04.wav',
    'vo/ravenholm/monk_pain07.wav',
}

ENT.VO_killed = {
    'vo/ravenholm/monk_kill03.wav',
    'vo/ravenholm/monk_kill09.wav',
    'vo/ravenholm/monk_kill10.wav',
    'vo/ravenholm/monk_kill11.wav',
    'vo/ravenholm/monk_mourn01.wav',
    'vo/ravenholm/monk_mourn02.wav',
    'vo/ravenholm/monk_mourn04.wav',
    'vo/ravenholm/monk_mourn05.wav',
    'vo/ravenholm/monk_mourn07.wav',
    'vo/ravenholm/madlaugh04.wav',
    'vo/ravenholm/madlaugh03.wav',
}

ENT.VO_shooting = {
    'vo/ravenholm/monk_death07.wav',
    'vo/ravenholm/madlaugh03.wav',
    'vo/ravenholm/cartrap_better.wav',
    'vo/ravenholm/monk_helpme02.wav',
}

ENT.GhostShit = {
    'ambient/voices/playground_memory.wav',
    'ambient/voices/squeal1.wav',
    'ambeint/alarms/warningbell1.wav',
    'ambient/creatures/town_moan1.wav',
    'ambient/creatures/town_child_scream1.wav',
    'ambient/creatures/town_scared_breathing2.wav',
    'ambient/creatures/town_scared_breathing21.wav',
    'ambient/levels/streetwar/gunship_distant2.wav',
    'ambient/levels/streetwar/gunship_distant2.wav',
    'ambient/levels/citadel/strange_talk9.wav'
}

ENT.CriticalAnim = {
    'hunter_cit_stomp',
    'hunter_cit_tackle'
}

--

-- AI --
ENT.Omniscient = false
ENT.SpotDuration = 10
ENT.RangeAttackRange = 500
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0
-- custom
ENT.Ignore_sounds = false
ENT.Omni = true
--


-- Relationships --
ENT.Factions = {"GREG"}
ENT.Frightening = true
ENT.AllyDamageTolerance = 0.33
ENT.AfraidDamageTolerance = 0.33
ENT.NeutralDamageTolerance = 0.33

-- Locomotion --
ENT.Acceleration = 1000
ENT.Deceleration = 1000
ENT.JumpHeight = 50
ENT.StepHeight = 20
ENT.MaxYawRate = 180
ENT.DeathDropHeight = 200

-- Animations --
ENT.IdleAnims = {
    'LineIdle01',
    'LineIdle02',
    'LineIdle03',
    'LineIdle04'
}

ENT.NoticeGestures = {
    "G_twoopen_midsharp",
    "G_oneopen_highpointsharp",
    "g_Fist",
    "g_Raise_Gun_Chop"
}


ENT.WalkAnimation = ACT_WALK
ENT.WalkAnimRate = 1
ENT.RunAnimation = 'run_all_panicked'
ENT.RunAnimRate = 1
ENT.IdleAnimation = 'LineIdle01'
ENT.IdleAnimRate = 1
ENT.JumpAnimation = ACT_JUMP
ENT.JumpAnimRate = 1

-- Movements --
ENT.UseWalkframes = false
ENT.WalkSpeed = 100
ENT.RunSpeed = 350

-- Climbing --
ENT.ClimbLedges = true
ENT.ClimbLedgesMaxHeight = 256
ENT.ClimbLedgesMinHeight = 32
ENT.LedgeDetectionDistance = 20
ENT.ClimbProps = false
ENT.ClimbLadders = true
ENT.ClimbLaddersUp = true
ENT.LaddersUpDistance = 20
ENT.ClimbLaddersUpMaxHeight = math.huge
ENT.ClimbLaddersUpMinHeight = 0
ENT.ClimbLaddersDown = true
ENT.LaddersDownDistance = 20
ENT.ClimbLaddersDownMaxHeight = math.huge
ENT.ClimbLaddersDownMinHeight = 0
ENT.ClimbSpeed = 90
ENT.ClimbUpAnimation = 'run_protected_all'
ENT.ClimbDownAnimation = 'run_protected_all'
ENT.ClimbAnimRate = 10
ENT.ClimbOffset = Vector(0, 0, 0)

-- Detection --
ENT.EyeBone = "ValveBiped.Bip01_Head1"
ENT.EyeOffset = Vector(0, 0, 0)
ENT.EyeAngle = Angle(0, 0, 0)
ENT.SightFOV = 110
ENT.SightRange = 9000
ENT.MinLuminosity = 0.1
ENT.MaxLuminosity = 1
ENT.HearingCoefficient = 5

-- Weapons --
ENT.UseWeapons = true
ENT.Weapons = {'weapon_crowbar', 'weapon_annabelle', 'weapon_stunstick', 'weapon_smg1'}
ENT.WeaponAccuracy = 1
ENT.WeaponAttachment = "Anim_Attachment_RH"
ENT.DropWeaponOnDeath = false
ENT.AcceptPlayerWeapons = false

-- Possession --
ENT.PossessionEnabled = false
ENT.PossessionPrompt = false
ENT.PossessionCrosshair = false
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {}
ENT.PossessionBinds = {}



--#################[CUSTOM VARS]#################--
ENT.HeadAngle = Angle(0,0,0)
ENT.HeadAngle_random = Angle(math.random(-80,80), math.random(-80,80), math.random(-80,80))
ENT.HeadAngle_set = false
ENT.HeadAngle_timer = 2

ENT.Patrolling = false
ENT.Chasing = false


--speaking
ENT.CurrentSpeak = 'nil'
ENT.Speaking = false
ENT.VoicePitch = math.random(90, 105)
ENT.ChaseSpeakTimer = 8
ENT.IdleSpeakTimer = math.random(15, 40)

--wander
ENT.LastEnemyPos = Vector(0,0,0)
ENT.FoundEnemy = false
ENT.Hiding = false
ENT.FunniRNG = math.random(1,3)

ENT.ChatSpeakTrigger = 5
ENT.ChatSpeakCountBeforeTrigger = 10
ENT.ChatSpeakCount = 0

--combat
ENT.CanStun = true
ENT.StunCooldown = 10
ENT.MeleeDamage = 7
ENT.Combat_strat = 8
ENT.HasHealSpot = false
ENT.HealSpotPos = Vector(0,0,0)
ENT.GoingHealing = false
ENT.CanHeal = true
ENT.HealCooldown = 180
ENT.SmgFireRate = 2.5
ENT.CanThrowFlashbang = true
ENT.FlashbangCooldown = 30


--traps
ENT.PlaceTrapCooldown = math.random(20, 160)
ENT.CanPlaceTrap = true

ENT.normalmaterial = "models/monk/monk_sheet.vmt"
ENT.invisiblematerial = "models/shadertest/shader3.vmt"



--map related
ENT.MapEventCooldown = math.random(60, 400)

--#################[SHARED REALM FUNCTIONS]#################--
function ENT:ChangeHeadAngle()
    if self.Combat_strat == 1 then
        self.HeadAngle_set = false
        self:ResetHeadAngle()
        return
    end

    if self.Hiding == true then
        self.HeadAngle_set = false
        return
    end
    local speed = math.pow(0.25, (FrameTime() * game.GetTimeScale()) / 0.05)
    self.HeadAngle_set = false
    self.HeadAngle_random = Angle(math.random(-80,80), math.random(-80,80), math.random(-80,80))
    -- self.HeadAngle = sine(0.25, self.HeadAngle, self.HeadAngle_random)
    for i=0, 200 do
        self.HeadAngle = sine(speed, self.HeadAngle, self.HeadAngle_random)
        self:SetPoseParameter('body_yaw', self.HeadAngle.yaw)
        --print(self.HeadAngle.yaw)
    end

    --print(self.HeadAngle.yaw)

    --visual stuff
    self:EmitSound(table.Random(self.SFX_Twitch), 60, math.random(90, 115), 1.0, CHAN_STATIC)
    local spos = self:GetPos()
    local trs = util.TraceLine({start=spos + Vector(0,0,64), endpos=spos + Vector(32, 0,-128), filter=self})
    util.Decal("Blood", trs.HitPos + trs.HitNormal, trs.HitPos - trs.HitNormal)
    ParticleEffectAttach('blood_impact_red_01_goop', PATTACH_POINT_FOLLOW, self, 1)

    local randomplayer = table.Random(player.GetAll())
    self:SetEyeTarget(randomplayer:GetShootPos())

  end

  function ENT:ResetHeadAngle()
    self:SetPoseParameter('body_yaw', 0)
  end


if SERVER then
--#################[]#################--

  function ENT:CustomInitialize() 
    SetGlobalBool('greg_spawned',true)
    local angry = true
    if angry then
        self:SetDefaultRelationship(D_HT)
    end
    --#################[VISUALS]#################--
    --light
    local light_ent = ents.Create('light_dynamic')
    local light_name = 'greg_light'..self:EntIndex()
    light_ent:Spawn()
    light_ent:SetName(light_name)
    for k,v in ipairs(ents.FindByName('greg_light'..self:EntIndex())) do
        if IsValid(v) then
            v:SetPos(self:GetPos() + (self:GetUp() * 64) + (self:GetForward() * 16))
            v:SetParent(self, 'forward')
            v:Fire('Brightness', '1')
            v:Fire('Color', '202 16 16')
            v:Fire('Distance', '200')
            v:Fire('style', '1')
            v:Fire('TurnOn')     
        end
    end
    self:FlashlightState('off')
    self:SelectWeapon('weapon_crowbar')

    PrintTable(self:GetAttachments())

    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_Spine'), Angle(0,26,0))
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_Head1'), Angle(0,26,0))
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_L_Thigh'), Angle(0,-26,0))
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_R_UpperArm'), Angle(90,-26,26))

    self:ManipulateBoneScale(self:LookupBone('ValveBiped.Bip01_L_UpperArm'), Vector(1.5,1.5,1.5))
    self:ManipulateBoneScale(self:LookupBone('ValveBiped.Bip01_R_UpperArm'), Vector(1.5,1.5,1.5))

    self:SetColor(Color(200,200,200,255))


    self:SetFlexScale(5.0)
    self:SetFlexWeight(42, 0.9)
    --self:SetFlexWeight(38, 3)
    self:SetFlexWeight(12, 4)
    self:SetFlexWeight(13, 4)
    self:SetFlexWeight(10, -1)
    self:SetFlexWeight(11, -1)
    for i=0, self:GetFlexNum() - 1 do
        print(i, ' - ',self:GetFlexName(i))
    end
    --#################[]#################--



    --#################[SPAWNING]#################--
    local sp_enabled = true
    if sp_enabled then
        local random_mesh = table.Random(navmesh.GetAllNavAreas())
        local mesh_pos = random_mesh:GetRandomPoint()

        if mesh_pos == nil then
            return
        end

        self:SetPos(mesh_pos)

        PrintMessage(HUD_PRINTTALK, 'GREG has joined the game.')
        EmitSound('ambient/creatures/town_zombie_call1.wav', Entity(1):GetPos(), 0, CHAN_AUTO, 1.0, -1, 0, 80, 13)
    end

    if self.HasHealSpot == false then
        self.HasHealSpot = true
        self.HealSpotPos = self:RandomPos(math.random(600,1000))
    end

    self:CleanStuff()
    greg_traps_placed = 0
    --#################[]#################--

  end
  function ENT:CustomThink() 
    --#################[LITTLE STATES]#################--
    --ignore sounds
    if self.Ignore_sounds == true then
        self.HearingCoefficient = 0.0
    else
        self.HearingCoefficient = 5.0
    end

    --know where enemies are at
    if self.Omni == true then
        self.Omniscient = true
    else
        self.Omniscient = false
    end

    --stun cooldown
    if self.CanStun == false and timer.Exists('greg_Stun') == false then
        timer.Create('greg_Stun', self.StunCooldown, 1, function() 
            if not self:IsValid() then
                return
            end
            self.CanStun = true
        end)
    end

    --chase speak cooldown
    if self.Chasing == true and timer.Exists('greg_Chase') == false then
        timer.Create('greg_Chase', self.ChaseSpeakTimer, 1, function() 
            if not self:IsValid() then
                return
            end
            self:Speak(table.Random(self.VO_chasing))
        end)
        
    end

    --heal cooldown
    if self.CanHeal == false and timer.Exists('greg_Heal') == false then
        timer.Create('greg_Heal', self.HealCooldown, 1, function() 
            if not self:IsValid() then
                return
            end
            self.CanHeal = true
        end)
    end

    --flashbang cooldown
    if self.CanThrowFlashbang == false and timer.Exists('greg_Flashbang') == false then
        timer.Create('greg_Flashbang', self.FlashbangCooldown, 1, function() 
            if not self:IsValid() then return end
            self.CanThrowFlashbang = true
        end)
    end

    --trap cooldown
    if self.CanPlaceTrap == false and timer.Exists('greg_Traps') == false then
        timer.Create('greg_Traps', self.PlaceTrapCooldown, 1, function() 
            if not self:IsValid() then return end
            self.CanPlaceTrap = true
        end)
    end

    if self.Chasing == false then
        timer.Remove('greg_Chase')
        self.Ignore_sounds = false

        if timer.Exists('greg_Rant') == false then
            timer.Create('greg_Rant', self.IdleSpeakTimer, 1, function() 
                if not self:IsValid() then
                    return 
                end
                if self.Hiding == true then
                    return
                end
                self:Speak(table.Random(self.VO_rant))
                self.IdleSpeakTimer = math.random(15,40)
            end)
        end
    end

    -- if timer.Exists('greg_music_amb') == false and self.Chasing == false then
    --     timer.Create('greg_music_amb', math.random(10, 60), 1, function() 
    --         if not self:IsValid() then return end
    --         track:FadeOut(0.5)
    --         GregPlayMusic('amb')
    --     end)
    -- end

    if self.Chasing == true then
        self.Ignore_sounds = true
    end



    --talking
    if self.CurrentSpeak != 'nil' then
        self:SetFlexWeight(39, math.random(-1, 0.8))
    end





    --#################[]#################--
    --print(self.Patrolling)

    --#################[VISUAL STUFF]#################--
    if self.HeadAngle_set == false then
        self.HeadAngle_set = true
        
        timer.Create('greg_HeadTimer', self.HeadAngle_timer, 1, function() 
            if not self:IsValid() then
                return
            end
            self:ChangeHeadAngle()
        end)

    end

    
    if self.Patrolling == true then
        self.HeadAngle_timer = 6
    end

    if self.Patrolling == false and self.Chasing == false then
        self.HeadAngle_timer = 2
    end

    if self.Chasing == true then
        self.HeadAngle_timer = 0.4
    end

    --#################[]#################--


    --#################[FUNCTIONS]#################--
    self:OpenDoors()
    --#################[]#################--





    --#################[COMBAT RELATED STATES]#################--
    if self.Combat_strat == 1 then
        
    end


    --get closer and teleport away (setup)
    if self.Combat_strat == 2 then
        self.RangeAttackRange = 200
    end

    --gun
    if self.Combat_strat == 1 then
        self.RangeAttackRange = 1500
    end

    --smg
    if self.Combat_strat == 4 then
        self.RangeAttackRange = 800
    end

    --just teleport away
    if self.Combat_strat == 3 then
        self:TeleportAway()
    end


    --flashbang range
    if self.Combat_strat == 8 then
        self.RangeAttackRange = 200
    end


     --#################[]#################--



     --#################[MAP RELATED]#################--

    if timer.Exists('greg_Map') == false then
        timer.Create('greg_Map', self.MapEventCooldown, 1, function()
            self:DoMapEvents()
            self.MapEventCooldown = math.random(60, 400)
        end)
    end



     --#################[]#################--
    
  end

  function sine(f,from,to)
    return Lerp(math.ease.InSine(f), from, to)
  end

  function ENT:Speak(line, spook) 
    if self.Speaking == true then
        return
    end
    local dsp = 1
    if spook == false or spook == nil then
        dsp = 1
    end
    if spook == true then
        dsp = 4
    end
    local voiceline = line
    self.CurrentSpeak = voiceline
    local voiceline_dur = SoundDuration(voiceline)
    self:EmitSound(voiceline, 75, self.VoicePitch, 1.0, CHAN_VOICE, 0, dsp)
    self.Speaking = true


    timer.Create('greg_Speak', voiceline_dur, 1, function() 
        if not self:IsValid() then
            return
        end
        self.Speaking = false
        self.CurrentSpeak = 'nil'
    end)
  end

  function ENT:ForceSpeak(line, spook)
    if self.Speaking == true then
        self.Speaking = false
        self:StopSound(self.CurrentSpeak)
        self.CurrentSpeak = 'nil'
        if timer.Exists('greg_Speak') == true then
            timer.Remove('greg_Speak')
        end
    end
    local dsp = 1
    if spook == false or spook == nil then
        dsp = 1
    end
    if spook == true then
        dsp = 4
    end
    local voiceline = line
    self.CurrentSpeak = voiceline
    local voiceline_dur = SoundDuration(voiceline)
    self:EmitSound(voiceline, 85, self.VoicePitch, 1.0, CHAN_VOICE, 0, dsp)
    self.Speaking = true


    timer.Create('greg_Speak', voiceline_dur, 1, function() 
        if not self:IsValid() then
            return
        end
        self.Speaking = false
        self.CurrentSpeak = 'nil'
    end)

  end

  function ENT:FlashlightState(state)
    local read = string.lower(state)
    if read == 'on' then
        for _,light in ipairs(ents.FindByName('greg_light'..self:EntIndex())) do
            if IsValid(light) then
                light:Fire('TurnOn')
            end
        end
    end

    if read == 'off' then
        for _,light in ipairs(ents.FindByName('greg_light'..self:EntIndex())) do
            if IsValid(light) then
                light:Fire('TurnOff')
            end
        end
    end
  end

  function ENT:OpenDoors()

    for _,ent in ipairs(ents.FindInCone(self:GetPos(), self:GetForward(), 127, 0.707)) do
        if ent:GetClass() == 'func_door' then
            ent:Fire('Open')
        end

        if ent:GetClass() == 'prop_door_rotating' then
            if self.FunniRNG == 50 then
                ent:Dissolve(1, 100)
            else
                ent:Fire('Open')
            end
            self.FunniRNG = math.random(1,50)
        end
    end
    
  end

  function ENT:DoGesture()
    self:AddGestureSequence(self:LookupSequence(table.Random(self.NoticeGestures)), true)
  end

  function ENT:HealUp()
    local gain = math.random(500, 1000)
    self:Health(self:Health() + gain)
    self:EmitSound('items/medshot4.wav', 80, 100, 1.0, CHAN_AUTO)

    --reset
    self.GoingToHeal = false
    self.CanHeal = false
  end

  function ENT:ChangeCombatStrat()
    self.RangeAttackRange = 500
    self.Combat_strat = math.random(1,10)
  end

  function ENT:TeleportAway()
    local random_mesh = table.Random(navmesh.GetAllNavAreas())
        local mesh_pos = random_mesh:GetRandomPoint()

        if mesh_pos == nil then
            self:ChangeCombatStrat()
            return
        end

        self:SetPos(mesh_pos)
        self:ChangeCombatStrat()
  end


  -- These hooks are called when the nextbot has an enemy (inside the coroutine)
  function ENT:OnMeleeAttack(enemy) 
    --just punch
    if self.Combat_strat != 7 then
        local dmg = DamageInfo()
        dmg:SetDamage(self.MeleeDamage)
        dmg:SetAttacker(self)
        dmg:SetInflictor(self)
        dmg:SetDamageType(DMG_BULLET)

        enemy:TakeDamageInfo(dmg)
        
        self:EmitSound('weapons/crowbar/crowbar_impact'..math.random(1,2)..'.wav', 75, math.random(98,105), 1.0, CHAN_WEAPON)
        enemy:EmitSound(table.Random(self.SFX_Twitch), 75, 110, 0.7, CHAN_STATIC)

        if enemy:IsPlayer() == true then
            enemy:ViewPunch(Angle(20,0,10))
            enemy:SetDSP(16)
            timer.Create('greg_muffle'..enemy:Nick(), 1, 1, function() 
                enemy:SetDSP(1)
            end)
        end

        self:PlaySequenceAndMove('swing', 2, self.FaceEnemy) 
        return
    end


    --gib grenade and teleport away lole :)
    if self.Combat_strat == 7 then
        self:DropGrenadeAttack(math.random(1,10))
        self:ChangeCombatStrat()
        self:TeleportAway()
    end
  end

  function ENT:OnRangeAttack(enemy) 



    --teleport
    if self.Combat_strat == 2 then
        local which_pos = math.random(1,2)
        if which_pos == 1 then
            local navmesh_pos = navmesh.GetNearestNavArea(self:GetPos())
            local pos = navmesh_pos:GetRandomPoint()
            self:SetPos(pos)
            self:ChangeCombatStrat()
            return
        end

        if which_pos == 2 then
            local navmesh_pos = navmesh.GetNearestNavArea(enemy:GetPos())
            local pos = navmesh_pos:GetRandomPoint()
            self:SetPos(pos)
            self.Combat_strat = 1
            return
        end

    end


    --fire annabelle
    if self.Combat_strat == 1 then
        self:EmitSound('items/ammo_pickup.wav', 100, 90, 1.0, CHAN_STATIC)
        self:ShootGunAttack()
    end


    --fire smg
    if self.Combat_strat == 4 then
        self:EmitSound('items/ammo_pickup.wav', 90, 90, 1.0, CHAN_STATIC)
        self:MinigunAttack()
    end

    --turn props into bombs
    if self.Combat_strat == 5 then
        self:BombPropsAttack(math.random(3,12), self:GetEnemy())
    end


    --swap positions with a random player
    if self.Combat_strat == 10 then
        self:ChangeSpotsAttack()
    end

    --placedown flashbang
    if self.Combat_strat == 8 then
        self:PlaceFlashbangAttack()
    end

  end

  function ENT:ShootGunAttack()
    self:ForceSpeak('vo/ravenholm/shotgun_overhere.wav')
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_R_UpperArm'), Angle(0,0,0))
    self:ResetHeadAngle()
    self.HeadAngle_timer = 12
    self.Combat_strat = 0
    self:SelectWeapon('weapon_annabelle')
    --self:StripWeapon('weapon_crowbar')
    --self:Give('weapon_annabelle')
    self:PlaySequenceAndWait('IdleAngryToShoot', 0.6, self.FaceEnemy)
    bullet = {}
    bullet.Attacker = self
    bullet.Inflictor = self:GetWeapon()
    bullet.Damage = 20
    bullet.Force = 100
    bullet.Num = 1
    bullet.Tracer = 1
    bullet.Dir = self:GetForward()
    bullet.Src = self:GetShootPos()

    self:FireBullets(bullet)
    --self:PlaySequence('shoot_gun', 1.0, self.FaceEnemy)
    self:EmitSound('weapons/shotgun/shotgun_fire6.wav', 100, 100, 1.0, CHAN_WEAPON)
    self:ForceSpeak('vo/ravenholm/shotgun_catch.wav')
    self:PlaySequenceAndWait('ShootToIdleAngry', 1.0)
    self:EmitSound('items/ammo_pickup.wav', 75, 100, 1.0)
    self:SelectWeapon('weapon_crowbar')
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_R_UpperArm'), Angle(90,-26,26))
    self:ChangeCombatStrat()
  end

  function ENT:MinigunAttack()
    --init
    self:ForceSpeak('vo/ravenholm/monk_giveammo01.wav')
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_R_UpperArm'), Angle(0,0,0))
    self:ResetHeadAngle()
    self.HeadAngle_timer = 12
    self.Combat_strat = 0
    --

    --setup
    local bullets_to_fire = 30 + math.random(0,60)

    self:SelectWeapon('weapon_smg1')
    self:PlaySequenceAndWait('IdleAngryToShoot', 0.6, self.FaceEnemy)
    mbullet = {}
    mbullet.Attacker = self
    mbullet.Inflictor = self:GetWeapon()
    mbullet.Damage = 5
    mbullet.Force = 60
    mbullet.Num = 1
    mbullet.Tracer = 1
    mbullet.Dir = self:GetForward()
    mbullet.Src = self:GetShootPos()
    --

    --fire
    for i=0,bullets_to_fire do
        mbullet.Dir = self:GetForward()
        mbullet.Src = self:GetShootPos()
        self:FireBullets(mbullet)
        self:EmitSound('weapons/smg1/smg1_fire1.wav', 80, 100, 1.0, CHAN_WEAPON)
        self:Speak(table.Random(self.VO_shooting))
        self:PlaySequenceAndWait('shoot_ar2', self.SmgFireRate, self.FaceEnemy)
    end
    --

    --end
    self:EmitSound('weapons/smg1/smg1_reload.wav', 75, 100, 1.0, CHAN_AUTO)
    self:PlaySequenceAndWait('ShootToIdleAngry', 1.0)
    self:EmitSound('items/ammo_pickup.wav', 75, 100, 1.0)
    self:SelectWeapon('weapon_crowbar')
    self:ManipulateBoneAngles(self:LookupBone('ValveBiped.Bip01_R_UpperArm'), Angle(90,-26,26))
    self:ChangeCombatStrat()
    --
  end

  function ENT:BombPropsAttack(count,enemy)
    local turned = 0
    local pos = enemy:GetPos()
    for _,prop in ipairs(ents.FindInSphere(pos, 666)) do
        if IsValid(prop) and prop:GetClass() == 'prop_physics' then
            if turned != count then
                local prop_pos = prop:GetPos()
                local bomb = ents.Create('grenade_helicopter')
                bomb:Spawn()
                bomb:SetPos(prop_pos)
                prop:Remove() 
                turned = turned + 1
            end
        end
    end

    self:ChangeCombatStrat()
  end

  function ENT:DropGrenadeAttack(count)
    local mypos = self:GetPos()
    self:ForceSpeak('vo/ravenholm/exit_nag01.wav')
    self:PlaySequenceAndWait('swing', 1, self.FaceEnemy)

    for i=0, count do
        self:DropGrenadeAttack_Spawn(mypos)
    end
  end

  function ENT:DropGrenadeAttack_Spawn(pos)
    local granate = ents.Create('npc_grenade_frag')
    local granate_pos = pos + Vector(0,0,32)
    local granate_timer = 1
    granate:Spawn()
    granate:SetPos(granate_pos)
    granate:Fire('SetTimer', tostring(granate_timer))

  end

  function ENT:ChangeSpotsAttack()
    local randomplayer = table.Random(player.GetAll())

    local my_pos = self:GetPos()
    local my_angles = self:GetAngles()

    local player_pos = randomplayer:GetPos()
    local player_angles = randomplayer:GetAngles()

    randomplayer:SetPos(my_pos)
    randomplayer:SetAngles(my_angles)
    randomplayer:EmitSound('greghunt/npc/greg/swap_pos.wav', 75, math.random(90,110), 0.8)

    self:SetPos(player_pos)
    self:SetAngles(player_angles)
    self:EmitSound('greghunt/npc/greg/swap_pos.wav', 75, math.random(90,110), 0.8)

    self:ChangeCombatStrat()
  end


  function ENT:PlaceFlashbangAttack()
    if self.CanThrowFlashbang == false then self:ChangeCombatStrat() end
    local flashbang = ents.Create('gh_flashbang')
    local flashbang_pos = self:GetPos() + Vector(0,0,32)
    flashbang:Spawn()
    flashbang:SetPos(flashbang_pos)

    self.CanThrowFlashbang = false
  end

  function ENT:PlacedownTrap()

    --checks
    if self.CanPlaceTrap == false then 
        print('greg - cannot place traps rn')
        return 
    end
    if greg_traps_placed >= greg_traps_max then
        print('greg - max trap count reached, cannot place')
        return
    end
    local roll = math.random(0,10)
    local win = 4

    if roll < win then 
        print('greg - roll is lower than win, cant place trap')
        return 
    end
    --checks end here
    print('greg - passed trap checks')
    --trap placement itself
    self.CanPlaceTrap = false
    local trap_id = math.random(1,1)
    local trap_classes = {
        'gh_trap_bomb',
        'gh_trap_noiser'
    }

    local class = table.Random(trap_classes)
    local trap = ents.Create(class)
    local trap_pos = self:GetPos() + Vector(0,0, 32)
    trap:Spawn()
    trap:SetPos(trap_pos)
    trap:SetName('gregtrap')

    greg_traps_placed = greg_traps_placed + 1
    print('greg - placed trap, class is ',class,', traps placed total = ', greg_traps_placed )

  end


  function ENT:OnContact(ent)
    if ent:GetClass() == 'prop_physics' then
        local physprop = ent:GetPhysicsObject()
		physprop:Wake()
		physprop:SetVelocity(self:GetForward() * 800)
    end
  end


  function ENT:OnChaseEnemy(enemy) 
    self.WalkAnimation = ACT_WALK
    self:SetEyeTarget(enemy:GetShootPos())
    self.Chasing = true
    self.GoingToHeal = false
    

    if timer.Exists('greg_ChaseStrat') == false then
        timer.Create('greg_ChaseStrat', 10, 1, function() 
            if not self:IsValid() then
                return
            end
            local chance_to_trigger = 9
            local chance = math.random(0.1, 0.9) * 10
            if chance > chance_to_trigger then
                self:ChangeCombatStrat()
            end
        end)
    end
  end
  function ENT:OnAvoidEnemy(enemy) end

  -- These hooks are called while the nextbot is patrolling (inside the coroutine)
  function ENT:OnReachedPatrol(pos)
    self.Patrolling = false
    if self.Hiding == false then 
        self.IdleAnimation = table.Random(self.IdleAnims)
    else
        self.IdleAnimation = 'crouchidlehide'
    end
    self:FlashlightState('off')

    if self.GoingToHeal == true then
        self:HealUp()
    end

    if self.Hiding == false then
        self:PlacedownTrap()
    end

    if self.Hiding == false then
        self:Wait(math.random(3, 7)) 
    else
        self:Wait(math.random(10, 30))
    end


    --traps

    --chat shit
    self.ChatSpeakCount = self.ChatSpeakCount + 1
    if self.ChatSpeakCount >= self.ChatSpeakCountBeforeTrigger then
        self.ChatSpeakCount = 0
        GregChatToPlayer()
    end
  end 
  function ENT:OnPatrolUnreachable(pos) end
  function ENT:OnPatrolling(pos) 
    --self:ResetHeadAngle()
    self.Patrolling = true
  end

  -- These hooks are called when the current enemy changes (outside the coroutine)
  function ENT:OnNewEnemy(enemy) 
    self.CombatStrat = math.random(1,2)
    self:ChangeHeadAngle()
    self.HeadAngle_timer = 0.4
    self:ForceSpeak(table.Random(self.VO_spot))

    self:FlashlightState('on')
    self:EmitSound('items/flashlight1.wav', 75, 80, 1.0, CHAN_AUTO, 0)


    self.FoundEnemy = true
    self.LastEnemyPos = enemy:GetPos()

    self:DoGesture()


    self.ChatSpeakCount = 0



    -- --music shit
    -- if greg_is_playing_music == false then
    --     track:FadeOut(0.2)
    --     GregPlayMusic('combat') 
    --     greg_is_playing_music = true
    -- end
    
  end
  function ENT:OnEnemyChange(oldEnemy, newEnemy)
    self.CombatStrat = math.random(1,2)
    self:ForceSpeak(table.Random(self.VO_changeenemy))
    self:DoGesture()
  end
  function ENT:OnLastEnemy(enemy) 
    self.Chasing = false
  end

  -- Those hooks are called inside the coroutine
  function ENT:OnSpawn() end
  function ENT:OnIdle()
    self:SetFlexWeight(42, math.random(0,4))
    self:IdleChoicers()
  end

  function ENT:OnOtherKilled(victim,info)
    local attacker = info:GetAttacker()
    if attacker == self then
        self:Speak(table.Random(self.VO_killed))

        if victim:IsPlayer() then
            local funnichance = math.random(1,3)

            if funnichance == 3 then
                local variant = math.random(1,3)
                
                if variant == 1 then --spawn funi lil toilet
                    local rag = victim:GetRagdollEntity()
                    rag:Remove()
                    local modele = ents.Create('prop_physics')
                    local modele_pos = victim:GetPos() + Vector(0,0,55)
                    local modele_angles = victim:GetAngles()
                    modele:SetModel('models/props_c17/FurnitureToilet001a.mdl')
                    modele:SetName('funnyassproplole')
                    modele:Spawn()
                    modele:SetPos(modele_pos)
                    modele:SetAngles(modele_angles)
                    modele:EmitSound('greghunt/npc/greg/misc/funni_kill_1.wav', 90, 100, 1.0, CHAN_AUTO)
                end

                if variant == 2 then --spawn grave
                    local rag = victim:GetRagdollEntity()
                    rag:Remove()
                    local modele = ents.Create('prop_physics')
                    local modele_pos = victim:GetPos() + Vector(0,0,55)
                    local modele_angles = victim:GetAngles()
                    modele:SetModel('models/props_c17/gravestone002a.mdl')
                    modele:SetName('funnyassproplole')
                    modele:Spawn()
                    modele:SetPos(modele_pos)
                    modele:SetAngles(modele_angles)
                    modele:EmitSound('greghunt/npc/greg/misc/funni_kill_2.wav', 90, 100, 1.0, CHAN_AUTO)
                end

                if variant == 3 then
                    local rag = victim:GetRagdollEntity()
                    rag:EmitSound('greghunt/npc/greg/misc/funni_kill_3.wav', 80, 100, 1.0, CHAN_AUTO)
                    timer.Simple(1, function() rag:Remove() end)
                end
            end
        end
    end
  end

  function ENT:OnRemove()
    timer.Remove('greg_Map')
    SetGlobalBool('greg_spawned',false)
    self:CleanStuff()
  end

  function ENT:IdleChoicers()
    self.WalkAnimation = ACT_WALK
    self.Hiding = false
    local rng_reroll_chance = math.random(1,10)
    self.Chasing = false
    if self:GetMaterial() == self.invisiblematerial then
        self:SetMaterial()
    end


    --first let's see if my health is good
    if self:Health() < 2000 then
        print('my health sucks')
        self:Speak(table.Random(self.VO_injured))
        if self.HasHealSpot == true and self.CanHeal == true then
            print('go heal pls')
            self.GoingToHeal = true
            self:AddPatrolPos(self.HealSpotPos)
            self:ForceSpeak(table.Random(self.VO_goheal))
            return
        end
    end


    local rng_choice = math.random(1,6)
    print(rng_choice)
    --just wander
    if rng_choice == 1 then
        self:AddPatrolPos(self:RandomPos(math.random(1000,4600)))
        return
    end

    --go to last seen enemy spot
    if rng_choice == 2 then
        if not self.FoundEnemy then
            self:IdleChoicers()
        end
        if self:GetPos() == self.LastEnemyPos then
            self:IdleChoicers()
            return
        end
        self:AddPatrolPos(self.LastEnemyPos)
        return
    end

    --spot random player and go
    if rng_choice == 3 then
        if rng_reroll_chance > 6 then
            self:IdleChoicers()
            return
        end

        local randomplayer = table.Random(player.GetAll())
        self:SpotEntity(randomplayer)
        return
    end

    --pick nearest spot near a player and go there
    if rng_choice == 4 then
        if rng_reroll_chance > 7 then
            self:IdleChoicers()
            return
        end
        local randomplayer = table.Random(player.GetAll())
        local navmesh_area = navmesh.GetNearestNavArea(randomplayer:GetPos())
        local navmesh_pos = navmesh_area:GetRandomPoint()

        self:AddPatrolPos(navmesh_pos)
        return
    end

    --pick nearest spot near a player and go there but silently
    if rng_choice == 5 then
        if rng_reroll_chance > 7 then
            self:IdleChoicers()
            return
        end
        local randomplayer = table.Random(player.GetAll())
        local navmesh_area = navmesh.GetNearestNavArea(randomplayer:GetPos())
        local navmesh_pos = navmesh_area:GetRandomPoint()
        self.Hiding = true
        self.WalkAnimation = 'crouchRUNALL1'
        self:SetMaterial(self.invisiblematerial)
        self:AddPatrolPos(navmesh_pos)
        return
    end

    --go hide
    if rng_choice == 6 then
        local area = table.Random(navmesh.GetAllNavAreas())
        local hidingspot = table.Random(area:GetHidingSpots(math.random(1,8)))
        print(hidingspot)
        if hidingspot == nil then
            self:IdleChoicers()
            return
        end
        self.Hiding = true
        self.WalkAnimation = 'Crouch_walk_all'
        self.IdleAnimation = 'crouchidlehide'

        self:AddPatrolPos(hidingspot)
        return
    end


  end

  function ENT:DoMapEvents()
    local event_id = 4

    if event_id == 1 then
        local randomplayer = table.Random(player.GetAll())
        local nav = navmesh.GetNearestNavArea(randomplayer:GetPos() + Vector(math.random(100, 500),0,0))
        if nav == nil then
            nav = navmesh.GetNearestNavArea(randomplayer:GetPos() - Vector(math.random(100, 500),0,0))
        end

        if nav == nil then
            return
        end

        local pos = nav:GetRandomPoint()
        EmitSound(table.Random(self.VO_chasing), pos, -1, CHAN_AUTO, math.random(0.2, 1.0), 75, 0, self.VoicePitch)
    end

    if event_id == 2 then
        local filter = RecipientFilter()

        local randomplayer = table.Random(player.GetAll())
        filter:AddPlayer(randomplayer)
        local nav = navmesh.GetNearestNavArea(randomplayer:GetPos() + Vector(math.random(100, 500),0,0))
        if nav == nil then
            nav = navmesh.GetNearestNavArea(randomplayer:GetPos() - Vector(math.random(100, 500),0,0))
        end

        if nav == nil then
            return
        end

        local pos = nav:GetRandomPoint()
        EmitSound(table.Random(self.GhostShit), pos, -1, CHAN_AUTO, math.random(0.1, 0.3), 75, 0, math.random(80, 105), 1, filter)
        filter:RemoveAllPlayers()
    end

    if event_id == 3 then
        local sillyman = ents.Create('npc_gh_playermimic_drg')
        sillyman:Spawn()
        return
    end

    if event_id == 4 then
        GregDoFogEvent(math.random(15, 80))
        return
    end
  end

  function ENT:HandleStuck()
    self:TeleportAway()
  end

  function ENT:CleanStuff()
    for _,deathprop in ipairs(ents.FindByName('funnyassproplole')) do
        if IsValid(deathprop) then
            deathprop:Remove()
        end
    end

    for _,trap in ipairs(ents.FindByName('gregtrap')) do
        if IsValid(trap) then
            trap:Remove()
        end
    end

    greg_traps_placed = 0

    --GregStopAllMusic()
  end

  function ENT:CriticalStrike(dmg)
    local damage = dmg:GetDamage()
    local attacker = dmg:GetAttacker()
    dmg:AddDamage(damage * 2)
    self:TakeDamageInfo(dmg)
    self:EmitSound('greghunt/npc/greg/criticalhit.wav', 90, math.random(90,110), 1.0, CHAN_AUTO)
    self:SpotEntity(attacker)
    self:ForceSpeak('vo/ravenholm/monk_death07.wav', true)
    ParticleEffectAttach('blood_advisor_pierce_spray_b', PATTACH_POINT_FOLLOW, self, 1)
    self:PlaySequenceAndWait(table.Random(self.CriticalAnim), 1)
    self:PlaySequenceAndWait('crouchhidetostand', 1)
    self:ForceSpeak(table.Random(self.VO_afterstun_critical), true)
  end


  -- Called outside the coroutine
  function ENT:OnTakeDamage(dmg, hitgroup)
    self:SpotEntity(dmg:GetAttacker())
  end
  function ENT:OnFatalDamage(dmg, hitgroup) end
  
  -- Called inside the coroutine
  function ENT:OnTookDamage(dmg, hitgroup) 
    -- print(dmg)
    -- local damage = dmg:GetDamage()
    -- print(damage)
    if self:GetEnemy() == NULL then
        self:CriticalStrike(dmg)
        return
    end


    if hitgroup == HITGROUP_HEAD then
        self:AddGestureSequence(self:LookupSequence("gesture_shoot_rpg", true))
        if self:GetMaterial() == self.invisiblematerial then
            self:SetMaterial()
        end
        self:EmitSound(table.Random(self.SFX_Headshot), 90, 100, 1.0, CHAN_AUTO)
        if self.CanStun == true then
            self.CanStun = false
            self:ForceSpeak('vo/ravenholm/monk_death07.wav', false)
            self:PlaySequenceAndWait('cower', 0.6)
            self:ForceSpeak(table.Random(self.VO_afterstun))
        end
    end

  end
  function ENT:OnDeath(dmg, hitgroup) 
    self:StopSound(self.CurrentSpeak)
    local funniprop_pos = self:GetPos()
    PrintMessage(HUD_PRINTTALK, 'GREG has left the game (Disconnect by User).')
    local funniprop = ents.Create('prop_physics')
    funniprop:SetModel('models/props_c17/FurnitureToilet001a.mdl')
    funniprop:SetName('funnyassproplole')
    funniprop:Spawn()
    funniprop:SetPos(funniprop_pos + funniprop:GetUp()*64)
    self:CleanStuff()

    for _,mimics in ipairs(ents.FindByClass('npc_gh_playermimic_drg')) do
        if IsValid(mimics) then
            mimics:Remove()
        end
    end

    SetGlobalBool('greg_spawned',false)
  end
  function ENT:OnDowned(dmg, hitgroup) end

else

  function ENT:CustomInitialize() end
  function ENT:CustomThink() end
  function ENT:CustomDraw() end

end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)