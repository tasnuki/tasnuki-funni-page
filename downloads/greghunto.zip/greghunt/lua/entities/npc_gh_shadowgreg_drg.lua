if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "SHADOW GREG"
ENT.Category = "greghunt"
ENT.Models = {"models/monk.mdl"}
ENT.Skins = {0}
ENT.ModelScale = 1
ENT.CollisionBounds = Vector(18, 18, 72)
ENT.BloodColor = BLOOD_COLOR_MECH
ENT.RagdollOnDeath = false

-- AI --
ENT.sr_asteroid_id = 0
ENT.map_is_on_sr = false 



-- Stats --
ENT.SpawnHealth = 100
ENT.HealthRegen = 0
ENT.MinPhysDamage = 10
ENT.MinFallDamage = 10

-- Sounds --
ENT.OnSpawnSounds = {}
ENT.OnIdleSounds = {}
ENT.IdleSoundDelay = 2
ENT.ClientIdleSounds = false
ENT.OnDamageSounds = {}
ENT.DamageSoundDelay = 0.25
ENT.OnDeathSounds = {}

ENT.OnDeathSoundsCustom = {"vo/ravenholm/madlaugh01.wav",
"vo/ravenholm/madlaugh02.wav",
"vo/ravenholm/madlaugh03.wav",
"vo/ravenholm/madlaugh04.wav"}
ENT.OnDownedSounds = {}
ENT.Footsteps = {}

-- AI --
ENT.Omniscient = false
ENT.SpotDuration = 3
ENT.RangeAttackRange = 0
ENT.MeleeAttackRange = 40
ENT.ReachEnemyRange = 20
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"GREG"}
ENT.Frightening = false
ENT.AllyDamageTolerance = 0.33
ENT.AfraidDamageTolerance = 0.33
ENT.NeutralDamageTolerance = 0.33

-- Locomotion --
ENT.Acceleration = 1000
ENT.Deceleration = 10000
ENT.JumpHeight = 50
ENT.StepHeight = 20
ENT.MaxYawRate = 250
ENT.DeathDropHeight = 200

-- Animations --
ENT.WalkAnimation = "walk_all_moderate"
ENT.WalkAnimRate = 1
ENT.RunAnimation = "walk_all_moderate"
ENT.RunAnimRate = 2
ENT.IdleAnimation = "LineIdle01"
ENT.IdleAnimRate = 0.1
ENT.JumpAnimation = ACT_JUMP
ENT.JumpAnimRate = 1

-- Movements --
ENT.UseWalkframes = false
ENT.WalkSpeed = 200
ENT.RunSpeed = 400

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbLedgesMaxHeight = math.huge
ENT.ClimbLedgesMinHeight = 0
ENT.LedgeDetectionDistance = 20
ENT.ClimbProps = false
ENT.ClimbLadders = false
ENT.ClimbLaddersUp = true
ENT.LaddersUpDistance = 20
ENT.ClimbLaddersUpMaxHeight = math.huge
ENT.ClimbLaddersUpMinHeight = 0
ENT.ClimbLaddersDown = false
ENT.LaddersDownDistance = 20
ENT.ClimbLaddersDownMaxHeight = math.huge
ENT.ClimbLaddersDownMinHeight = 0
ENT.ClimbSpeed = 60
ENT.ClimbUpAnimation = ACT_CLIMB_UP
ENT.ClimbDownAnimation = ACT_CLIMB_DOWN
ENT.ClimbAnimRate = 1
ENT.ClimbOffset = Vector(0, 0, 0)

-- Detection --
ENT.EyeBone = "ValveBiped.Bip01_Head1"
ENT.EyeOffset = Vector(0, 0, 0)
ENT.EyeAngle = Angle(0, 0, 0)
ENT.SightFOV = 150
ENT.SightRange = 15000
ENT.MinLuminosity = 0
ENT.MaxLuminosity = 1
ENT.HearingCoefficient = 0

-- Weapons --
ENT.UseWeapons = false
ENT.Weapons = {}
ENT.WeaponAccuracy = 1
ENT.WeaponAttachment = "Anim_Attachment_RH"
ENT.DropWeaponOnDeath = false
ENT.AcceptPlayerWeapons = true

-- Possession --
ENT.PossessionEnabled = false
ENT.PossessionPrompt = true
ENT.PossessionCrosshair = false
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {}
ENT.PossessionBinds = {}

if SERVER then

  function ENT:CustomInitialize() end
  function ENT:CustomThink() 
    self:OpenDoor() 
    --self.displacepos = self:RandomPos(200, 3500)
  end

  -- These hooks are called when the nextbot has an enemy (inside the coroutine)
  function ENT:OnMeleeAttack(enemy)

    self:DisplaceEnemy(enemy)

    self:EmitSound("doors/door_metal_large_chamber_close1.wav", 90, math.random(80, 110),1.0)
    --self:Remove()

  end
  function ENT:OnRangeAttack(enemy) end
  function ENT:OnChaseEnemy(enemy) end
  function ENT:OnAvoidEnemy(enemy) end

  function ENT:SRDisplaceEnemy(enemy)
    enemy:EmitSound("doors/door_metal_large_chamber_close1.wav", 75, math.random(80, 110),1.0)
    local displace_mode = math.random(1,2) --1 = on another asteroid, 2 = nearby
    if displace_mode == 1 then 
        if self.sr_asteroid_id == 1 then --novikov
            local rng = math.random(1,2)
            if rng == 1 then
                self:SRDisplace_einstein(enemy)
            end 
    
            if rng == 2 then 
                self:SRDisplace_bodriy(enemy)
            end
        end
    
        if self.sr_asteroid_id == 2 then --einstein
            local rng = math.random(1,2) 
            if rng == 1 then 
                self:SRDisplace_novikov(enemy)
            end
    
            if rng == 2 then 
                self:SRDisplace_bodriy(enemy)
            end
    
        end
    
        if self.sr_asteroid_id == 3 then --bodriy
            local rng = math.random(1,2)
            if rng == 1 then 
                self:SRDisplace_novikov(enemy)
            end
    
            if rng == 2 then
                self:SRDisplace_einstein(enemy)
            end
        end
    end

    if displace_mode == 2 then 
        self:DisplaceEnemy(enemy)
    end

  end

  function ENT:SRDisplace_novikov(enemy)
    local rng_pos = math.random(1,4)
    local spawnvector = Vector(0,0,0)
    if rng_pos == 1 then spawnvector = Vector(-5502.53, 3078.04, -1855.97) end
    if rng_pos == 2 then spawnvector = Vector(-5502.53, 3078.04, -1855.97) end
    if rng_pos == 3 then spawnvector = Vector(-6738.52, 3677.08, -1951.97) end 
    if rng_pos == 4 then spawnvector = Vector(-4324, 83, -1855) end

    enemy:SetPos(spawnvector)

  end

  function ENT:SRDisplace_einstein(enemy)
    local rng_pos = math.random(1,4)
    local spawnvector = Vector(0,0,0)
    if rng_pos == 1 then spawnvector = Vector(-5502.53, 3078.04, -1855.97) end
    if rng_pos == 2 then spawnvector = Vector(-5502.53, 3078.04, -1855.97) end
    if rng_pos == 3 then spawnvector = Vector(-6738.52, 3677.08, -1951.97) end 
    if rng_pos == 4 then spawnvector = Vector(-4324, 83, -1855) end

    enemy:SetPos(spawnvector)
  end

  function ENT:SRDisplace_bodriy(enemy)
    local rng_pos = math.random(1,4)
    local spawnvector = Vector(0,0,0)
    if rng_pos == 1 then spawnvector = Vector(-5502.53, 3078.04, -1855.97) end
    if rng_pos == 2 then spawnvector = Vector(-5502.53, 3078.04, -1855.97) end
    if rng_pos == 3 then spawnvector = Vector(-6738.52, 3677.08, -1951.97) end 
    if rng_pos == 4 then spawnvector = Vector(-4324, 83, -1855) end

    enemy:SetPos(spawnvector)
  end

  function ENT:DisplaceEnemy(enemy)
    local displacepos = self:RandomPos(900, 3500)
    enemy:SetPos(displacepos)
    --print(displacepos)
    enemy:EmitSound("doors/door_metal_large_chamber_close1.wav", 75, math.random(80, 110),1.0)
    self:Remove()
  end

  function ENT:SRShadowClonePos(astr)
    local spawnvector = Vector(0,0,0)
    print(astr)
    if astr == 1 then 
        local altspawn = math.random(1,4)
        if altspawn == 1 then spawnvector = Vector(-7282, 1703, -1855) end
        if altspawn == 2 then spawnvector = Vector(-7766, 1866, -1855) end
        if altspawn == 3 then spawnvector = Vector(-6008, 187, -1823) end
        if altspawn == 4 then spawnvector = Vector(-4229, 350, -1855) end
    end

    if astr == 2 then 
        local altspawn = math.random(1,4)
        if altspawn == 1 then spawnvector = Vector(9378, 10838, -1279) end
        if altspawn == 2 then spawnvector = Vector(7221, 9822, -1279) end
        if altspawn == 3 then spawnvector = Vector(7294, 3125, -831) end
        if altspawn == 4 then spawnvector = Vector(7584, 1398, 8) end
    end

    if astr == 3 then 
        local altspawn = math.random(1,4)
        if altspawn == 1 then spawnvector = Vector(-5854, 12971, -1023) end
        if altspawn == 2 then spawnvector = Vector(-9103, 12445, -1023) end
        if altspawn == 3 then spawnvector = Vector(-8968, 11062, -895) end
        if altspawn == 4 then spawnvector = Vector(-7818, 7951, -1023) end
    end

    self:SetPos(spawnvector)

  end

  function ENT:OpenDoor() 
    for k,v in ipairs(ents.FindInCone(self:GetPos(), self:GetForward(), self.RangeAttackRange +50, math.cos( math.rad( 90 ) ))) do
		if IsValid(v) && IsValid(self) then
			if v:GetClass() == "prop_door_rotating" or v:GetClass() == "func_door" then
				v:Fire("Open")
				end
			end
		end
  end

  -- These hooks are called while the nextbot is patrolling (inside the coroutine)
  function ENT:OnReachedPatrol(pos)
    self:Wait(math.random(3, 7))
  end 
  function ENT:OnPatrolUnreachable(pos) end
  function ENT:OnPatrolling(pos) end

  -- These hooks are called when the current enemy changes (outside the coroutine)
  function ENT:OnNewEnemy(enemy) 
    self:EmitSound("vo/ravenholm/monk_death07.wav",90,math.random(80,150),1.0)
  end
  function ENT:OnEnemyChange(oldEnemy, newEnemy) end
  function ENT:OnLastEnemy(enemy) end

  -- Those hooks are called inside the coroutine
  function ENT:OnSpawn()
    if game.GetMap() == "snukirepairs_sandbox" then 
        self.map_is_on_sr = true 
    end
    self.sr_asteroid_id = math.random(1,3)
    self:SetDefaultRelationship(D_HT)
    self:SetMaterial("debug/env_cubemap_model.vmt")
    self:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)

  end

  function ENT:OnIdle()
    self:AddPatrolPos(self:RandomPos(3500))
  end


  function ENT:OnRemove()
    self:StopSound("vo/ravenholm/monk_death07.wav")
  end
  -- Called outside the coroutine
  function ENT:OnTakeDamage(dmg, hitgroup)
    self:SpotEntity(dmg:GetAttacker())
  end
  function ENT:OnFatalDamage(dmg, hitgroup) end
  
  -- Called inside the coroutine
  function ENT:OnTookDamage(dmg, hitgroup) end
  function ENT:OnDeath(dmg, hitgroup)
    self:StopSound("vo/ravenholm/monk_death07.wav") 
    self:EmitSound(table.Random(self.OnDeathSoundsCustom), 90,math.random(80, 150), 1.0)
  end
  function ENT:OnDowned(dmg, hitgroup) end

else

  function ENT:CustomInitialize() end
  function ENT:CustomThink() 
  end
  function ENT:CustomDraw() end

end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)