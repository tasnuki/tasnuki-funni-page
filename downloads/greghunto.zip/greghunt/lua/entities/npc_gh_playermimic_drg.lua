if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

ENT.ReplacedAnim_run = ACT_HL2MP_RUN
ENT.ReplacedAnim_idle = ACT_HL2MP_IDLE


-- Misc --
ENT.PrintName = "Mimic"
ENT.Category = "greghunt"
ENT.Models = {"models/player/corpse1.mdl"}
ENT.Skins = {0}
ENT.ModelScale = 1
ENT.CollisionBounds = Vector(10, 10, 72)
ENT.BloodColor = BLOOD_COLOR_RED
ENT.RagdollOnDeath = true

-- Stats --
ENT.SpawnHealth = 50
ENT.HealthRegen = 1
ENT.MinPhysDamage = 10
ENT.MinFallDamage = 10

-- Sounds --
ENT.OnSpawnSounds = {}
ENT.OnIdleSounds = {}
ENT.IdleSoundDelay = 2
ENT.ClientIdleSounds = false
ENT.OnDamageSounds = {}
ENT.DamageSoundDelay = 0.25
ENT.OnDeathSounds = {}
ENT.OnDownedSounds = {}
ENT.Footsteps = {}

-- AI --
ENT.Omniscient = false
ENT.SpotDuration = 5
ENT.RangeAttackRange = 0
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"GREG"}
ENT.Frightening = false
ENT.AllyDamageTolerance = 0.33
ENT.AfraidDamageTolerance = 0.33
ENT.NeutralDamageTolerance = 0.33

-- Locomotion --
ENT.Acceleration = 1000
ENT.Deceleration = 1000
ENT.JumpHeight = 50
ENT.StepHeight = 20
ENT.MaxYawRate = 250
ENT.DeathDropHeight = 200

-- Animations --
ENT.WalkAnimation = ACT_HL2MP_RUN_PHYSGUN
ENT.WalkAnimRate = 1
ENT.RunAnimation = ACT_HL2MP_RUN_PHYSGUN
ENT.RunAnimRate = 1
ENT.IdleAnimation = ACT_HL2MP_IDLE_PHYSGUN
ENT.IdleAnimRate = 1
ENT.JumpAnimation = ACT_HL2MP_JUMP_PHYSGUN
ENT.JumpAnimRate = 1

-- Movements --
ENT.UseWalkframes = false
ENT.WalkSpeed = 190
ENT.RunSpeed = 500

-- Climbing --
ENT.ClimbLedges = false
ENT.ClimbLedgesMaxHeight = math.huge
ENT.ClimbLedgesMinHeight = 0
ENT.LedgeDetectionDistance = 20
ENT.ClimbProps = false
ENT.ClimbLadders = false
ENT.ClimbLaddersUp = true
ENT.LaddersUpDistance = 20
ENT.ClimbLaddersUpMaxHeight = math.huge
ENT.ClimbLaddersUpMinHeight = 0
ENT.ClimbLaddersDown = false
ENT.LaddersDownDistance = 20
ENT.ClimbLaddersDownMaxHeight = math.huge
ENT.ClimbLaddersDownMinHeight = 0
ENT.ClimbSpeed = 60
ENT.ClimbUpAnimation = ACT_CLIMB_UP
ENT.ClimbDownAnimation = ACT_CLIMB_DOWN
ENT.ClimbAnimRate = 1
ENT.ClimbOffset = Vector(0, 0, 0)

-- Detection --
ENT.EyeBone = ""
ENT.EyeOffset = Vector(0, 0, 0)
ENT.EyeAngle = Angle(0, 0, 0)
ENT.SightFOV = 150
ENT.SightRange = 15000
ENT.MinLuminosity = 0
ENT.MaxLuminosity = 1
ENT.HearingCoefficient = 1

-- Weapons --
ENT.UseWeapons = true
ENT.Weapons = {"weapon_physgun"}
ENT.WeaponAccuracy = 1
ENT.WeaponAttachment = "Anim_Attachment_RH"
ENT.DropWeaponOnDeath = false
ENT.AcceptPlayerWeapons = false 

-- Possession --
ENT.PossessionEnabled = false
ENT.PossessionPrompt = true
ENT.PossessionCrosshair = false
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {}
ENT.PossessionBinds = {}



--stuff
ENT.NetworkedToPlayer = nil
ENT.MeleeDamage = 10

if SERVER then

  function ENT:CustomInitialize() 
    self.NetworkedToPlayer = table.Random(player.GetAll())
    local nick = self.NetworkedToPlayer:Nick()
    for _,p in ipairs(player.GetAll()) do
        print(p)
        if p:Nick() != nick then
          print('doesnt match ', nick)
          self:SetNoDraw(true)
        end       
    end



  local funnispawning = true
  if funnispawning == true then
    local random_mesh = table.Random(navmesh.GetAllNavAreas())
        local mesh_pos = random_mesh:GetRandomPoint()

        if mesh_pos == nil then
            return
        end

        self:SetPos(mesh_pos)
  end
  end
  function ENT:CustomThink() 
    

  end

  function ENT:OnOtherKilled(victim, dmg)
    local attacker = dmg:GetAttacker()
    if attacker == self then
        self:Health(350)
        self:SetModel(victim:GetModel())
    end
  end

  -- These hooks are called when the nextbot has an enemy (inside the coroutine)
  function ENT:OnMeleeAttack(enemy)
        self:PlaySequenceAndMove("cidle_physgun", 20)
        local dmg = DamageInfo()
        dmg:SetDamage(self.MeleeDamage)
        dmg:SetAttacker(self)
        dmg:SetInflictor(self)
        dmg:SetDamageType(DMG_DISSOLVE)
        enemy:TakeDamageInfo(dmg)
  end
  function ENT:OnRangeAttack(enemy) end
  function ENT:OnChaseEnemy(enemy) end
  function ENT:OnAvoidEnemy(enemy) end

  -- These hooks are called while the nextbot is patrolling (inside the coroutine)
  function ENT:OnReachedPatrol(pos)
    self:Wait(math.random(3, 7))
  end 
  function ENT:OnPatrolUnreachable(pos) end
  function ENT:OnPatrolling(pos) end

  -- These hooks are called when the current enemy changes (outside the coroutine)
  function ENT:OnNewEnemy(enemy) end
  function ENT:OnEnemyChange(oldEnemy, newEnemy) end
  function ENT:OnLastEnemy(enemy) end

  -- Those hooks are called inside the coroutine
  function ENT:OnSpawn() 
    self:SetDefaultRelationship(D_HT)
    local playertable = player.GetAll()
    local player_to_mimic = ''
    player_to_mimic = table.Random(playertable)
    self:SetModel(player_to_mimic:GetModel())
    self.CollisionBounds = Vector(64,64,72)

    local pos = self:RandomPos(100, 1000)
    self:SetPos(pos)


  end
  function ENT:OnIdle()
    self:AddPatrolPos(self:RandomPos(1500))
  end

  -- Called outside the coroutine
  function ENT:OnTakeDamage(dmg, hitgroup)
    self:SpotEntity(dmg:GetAttacker())
    self:AddGesture(ACT_FLINCH)
  end
  function ENT:OnFatalDamage(dmg, hitgroup) end
  
  -- Called inside the coroutine
  function ENT:OnTookDamage(dmg, hitgroup) end
  function ENT:OnDeath(dmg, hitgroup) end
  function ENT:OnDowned(dmg, hitgroup) end

else

  function ENT:CustomInitialize() end
  function ENT:CustomThink() end
  function ENT:CustomDraw() end

end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)