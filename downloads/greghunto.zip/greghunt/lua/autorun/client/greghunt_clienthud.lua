if CLIENT then
    
    --utility functions-------------------------------------------
    function GetGregHealth()
        for _,greggus in ipairs(ents.FindByClass('npc_gh_greg_drg')) do
            if IsValid(greggus) then
                return greggus:Health()
            end
        end
    end

    function GetGregMaxHealth()
        for _,greggus in ipairs(ents.FindByClass('npc_gh_greg_drg')) do
            if IsValid(greggus) then
                return greggus:GetMaxHealth()
            end
        end
    end

    function GetRandomPlayerName()
        local pl = table.Random(player.GetAll())
        return pl:Name()
    end
    -------------------------------------------------------------


    --healthbar vars---------------------------------------------
    local gregtitles = {
        'GATEKEEPER OF '..game.GetMap(),
        'BALD MAN',
        'MESSY CODE DEMON',
        'BALD STAGE NUMBER 7',
        'MONKE'
    }
    local hpbar_gregname = 'GREG'
    local hpbar_gregtitle = table.Random(gregtitles)

    local hpbar_pos_x = ScrW() / 2 - 320
    local hpbar_pos_y = 20
    local hpbar_icon = Material('entities/npc_gh_greg_drg.png')
    local hpbar_background_painted = false
    --------------------------------------------------------------

    hook.Add('HUDPaint', 'greg_hud', function()
        local greghealth = nil
        local greghealthmax = nil
        local pl = LocalPlayer()
        if GetGlobalBool('greg_spawned') == true then
            greghealth = GetGregHealth()
            greghealthmax = GetGregMaxHealth()
        end

        --healthbar-----------------------------------
        if greghealth != nil and greghealth > 0 and pl:GetNWInt('g_hud_hp') > 0 then
            surface.SetDrawColor(Color(0,0,0,190))
            surface.DrawRect(hpbar_pos_x,hpbar_pos_y, greghealthmax * 670 / greghealthmax, 25)
            surface.SetDrawColor(Color(201,19,19,190))
            surface.DrawRect(hpbar_pos_x,hpbar_pos_y, greghealth / greghealthmax * 670, 25)

            --draw icon
            surface.SetMaterial(hpbar_icon)
            --outline
            surface.SetDrawColor(Color(211,2,2, 100))
            surface.DrawOutlinedRect(hpbar_pos_x - 70, hpbar_pos_y, 65,65, 2)
            --icon
            surface.SetDrawColor(Color(255,255,255,255))
            surface.DrawTexturedRect(hpbar_pos_x - 70, hpbar_pos_y, 64,64)

            
            --COOL TEXT ! ! 
            draw.SimpleTextOutlined(hpbar_gregname, 'Trebuchet24', hpbar_pos_x, hpbar_pos_y + 25, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 3, Color(78,9,9))
            draw.SimpleTextOutlined(string.upper(hpbar_gregtitle), 'Trebuchet24', hpbar_pos_x, hpbar_pos_y + 45, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 3, Color(78,9,9))
            if pl:GetNWInt('g_hud_hp') == 1 then
                draw.SimpleTextOutlined('HEALTH', 'Trebuchet24', hpbar_pos_x, hpbar_pos_y, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(78,9,9))
            end

            if pl:GetNWInt('g_hud_hp') == 2 then
                draw.SimpleTextOutlined('HEALTH: '..GetGregHealth(), 'Trebuchet24', hpbar_pos_x, hpbar_pos_y, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(78,9,9))
            end
        end
        ----------------------------------------------
    end)


end