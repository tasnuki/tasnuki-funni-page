include('client/greghunt_clienthud.lua')
--network util
if SERVER then
   util.AddNetworkString('COOLTEXT') 
end

if CLIENT then
    net.Receive('COOLTEXT', function(len,ply)
        local text = net.ReadString()
        local color = net.ReadColor()
        chat.AddText(color,text)
    end)
end
-----------------------------------------

local gregchat_responses_yes = {
    'IM GOING TO GETACHA',
    'PREAPRE YOURSELF',
    'MY POWER WAS LOST IN PALCES WHICH WERE NOT MINE AFFLICTGION BESOUGHT ME AND THE MERCILESS ONES ATTACKED ME WITHOUT CAUSE',
    'MAY THEIR PATHS BECOME DARK AND SLIPPERY AND MAY THE ANGEL OF THE LORD SIHTASS THEM',
    'monkey с:'
}

local gregchat_responses_no = {
    'BITCH',
    'bröb',
    'no :)',
    'okayt.'
}

local help_commands = {
    '===GREG CHAT COMMANDS===',
    '!greghp 0/1 | Disable/Enable healthbar (Client)',
    '!gregspawnhealth number | Set custom health for Greg (Admin)'
}

--init
hook.Add('Initialize', 'greg_init', function()
    SetGlobalBool('greg_spawned', false)
    SetGlobalBool('greg_fog_enabled', false)

    SetGlobalString('greg_askedplayer', nil)

    SetGlobalBool('greg_music_enabled', true)

    if SERVER then
        greg_traps_placed = 0
        greg_traps_max = 16
    end
end)

hook.Add('PlayerInitialSpawn', 'greg_init_spawn_pl', function(pl)
    pl:SetNWInt('g_hud_hp', 1) --show healthbar

end)
-----------------------------------------




--utility
function CText(text,color,sendto)
    net.Start('COOLTEXT')
    net.WriteString(text)
    net.WriteColor(color, false)
    if sendto == 'all' then
        net.Broadcast()
    else
        net.Send(sendto)
    end
end

function GTrapSubtract()
    if SERVER then
        greg_traps_placed = greg_traps_placed - 1
        if greg_traps_placed < 0 then greg_traps_placed = 0 end 
    end
end


function GPlaySound(patx)
    -- local sound
    -- local filter
    -- if SERVER then
    --     filter = RecipientFilter()
    --     filter:AddAllPlayers()
    -- end

    -- if SERVER then
    --     sound = CreateSound(game.GetWorld(), patx, filter)
    --     if sound then
    --         sound:SetSoundLevel(0)
    --     end
    -- end

    -- if sound then
    --     if CLIENT then
    --         sound:Stop()
    --     end
    --     sound:Play()
    -- end
    -- return sound

    local filter

    if SERVER then
        filter = RecipientFilter()
        filter:AddAllPlayers()
    end

    EmitSound(patx, game.GetWorld():GetPos(), -1, CHAN_AUTO, 1.0, 0)

end

-----------------------------------------

--chat commands
hook.Add('PlayerSay', 'greg_chat', function(pl, text)
    if string.StartsWith(text,'!greghp') then
        local args = string.Split(text,' ')
        PrintTable(args)
        tonumber(args[2])
        if args[2] == '1' then
            --enable
            pl:SetNWInt('g_hud_hp', 1)
            CText('Healthbar enabled :)', Color(161,33,33), pl)
            return ''
        end

        if args[2] == '0' then
            --disable
            pl:SetNWInt('g_hud_hp', 0)
            CText('Healthbar disabled...', Color(161,33,33), pl)
            return ''
        end

        if args[2] == '2' then
            --disable
            pl:SetNWInt('g_hud_hp', 2)
            CText('Healthbar enabled, showing numbers as well.', Color(161,33,33), pl)
            return ''
        end
    end

    if text == '!greghelp' then
        for _,command in ipairs(help_commands) do
            CText(command, Color(255,255,255), pl)
        end
        return ''
    end

    if pl:Name() == GetGlobalString('greg_askedplayer') then
        local answer = string.lower(text)
        if answer == 'yes' then
            GregChatReset(pl)
            local responsetime = math.random(2, 4)
            timer.Simple(responsetime, function() 
                CText('Greg: '..table.Random(gregchat_responses_yes), Color(231,244,159), 'all')
                GregKickPlayerAss(pl)
                GregDistantRoar(pl)
            end)
        end

        if answer == 'no' then
            GregChatReset(pl)
            local responsetime = math.random(1,2)
            timer.Simple(responsetime, function()
                CText('Greg: '..table.Random(gregchat_responses_no), Color(231,244,159), 'all')
            end)
        end
    end

    --admin shit
    if pl:IsAdmin() then
        if text == '!gregfog' then
            GregDoFogEvent(15)
            return ''
        end

        if text == '!gregchat' then
            GregChatToPlayer()
        end

        if string.StartsWith(text, '!gregspawnhealth') then
            local args = string.Split(text,' ')
            if args[2] != nil then
                SetGlobalInt('greg_heatlh', tonumber(args[2]))
                CText('Greg health set to '..args[2], Color(161,32,32), pl)
                return ''
            end
        end

        -- if string.StartsWith(text, '!gregmusic') then
        --     local args = string.Split(text, ' ')
        --     if args[2] == '0' then
        --         SetGlobalBool('greg_music_enabled', false)
        --         GregStopAllMusic()
        --         CText('Music disabled :(', Color(161,33,33), pl)
        --         return ''
        --     end

        --     if args[2] == '1' then
        --         SetGlobalBool('greg_music_enabled', true)
        --         CText('Music Enabled :)', Color(161,33,33), pl)
        --         return ''
        --     end
        -- end
    end
end)
--------------------------------------------




--functions---------------------------------
function GregDoFogEvent(lifetime)
    SetGlobalBool('greg_fog_enabled', true)
    GPlaySound('greghunt/npc/greg/event_startfog.wav')
    if SERVER then
        timer.Simple(lifetime, function() GregClearFogEvent() end)
    end
end

function GregClearFogEvent()
    SetGlobalBool('greg_fog_enabled', false )
    GPlaySound('greghunt/npc/greg/event_endfog.wav')
end



function GregChatToPlayer()
   -- if GetGlobalString('greg_askedplayer') != nil then return end
    local speaking_to_player = table.Random(player.GetAll())
    SetGlobalString('greg_askedplayer', speaking_to_player:Name())
    GPlaySound('greghunt/npc/greg/chat_ask.wav')
    local texts = {
        'DO YOU (%s) WANT ME TO KICK YOUR ASS RIGH T NOW??? ASNSWER ME YES OR NO IN CHAT RIGHT NOW TYPE Y OUR SHIT OUT',
        '%s, WANTM E ME TO KICK YOUR ASS SAY YES OR NO',
        'DOCTOR %s SAY YES TO INSTANTLY KILL ME :) (not fake)'
    }

    --CText(string.format(string.format(table.Random(texts),speaking_to_player:Name()), Color(231,244,159), 'all')
    CText(string.format('Greg: '..table.Random(texts), string.upper(speaking_to_player:Name())), Color(231,244,159), 'all')

end

function GregKickPlayerAss(pl)
    for _, greggus in ipairs(ents.FindByClass('npc_gh_greg_drg')) do
        if IsValid(greggus) then
            local pos = pl:GetPos()
            local area = navmesh.GetNearestNavArea(pos,true,600, true, true)
            if area == nil then
                GregKickPlayerAss(pl)
                return
            end

            local area_pos = area:GetRandomPoint()
            greggus:SetPos(area_pos)
            return
        end
    end
end

function GregChatReset(pl)
    SetGlobalString('greg_askedplayer',nil)
end

function GregDistantRoar(pl)
    if pl == nil then
        pl = table.Random(player.GetAll())
    end

    local area = navmesh.GetNearestNavArea(pl:GetPos(), true, math.random(2000, 9000), true, false)
    -- if area != nil then
    --     GregDistantRoar(pl)
    --     return
    -- end

    local pos = area:GetRandomPoint()

    EmitSound('ambient/creatures/town_zombie_call1.wav', pos, -1, CHAN_STATIC, 1.0, 150)
end


---------------------------------------------


hook.Add('SetupWorldFog', 'greg_fog_event', function()
    if GetGlobalBool('greg_fog_enabled') == true then
        render.FogMode(1)
        render.FogColor(255,255,255)
        render.FogStart(200)
        render.FogEnd(500)
        return true 
    end
end)

hook.Add('SetupSkyboxFog', 'greg_skyfog_event', function()
    if GetGlobalBool('greg_fog_enabled') == true then
        render.FogMode(1)
        render.FogColor(255,255,255)
        render.FogStart(0)
        render.FogEnd(2)
        return true 
    end
end)

----------------------------------------------------

-- --music system--------------------------------------
-- local amb_tracks = {
--     "greghunt/music/amb_medsci2.wav"
-- }

-- local combat_tracks = {
--     'greghunt/music/combat_medsci1.wav'
-- }


-- function GregPlayMusic(type)
--     if SERVER then
--         if GetGlobalBool('greg_music_enabled') == false then greg_is_playing_music = false return end
--         local music = nil
--         if type == 'amb' then
--             music = table.Random(amb_tracks)

--         end

--         if type == 'combat' then
--             music = table.Random(combat_tracks)
--         end

--         local filter = RecipientFilter()
--         filter:AddAllPlayers()
--         track = CreateSound(game.GetWorld(), music, filter)
--         track:SetSoundLevel(0)
--         track:SetDSP(0)
--     end

--     if CLIENT then
--         track:Stop()
--     end

--     track:Play()
-- end

-- function GregStopAllMusic()
--     greg_is_playing_music = false
--     track:Stop()
-- end