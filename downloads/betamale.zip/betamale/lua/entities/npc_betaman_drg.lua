if not DrGBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --
ENT.PrintName = "beta male"
ENT.Category = "tasnuki goodfellas"
ENT.Models = {"models/player/betaroyale/citizen_snood.mdl"}
ENT.Skins = {3}
ENT.ModelScale = 1
ENT.CollisionBounds = Vector(10, 10, 72)
ENT.BloodColor = BLOOD_COLOR_RED
ENT.RagdollOnDeath = true

-- Stats --
ENT.SpawnHealth = 2000
ENT.HealthRegen = 0
ENT.MinPhysDamage = 10
ENT.MinFallDamage = 10

-- Sounds --
ENT.OnSpawnSounds = {}
ENT.OnIdleSounds = {}
ENT.IdleSoundDelay = 2
ENT.ClientIdleSounds = false
ENT.OnDamageSounds = {}
ENT.DamageSoundDelay = 0.25
ENT.OnDeathSounds = {}
ENT.OnDownedSounds = {}
ENT.Footsteps = {}

-- AI --
ENT.Omniscient = false
--cvar_spotdur = CreateConVar('betamale_chase_duration', 6, FCVAR_ARCHIVE, 'for how long beta male will chase before he forgets the enemy', 1, 100)
ENT.SpotDuration = 12
ENT.RangeAttackRange = 750
ENT.MeleeAttackRange = 50
ENT.ReachEnemyRange = 50
ENT.AvoidEnemyRange = 0

-- Relationships --
ENT.Factions = {"FACTION_BETAMENS"}
ENT.Frightening = false
ENT.AllyDamageTolerance = 0.33
ENT.AfraidDamageTolerance = 0.33
ENT.NeutralDamageTolerance = 0.33

-- Locomotion --
ENT.Acceleration = 1000
ENT.Deceleration = 1000
ENT.JumpHeight = 50
ENT.StepHeight = 20
ENT.MaxYawRate = 250
ENT.DeathDropHeight = 200

-- Animations --
ENT.WalkAnimation = ACT_HL2MP_WALK
ENT.WalkAnimRate = 1
ENT.RunAnimation = ACT_HL2MP_RUN
ENT.RunAnimRate = 1
ENT.IdleAnimation = ACT_HL2MP_IDLE
ENT.IdleAnimRate = 1
ENT.JumpAnimation = 'jump_fist'
ENT.JumpAnimRate = 1

-- Movements --
ENT.UseWalkframes = false
ENT.WalkSpeed = 100
ENT.RunSpeed = 360

-- Climbing --
ENT.ClimbLedges = true
ENT.ClimbLedgesMaxHeight = 85
ENT.ClimbLedgesMinHeight = 0
ENT.LedgeDetectionDistance = 20
ENT.ClimbProps = false
ENT.ClimbLadders = false
ENT.ClimbLaddersUp = true
ENT.LaddersUpDistance = 20
ENT.ClimbLaddersUpMaxHeight = math.huge
ENT.ClimbLaddersUpMinHeight = 0
ENT.ClimbLaddersDown = false
ENT.LaddersDownDistance = 20
ENT.ClimbLaddersDownMaxHeight = math.huge
ENT.ClimbLaddersDownMinHeight = 0
ENT.ClimbSpeed = 60
ENT.ClimbUpAnimation = 'jump_dual'
ENT.ClimbUpAnimation = 'jump_dual'
ENT.ClimbAnimRate = 1
ENT.ClimbOffset = Vector(0, 0, 0)

-- Detection --
ENT.EyeBone = "ValveBiped.Bip01_Head1"
ENT.EyeOffset = Vector(0, 0, 0)
ENT.EyeAngle = Angle(0, 0, 0)
ENT.SightFOV = 150
ENT.SightRange = 15000
ENT.MinLuminosity = 0
ENT.MaxLuminosity = 1
ENT.HearingCoefficient = 1

-- Weapons --
ENT.UseWeapons = true
ENT.Weapons = {'weapon_crowbar', 'weapon_357', 'weapon_shotgun'}
ENT.WeaponAccuracy = 1
ENT.WeaponAttachment = "Anim_Attachment_RH"
ENT.DropWeaponOnDeath = false
ENT.AcceptPlayerWeapons = false

-- Possession --
ENT.PossessionEnabled = false
ENT.PossessionPrompt = true
ENT.PossessionCrosshair = false
ENT.PossessionMovement = POSSESSION_MOVE_1DIR
ENT.PossessionViews = {}
ENT.PossessionBinds = {}

--------------------------------------------------
//
//TABLES
//
--------------------------------------------------
ENT.FootstepsSFX = {
  'player/footsteps/metal1.wav',
  'player/footsteps/metal2.wav',
  'player/footsteps/metal3.wav',
  'player/footsteps/metal4.wav'
}


ENT.ValidWeapons = {
  'weapon_357',
  'weapon_shotgun'
}

ENT.VO_Kill = {
  'betamale/kill_taunt1.wav',
  'betamale/kill_taunt3.wav',
  'betamale/kill_taunt4.wav',
  'betamale/kill_taunt2.wav'
}

ENT.VO_spot_with_gun = {
  'betamale/spot_when_gun1.wav',
  'betamale/spot_when_gun2.wav',
  'betamale/spot_when_gun3.wav',
  'betamale/spot_when_gun4.wav'
}

ENT.VO_spot = {
  'betamale/spot_generic1.wav',
  'betamale/spot_generic2.wav'
}

ENT.VO_firing_weapon = {
  "betamale/firing1.wav",
  'betamale/firing2.wav',
  'betamale/firing3.wav',
  'betamale/firing4.wav',
  'betamale/firing5.wav'
}

ENT.VO_nospeak = {
  'betamale/listen_false1',
  'betamale/lost_enemies1',
  'betamale/wander2.wav'
}

ENT.VO_listenconfirmed = {
  'betamale/listen_confirmed.wav',
  'betamale/listen_confirmed2.wav'
}

ENT.VO_listening_long = {
  'betamale/listening1.wav',
  'betamale/listening2.wav'
}

ENT.SFX_weapon_switch = {
  'betamale/weapon_switch1.wav',
  'betamale/weapon_switch2.wav'
}


------------------------------------------
//
//SHARED FUNCTIONS
//
------------------------------------------


function ENT:getcorrectanim()
  local weapon = self:GetActiveWeapon():GetClass()
  if weapon == 'weapon_crowbar' then
    --print('crowbar')
    if self.Sneaking == false then
      self.WalkAnimation = ACT_HL2MP_WALK_MELEE
      self.RunAnimation = ACT_HL2MP_RUN_MELEE
      self.IdleAnimation = ACT_HL2MP_IDLE_MELEE
    else
      self.WalkAnimation = ACT_HL2MP_WALK_CROUCH_MELEE
      self.RunAnimation = ACT_HL2MP_RUN_MELEE
      self.IdleAnimation = ACT_HL2MP_IDLE_CROUCH_MELEE
    end
    return
  end

  if weapon == 'weapon_357' then
    --print('357')
    if self.Sneaking == false then
      self.WalkAnimation = ACT_HL2MP_WALK_REVOLVER
      self.RunAnimation = ACT_HL2MP_RUN_REVOLVER
      self.IdleAnimation = ACT_HL2MP_IDLE_PISTOL
    else
      self.WalkAnimation = ACT_HL2MP_WALK_CROUCH_PISTOL
      self.RunAnimation = ACT_HL2MP_RUN_REVOLVER
      self.IdleAnimation = ACT_HL2MP_IDLE_CROUCH_PISTOL
    end
    return
  end

  if weapon == 'weapon_shotgun' then
    --print('shotgun')
    if self.Sneaking == false then
      self.WalkAnimation = ACT_HL2MP_WALK_SHOTGUN
      self.RunAnimation = ACT_HL2MP_RUN_SHOTGUN
      self.IdleAnimation = ACT_HL2MP_IDLE_SHOTGUN
    else
      self.WalkAnimation = ACT_HL2MP_WALK_CROUCH_SHOTGUN
      self.RunAnimation = ACT_HL2MP_RUN_SHOTGUN
      self.IdleAnimation = ACT_HL2MP_IDLE_CROUCH_SHOTGUN
    end
    return
  end

end

function ENT:FootstepInterval()


  if self:GetEnemy() != NULL then
    return 0.2
  end
  if self.Patrolling == true then
    return 0.5
  end



  

end

function ENT:FootstepThink()
  if self.Patrolling == false and self:GetEnemy() == nil then return end --too scared to remove this
  if self:GetVelocity():Length() < 20 then return end --if standing still then just dont do anything
  if self.Sneaking then return end --if sneaking dont do any sound
  local timeleft = self.fstep_next - CurTime()
  if timeleft <= 0 then
   -- print('triggered')
    local footstep = table.Random(self.FootstepsSFX)
    self:EmitSound(footstep, 75, math.random(92, 109), 1.0, CHAN_BODY)
    self.fstep_delay = self:FootstepInterval()
    self.fstep_next = CurTime() + self.fstep_delay
  end
end


function ENT:getcorrectidleanim(weapon)
  if weapon == 'weapon_crowbar' then
    return 'idle_melee'
  end

  if weapon == 'weapon_357' then
    return 'idle_pistol'
  end

  if weapon == 'weapon_shotgun' then
    return 'idle_shotgun'
  end

  return 'idle_all_01'
end






--------------------------------------------------
//
//BIG BOY VARIABLES
//
--------------------------------------------------
--weapons
ENT.Ammo_shotgun = 2
ENT.Ammo_revolver = 2
ENT.Damage_shotgun = 40
ENT.Damage_revolver = 80
ENT.Damage_crowbar = 6


--footsteps
ENT.fstep_delay = 5
ENT.fstep_next = 0


--attacks
ENT.crowbar_swing_cooldown = 0.6
ENT.crowbar_swing_timer = 0
ENT.crowbar_can_attack = false
ENT.revolver_refire = 0.7
ENT.revolver_timer = 0
ENT.revolver_can_fire = false
ENT.revolver_shots = nil
ENT.revolver_first_shot = true
ENT.shotgun_refire = 2.0
ENT.shotgun_can_fire = false
ENT.shotgun_shots = nil
ENT.shotgun_first_shot = true

ENT.can_do_range_attacks = true
ENT.can_switch_weapons = true
ENT.range_attacks_cooldown = 5

ENT.can_shove = true
ENT.shove_cooldown = 1

--states
ENT.Patrolling = false
ENT.Sneaking = false 
ENT.Speaking = false

ENT.flashlight_state = true



--combat strats
ENT.can_shoot = true
ENT.patrol_try_action_cooldown = 16
ENT.patrol_can_try_action = false



--hearing
cvar_hearing_close = CreateConVar('betamale_hearing_close', 250, FCVAR_ARCHIVE, "beta males close hearing range, this check is rolled almost constantly so keep the range lower", 0, 1000)
cvar_hearing_long = CreateConVar('betamale_hearing_long', 1500, FCVAR_ARCHIVE, "beta male's long hearing range, this only activates when he's in listening state", 0, 5000)
cvar_hearing_long_duration = CreateConVar('betamale_hearing_long_duration', 5, FCVAR_ARCHIVE, "for how long beta male should listen when he's in a listening state", 0, 10)

ENT.close_hearing_range = cvar_hearing_close:GetInt()
ENT.long_hearing_range = cvar_hearing_long:GetInt()
ENT.LongListening = false
--long hearing timers
ENT.hearing_delay = 1.0
ENT.hearing_next = 0
--close hearing tiemrs
ENT.chearing_delay = 0.6
ENT.chearing_next = 0
ENT.chearing_curious_spot = nil


--world interaction
ENT.door_open_delay = 1.3
ENT.door_open_next = 0

if SERVER then

  --------------------------------------------------
  //
  //WEAPON RELATED FUNCTIONS
  //
  --------------------------------------------------

  function ENT:SwitchToWeapon(weapon)
    if self:GetActiveWeapon():GetClass() == weapon then return end
    self:AddGestureSequence(self:LookupSequence('flinch_01'))
    self:SelectWeapon(weapon)
    self:EmitSound(table.Random(self.SFX_weapon_switch), 75, 105, 1.0, CHAN_STATIC)

    print('switched weapon to ', weapon)
  end

  function ENT:CheckWeaponAmmo(weapon)
    if weapon == 'weapon_crowbar' then return end -- dont check crowbar

    if weapon == 'weapon_357' then
      print('checking ammo of my 357...')
      if self.Ammo_revolver <= 0 then
        print('my revolver is empty!')
        self:ReloadWeapon('weapon_357')
        return false
      else
        return true
      end
    end


    if weapon == 'weapon_shotgun' then
      print('checking ammo of my shotgun...')
      if self.Ammo_shotgun <= 0 then
        print('my shotgun is empty!!')
        self:ReloadWeapon('weapon_shotgun')
        return false
      else
        return true
      end
    end


  end

  function ENT:ReloadWeapon(weapon)
    if weapon == 'weapon_crowbar' then return end -- dont reload crowbar lol

    local old_weapon = self:GetActiveWeapon():GetClass()
    --switch to weapon in question if its not already deployed
    if self:GetActiveWeapon():GetClass() != weapon then
      self:SwitchToWeapon(weapon)
    end


    if weapon == 'weapon_357' then
      --start reload
      self:AddGestureSequence(self:LookupSequence('reload_revolver'))
      self:getcorrectanim()
      self:EmitSound('weapons/357/357_reload1.wav', 75, 100, 1.0, CHAN_WEAPON)
      self:PlaySequenceAndWait('idle_revolver', 0.4)
      --finish reload
      self:getcorrectanim()
      self.Ammo_revolver = 6
      print('revolver reloaded')


      --if im not angry then switch to my previous gun
      if self:GetEnemy() == NULL then
        print('no enemies, switched to my previous gun')
        if self:GetActiveWeapon():GetClass() != old_weapon then
          self:SwitchToWeapon(old_weapon)
        end
      end


      return
    end


    if weapon == 'weapon_shotgun' then
      --start reload
      self:AddGestureSequence(self:LookupSequence('reload_shotgun'))
      self:getcorrectanim()
      self:EmitSound('weapons/shotgun/shotgun_reload1.wav', 75, 100, 1.0, CHAN_WEAPON)
      self:PlaySequenceAndWait('idle_shotgun', 0.4)
      --finish reload
      self:getcorrectanim()
      self.Ammo_shotgun = 6
      print('shotgun reloaded')



      --if im not angry then switch to my previous gun
      if self:GetEnemy() == NULL then
        print('no enemies, switched to my previous gun')
        if self:GetActiveWeapon():GetClass() != old_weapon then
          self:SwitchToWeapon(old_weapon)
        end
      end

      return
    end
  end


  function ENT:WanderReloadGun()
    local weapon_to_reload = table.Random(self.ValidWeapons)

    if weapon_to_reload == 'weapon_357' then
      if self.Ammo_revolver < 4 then
        self:ReloadWeapon('weapon_357')
        return
      end
    end

    if weapon_to_reload == 'weapon_shotgun' then
      if self.Ammo_shotgun < 6 then
        self:ReloadWeapon('weapon_shotgun')
        return
      end
    end
  end


  function ENT:Cooldown_crowbar()
    local timeleft = self.crowbar_swing_timer - CurTime()
    print(timeleft)
    if timeleft < 0 then
      print('done')
      self.crowbar_swing_timer = CurTime() + self.crowbar_swing_cooldown
      self.crowbar_can_attack = true
    end
  end

  function ENT:Cooldown_revolver()
    local timeleft = self.revolver_timer - CurTime()
    if timeleft < 0 then
      self.revolver_timer = CurTime() + self.revolver_refire
      self.revolver_can_fire = true
    end
  end


  function ENT:StartRangeAttack(weapon, enemy)
    if weapon == 'weapon_357' then
      self:Attack_357(enemy)
      return
    end

    if weapon == 'weapon_shotgun' then
      self:Attack_shotgun(enemy)
      return
    end
  end





  function ENT:Attack_357(enemy)
    --switch to 357 if it's not in hands
    if self:GetActiveWeapon():GetClass() != 'weapon_357' then
      self:SwitchToWeapon('weapon_357')
    end

    --how many shots do i wanna fire
    if self.revolver_shots == nil then
      self.revolver_shots = math.random(1,6)
    end


    --if it's my first shot then aim a little to create a little delay
    if self.revolver_first_shot then
      self:PlaySequenceAndWait('idle_pistol', 2, self.FaceEnemy)
      self.revolver_first_shot = false
    end

    --see if it's even loaded
    if self:CheckWeaponAmmo('weapon_357') == false then return end

   -- local how_many_shots = math.random(1,6)
 --   print(how_many_shots)
   -- local x,y,z = enemy:GetPos():Unpack()

    --fire prep
    local bullet = {}
    bullet.Attacker = self
    bullet.Inflictor = self:GetWeapon()
    bullet.Damage = self.Damage_revolver
    bullet.Force = 30
    bullet.Num = 1
    bullet.Tracer = 1
    bullet.Src = self:GetShootPos()
    bullet.Dir = self:GetForward() + Vector(0,0, math.random(0.01, 0.08))
    bullet.IgnoreEntity = self


    --if gun can fire then shoot
    if self.revolver_can_fire == true then
        self:FireBullets(bullet)
        --self:GetActiveWeapon():ShootBullet(self.Damage_revolver, 1, 0, self:GetActiveWeapon():GetPrimaryAmmoType(), 100, 1)
        self:AddGestureSequence(self:LookupSequence('range_revolver'))
        self:EmitSound('weapons/357/357_fire2.wav', 105, 100, 1.0, CHAN_WEAPON)
        self.Ammo_revolver = self.Ammo_revolver - 1
        self.revolver_can_fire = false
        self.revolver_shots = self.revolver_shots - 1

        --chance to say something
        local chance = math.random(1,3)
        if chance == 3 then
          self:Speak(table.Random(self.VO_firing_weapon))
        end


    end


    --i finished firing all my shots
    if self.revolver_shots <= 0 then
      self.can_do_range_attacks = false
      self.revolver_shots = nil
      self.revolver_first_shot = true
    end
  end




  function ENT:Attack_shotgun(enemy)
    --switch to shotgun if it's not in hands
    if self:GetActiveWeapon():GetClass() != 'weapon_shotgun' then
      self:SwitchToWeapon('weapon_shotgun')
    end

    --see if it's even loaded
    if self:CheckWeaponAmmo('weapon_shotgun') == false then return end


    --decide how many shots im gonna fire if im still undecided
    if self.shotgun_shots == nil then
      self.shotgun_shots = math.random(1, 6)
    end

    --stand still and aim a little
    self:PlaySequenceAndWait('idle_shotgun', 3, self.FaceEnemy)

    --fire prep
    local bullet = {}
    bullet.Attacker = self
    bullet.Inflictor = self:GetWeapon()
    bullet.Damage = self.Damage_shotgun
    bullet.Force = 100
    bullet.Num = 6
    bullet.Spread = Vector(math.random(0.1,1), math.random(0.1,1), 0)
    bullet.Tracer = 1
    bullet.Src = self:GetShootPos()
    bullet.Dir = self:GetForward()
    bullet.IgnoreEntity = self

    --fire my gun
    if self.shotgun_can_fire then
      self:FireBullets(bullet)
      self:EmitSound('weapons/shotgun/shotgun_fire6.wav', 105, 100, 1.0, CHAN_WEAPON)
      self:AddGestureSequence(self:LookupSequence('range_shotgun'))
      self.shotgun_can_fire = false
      self.Ammo_shotgun = self.Ammo_shotgun - 1
      self.shotgun_shots = self.shotgun_shots - 1
      --timer.Simple(self.shotgun_refire, function() self:EmitSound('weapons/shotgun/shotgun_cock.wav', 75, 90, 0.7, CHAN_WEAPON) end)


      --chance to say something
        local chance = math.random(1,3)
        if chance == 3 then
          self:Speak(table.Random(self.VO_firing_weapon))
        end
    end

    --i finished firing all my shots :)
    if self.shotgun_shots <= 0 then
      self.can_do_range_attacks = false
      self.shotgun_shots = nil
    end


  end



  ---------------------------------------------------
  function ENT:CustomInitialize() 
    self:SetDefaultRelationship(D_HT)
    self:getcorrectanim()


    --create flashlight
    local flashlight = ents.Create('env_projectedtexture')
    local flashlight_pos = self:GetPos()
    flashlight:Spawn()
    flashlight:SetPos(flashlight_pos)
    flashlight:SetAngles(self:GetAngles())
    flashlight:SetName('flashlight_betaman'..self:EntIndex())
    flashlight:SetParent(self, self:LookupBone('ValveBiped.Bip01_Spine'))
    flashlight:SetPos(self:GetPos() + self:GetForward() * 2 + self:GetUp() * 72)
    flashlight:Fire('FOV', '50')
    flashlight:Fire('EnableShadows', true)
    flashlight:Fire('TurnOn')
    flashlight:Fire('EnableShadows', '1')


    self.loco:SetMaxYawRate(320)


    --self:LongListenStart()

  end
  function ENT:CustomThink() 
    --small functions------------------
    if self.Patrolling == true or self:GetEnemy() != NULL then self:FootstepThink() end
    if self:GetEnemy() != NULL then self.Patrolling = false end


    if self.crowbar_can_attack == false then self:Cooldown_crowbar() end


    --this is fucking hell dont do this kids

    if self.revolver_can_fire == false then
      if timer.Exists('betaman_'..self:EntIndex()..'_revolver') == false then
        timer.Create('betaman_'..self:EntIndex()..'_revolver', self.revolver_refire, 1, function() 
          if not self:IsValid() then return end
          self.revolver_can_fire = true
        end)
      end
    end


    if self.can_do_range_attacks == false then
      if timer.Exists('betaman_'..self:EntIndex()..'_range') == false then
        timer.Create('betaman_'..self:EntIndex()..'_range', self.range_attacks_cooldown, 1, function() 
          if not self:IsValid() then return end
          self.can_do_range_attacks = true
        end)
      end
    end


    if self.shotgun_can_fire == false then
      if timer.Exists('betaman_'..self:EntIndex()..'_shotgun') == false then
        timer.Create('betaman_'..self:EntIndex()..'_shotgun', self.shotgun_refire, 1, function() 
          if not self:IsValid() then return end
          self.shotgun_can_fire = true
        end)
      end
    end


    if self.patrol_can_try_action == false then
      if timer.Exists('betaman_'..self:EntIndex()..'_actiontry') == false then
        timer.Create('betaman_'..self:EntIndex()..'_actiontry', self.patrol_try_action_cooldown, 1, function() 
          if not self:IsValid() then return end
          self.patrol_can_try_action = true
        end)
      end
    end


    if self.can_shove == false then
      if timer.Exists('betaman_'..self:EntIndex()..'_shove') == false then
        timer.Create('betaman_'..self:EntIndex()..'_shove', self.shove_cooldown, 1, function() 
          if not self:IsValid() then return end
          self.can_shove = true
        end)
      end
    end


    -----------------------------------


    self:getcorrectanim()
   -- print(self:GetActiveWeapon())
   -- print(self:LookupSequence(self.WalkAnimation))
    
   -- self:DestroyShit()

   ---state functions-------------------------------
    self:LongListenThink()
    self:CloseListenThink()
    self:DoorOpenThink()
    -- if debugge then
    --   self:LongListenStart()
    -- end


   -------------------------------------------------
  end

  function ENT:DoorOpenThink()
    -- for _,ent in ipairs(ents.FindInCone(self:GetPos(), self:GetBonePosition(6), self.MeleeAttackRange + 50, math.cos(math.rad(90)))) do
    --   if ent:GetClass() == 'prop_door_rotating' or ent:GetClass() == 'func_door' then
    --     ent:Fire('Open')
    --   end
    -- end

    for _,ent in ipairs(ents.FindInSphere(self:GetPos(), 50)) do
        if ent:GetClass() == 'prop_door_rotating' or ent:GetClass() == 'func_door' then
          ent:Fire('Open')
      end
    end
  end

  function ENT:Speak(line)
    if self.Speaking then return end

    self:EmitSound(line, 90, 100, 1.0, CHAN_VOICE)
    self.Speaking = true
    timer.Simple(SoundDuration(line), function() self.Speaking = false end)
  end

  function ENT:FlashlightToggle(force)
    if force == nil then force = 'toggle' end

    if force == 'toggle' then

      --turn it off
      if self.flashlight_state == true then
        for _,f in ipairs(ents.FindByName('flashlight_betaman'..self:EntIndex())) do
          if IsValid(f) then
            f:Fire('TurnOff')
            self.flashlight_state = false
            self:EmitSound('items/flashlight1.wav', 75, 100, 1.0, CHAN_STATIC)
            return
          end
        end
      end


      --turn it on
      if self.flashlight_state == false then
        for _,f in ipairs(ents.FindByName('flashlight_betaman'..self:EntIndex())) do
          if IsValid(f) then
            f:Fire('TurnOn')
            self.flashlight_state = true
            self:EmitSound('items/flashlight1.wav', 75, 100, 1.0, CHAN_STATIC)
            return
          end
        end
      end
    end


    if force == 'on' then
        for _,f in ipairs(ents.FindByName('flashlight_betaman'..self:EntIndex())) do
          if IsValid(f) then
            f:Fire('TurnOn')
            self.flashlight_state = true
            self:EmitSound('items/flashlight1.wav', 75, 100, 1.0, CHAN_STATIC)
            return
          end
        end
    end

    if force == 'off' then
      for _,f in ipairs(ents.FindByName('flashlight_betaman'..self:EntIndex())) do
          if IsValid(f) then
            f:Fire('TurnOff')
            self.flashlight_state = false
            self:EmitSound('items/flashlight1.wav', 75, 100, 1.0, CHAN_STATIC)
            return
          end
        end
    end


  end


  function ENT:OnContact(ent)
    if self.can_shove == false then return end
    if ent:GetClass() == 'prop_physics' then
      print('done')
      local phys = ent:GetPhysicsObject()
      phys:Wake()
      phys:SetVelocity(self:GetForward() * 600)
      local material = phys:GetMaterial()
      if self:IsPlayingGesture(self:LookupSequence('range_melee_shove_1hand')) == false then
          self:AddGestureSequence(self:LookupSequence('range_melee_shove_1hand'))
      end

      self:EmitSound('weapons/iceaxe/iceaxe_swing1.wav', 75, 90, 0.7, CHAN_AUTO)
      self:EmitSound('physics/metal/weapon_impact_hard'..math.random(1,3)..'.wav', 75, 100, 1.0,  CHAN_ITEM)

      if material == 'wood' then
        ent:EmitSound('physics/wood/wood_box_impact_hard'..math.random(1,4)..'.wav', 80, 100, 1.0, CHAN_STATIC)
      end

      if material == 'metal' then
        ent:EmitSound('physics/metal/metal_barrel_impact_hard'..math.random(1,8)..'.wav', 80, 100, 1.0, CHAN_STATIC)
      end

      self.can_shove = false
    end


    --special exception if it's a door
    -- if ent:GetClass() == 'prop_door_rotating' or ent:GetClass() == 'func_door' then
    --   ent:Fire('Open')
    -- end
  end


  -- These hooks are called when the nextbot has an enemy (inside the coroutine)
  function ENT:OnMeleeAttack(enemy) 
    if self.crowbar_can_attack == false then return end

    if self:GetActiveWeapon():GetClass() != 'weapon_crowbar' then
      self:SwitchToWeapon('weapon_crowbar')
    end


    --do attack
    self.crowbar_can_attack = false
    local trace = util.TraceLine({
      start = self:GetPos() + Vector(0,0,32),
      endpos = enemy:GetPos() + Vector(0,0,32),
      filter = self
    })

    if trace.Entity == enemy then
      print('hit !!')
      local dmg = DamageInfo()
      dmg:SetAttacker(self)
      dmg:SetInflictor(self:GetActiveWeapon())
      dmg:SetDamage(self.Damage_crowbar)
      dmg:SetDamageType(DMG_CLUB)
      enemy:TakeDamageInfo(dmg)
      enemy:EmitSound('physics/flesh/flesh_impact_bullet'..math.random(1,5)..'.wav', 75, 100, 0.6, CHAN_STATIC)
      self:EmitSound('physics/metal/metal_box_impact_hard'..math.random(1,3)..'.wav', 75, math.random(98, 105), 0.5, CHAN_STATIC)
    else
      print('miss!')
    end
    --flair
    self:EmitSound('weapons/iceaxe/iceaxe_swing1.wav', 75, math.random(94, 106), 1.0, CHAN_WEAPON)
    self:AddGestureSequence(self:LookupSequence('range_melee'))

  end
  function ENT:OnRangeAttack(enemy) 
    if self.can_do_range_attacks == true then
        local gun = table.Random(self.ValidWeapons)
        self:StartRangeAttack(gun, enemy)
    else
      self:SwitchToWeapon('weapon_crowbar')
    end


  end
  function ENT:OnChaseEnemy(enemy) end
  function ENT:OnAvoidEnemy(enemy) end


  function ENT:OnOtherKilled(victim, info)
    local attacker = info:GetAttacker()


    --taunt the enemy
    if attacker == self then
      local chance = math.random(0,3)
      if chance == 3 then
        self:Speak(table.Random(self.VO_Kill))
      end
    end
  end

  --------------------------------------------
  //
  //WANDER RELATED FUNCTIONS
  //
  ---------------------------------------------



  --rolls when patrol is REACHED
  function ENT:PatrolReachAction()
    local action_id = math.random(1,1)

    --reload a random gun
    if action_id == 1 then
      self:WanderReloadGun()
      return
    end
  end

  --triggers when RollPatrollingAction hits
  function ENT:WhilePatrollingAction()
    local action_id = math.random(1,2)
    
    --reload my current gun
    if action_id == 1 then
      self:CheckWeaponAmmo(self:GetActiveWeapon():GetClass())
      return
    end


    --start sneaking just for a bit
    if action_id == 2 then
      self.Sneaking = true
      self:FlashlightToggle('off')
      timer.Simple(14, function() self.Sneaking = false self:FlashlightToggle('on') end)
    end

    --try to hear enemies
    if action_id == 3 then
      self:LongListenStart()
      return
    end
  end


  --try to roll a chance for an action while on the go
  function ENT:RollPatrollingAction()
    if self.patrol_can_try_action == false then return end
    local chance = math.random(1, 10)
    local fire = 10

    print(chance)

    if chance == fire then
      self:WhilePatrollingAction()
    end
    self.patrol_can_try_action = false
  end



  ---------------------------------------------

  ------------------------------------------
  //
  //LISTENING STUFF
  //
  ------------------------------------------

  --start listening
  function ENT:LongListenStart()
    local duration = cvar_hearing_long_duration:GetInt()
  
    self.LongListening = true
    --stand still for a bit
    self:AddPatrolPos(self:RandomPos(50))
    --self:PlaySequenceAndMove(self:getcorrectidleanim(self:GetActiveWeapon():GetClass()), 0.3)
    
    --stop long listen
    timer.Simple(duration, function() self.LongListening = false end)

    print('long listen started')

  end


  --hearing timer, each ping try to see if someones talking
  function ENT:LongListenThink()
    if self.LongListening == false then return end
    local timeleft = self.hearing_next - CurTime()
    if timeleft <= 0 then
      self:LongListenPing()
      self.hearing_next = CurTime() + self.hearing_delay
    end
  end

  --the ping itself
  function ENT:LongListenPing()
    print('long listen ping')
    for _,ent in ipairs(ents.FindInSphere(self:GetPos(), self.long_hearing_range)) do
      if IsValid(ent) and ent:IsPlayer() and ent:Alive() and ent:IsSpeaking() then
        self:LongListenHeard()
        return
      end
    end
  end

  --if i heard someone give them grace period to shut up
  function ENT:LongListenHeard()
    local graceline = table.Random(self.VO_listening_long)

    local grace = SoundDuration(graceline)
    grace = grace + 1
    grace = math.Round(grace)
    print(grace)
    self:Speak(graceline)

    --stop long listening
    self.LongListening = false

    --stand still for a bit
    self:AddPatrolPos(self:RandomPos(50))
    --self:PlaySequenceAndWait(self:getcorrectidleanim(self:GetActiveWeapon():GetClass()), 0.3)

    --do one last ping to confirm
    timer.Simple(grace, function() self:LongListenConfirm() end)

  end

  --check again if they're still speaking
  function ENT:LongListenConfirm()
    print('long listen final ping')
    for _,ent in ipairs(ents.FindInSphere(self:GetPos(), self.long_hearing_range)) do
      if IsValid(ent) and ent:IsPlayer() and ent:Alive() and ent:IsSpeaking() then
        --okay you kept speaking get fucked
        self:Speak(table.Random(self.VO_listenconfirmed))
        self:SpotEntity(ent)
        return
      end
    end
    self:LongListenNoSpeak()
  end


  --after final check if no one spoke
  function ENT:LongListenNoSpeak()

    --if no one is talking then all good, start patrolling
    self:AddPatrolPos(self:RandomPos(math.random(1500,4500)))
    self:Speak(table.Random(self.VO_nospeak))
  end


  --this is super close range hearing, like really really close to him
  function ENT:CloseListenThink()
    local timeleft = self.chearing_next - CurTime()
    if timeleft < 0 then
      self:CloseListenPing()
      self.chearing_next = CurTime() + self.chearing_delay
    end
  end

  --close range hearing ping
  function ENT:CloseListenPing()
    for _,ent in ipairs(ents.FindInSphere(self:GetPos(), self.close_hearing_range)) do
      if IsValid(ent) and ent:IsPlayer() and ent:Alive() and ent:IsSpeaking() then
        self:CloseListenHeard(ent)
        return
      end
    end
  end

  --close range heard player, investigate the source of that noise
  function ENT:CloseListenHeard(ent)
    print('close listen heard')
    local delete = 9
    --create a curious spot for me to check
    self.chearing_curious_spot = ent:GetPos()
    

    --dont patrol a nil pos
    if self.chearing_curious_spot == nil then return end

    --go see who made that noise
    self:AddPatrolPos(self.chearing_curious_spot)


    --delete the spot after a few seconds
    timer.Simple(delete, function() self.chearing_curious_spot = nil end)

  end



  -- These hooks are called while the nextbot is patrolling (inside the coroutine)
  function ENT:OnReachedPatrol(pos)
    self.Patrolling = false
    self:PatrolReachAction()
    self:Wait(math.random(2, 4))
  end 
  function ENT:OnPatrolUnreachable(pos) end
  function ENT:OnPatrolling(pos) 
    self.Patrolling = true
    self:RollPatrollingAction()
  end

  -- These hooks are called when the current enemy changes (outside the coroutine)
  function ENT:OnNewEnemy(enemy) 
    self.Listening = false

    --do funny speech
    --if with gun do unique speech
    if self:GetActiveWeapon():GetClass() != 'weapon_crowbar' then
      self:Speak(table.Random(self.VO_spot_with_gun))
    else
      self:Speak(table.Random(self.VO_spot))
    end


    --if i was long listening then stop
    self.LongListen = false


  end
  function ENT:OnEnemyChange(oldEnemy, newEnemy) end
  function ENT:OnLastEnemy(enemy) end

  -- Those hooks are called inside the coroutine
  function ENT:OnSpawn() end
  function ENT:OnIdle()
    self:AddPatrolPos(self:RandomPos(math.random(1500, 4000)))
  end

  -- Called outside the coroutine
  function ENT:OnTakeDamage(dmg, hitgroup)
    self:SpotEntity(dmg:GetAttacker())
  end
  function ENT:OnFatalDamage(dmg, hitgroup) end
  
  -- Called inside the coroutine
  function ENT:OnTookDamage(dmg, hitgroup) end
  function ENT:OnDeath(dmg, hitgroup) end
  function ENT:OnDowned(dmg, hitgroup) end

else

  function ENT:CustomInitialize()
  end
  function ENT:CustomThink() 
  end
  function ENT:CustomDraw() end

end

-- DO NOT TOUCH --
AddCSLuaFile()
DrGBase.AddNextbot(ENT)