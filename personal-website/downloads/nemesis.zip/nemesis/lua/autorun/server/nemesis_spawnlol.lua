local time_min_cvar = CreateConVar('nemesis_spawn_min', 60, FCVAR_ARCHIVE, 'minimal value for timer', 1, 1000)
local time_max_cvar = CreateConVar('nemesis_spawn_max', 400, FCVAR_ARCHIVE, 'max value for timer', 2, 1000)

local class_to_spawn = CreateConVar('nemesis_class', 'npc_monk', FCVAR_ARCHIVE, 'npc to spawn')
local spawn_type = CreateConVar('nemesis_spawntype', 1, FCVAR_ARCHIVE, '0 - anywhere, 1 - close to host', 0, 1)
local weapon_to_give = CreateConVar('nemesis_weapon', 'NULL', FCVAR_ARCHIVE, 'what weapon to give; type NULL if you wish to NOT give weapons')
local health_to_give = CreateConVar('nemesis_health', '-1', FCVAR_ARCHIVE, 'how much health should nemesis have; type -1 if you wish to not modify heatlh', 1, 10000)
local force_hate = CreateConVar('nemesis_force_hate', 1, FCVAR_ARCHIVE, 'should the spawned nemesis be hostile towards everyone?', 0, 1)
local times_to_spawn = CreateConVar('nemesis_max_spawns', 1, FCVAR_ARCHIVE, 'how many times should the nemesis spawn', 1, 1000)

local enable_on_start = CreateConVar('nemesis_start_on_spawn', 0, FCVAR_ARCHIVE, 'should the system start immediately on spawn?', 0, 1)

local function NemesisStart()
    local min = time_min_cvar:GetInt()
    local max = time_max_cvar:GetInt()
    local reps = times_to_spawn:GetInt()
    timer.Create('nemesis_spawn_timer', math.random(min,max), reps, function() 
        NemesisSpawn()
    end)
end


function NemesisSpawn()
    local close = spawn_type:GetBool()
    local class = class_to_spawn:GetString()
    local ent = ents.Create(class)
    local pos = nil

    --spawn type ANYWHERE
    if close == false then
        --find a area to spawn in
        local navarea = table.Random(navmesh.GetAllNavAreas())

        --if underwater then fuck you
        if navarea:IsUnderwater() == true then
            NemesisSpawn()
            return
        end

        pos = navarea:GetRandomPoint()
    end

    --spawn type CLOSE
    if close == true then
        local navarea = navmesh.GetNearestNavArea(Entity(1):GetPos(), true, 10000, true, true)

        pos = navarea:GetRandomPoint()
    end





    --if no pos then fuck you
    if pos == nil then NemesisSpawn() return end
    --spawn the gremlin

    ent:Spawn()
    ent:SetPos(pos)
    ent:SetName('nemesis')
    PrintMessage(HUD_PRINTTALK, class..' has invaded..........')

    --give weapon if it's not null
    local weaponclass = weapon_to_give:GetString()
    if weaponclass != 'NULL' then
        ent:Give(weaponclass)
    end

    --apply health
    local health = health_to_give:GetInt()
    if health != -1 then
        ent:SetHealth(health)
    end


    --apply angry mode if it's enabled
    local should_be_angry = force_hate:GetBool()
    if should_be_angry then
        ent:AddRelationship('npc_* D_HT 100')
        ent:AddRelationship('player D_HT 100')
    end

    --do funni if greg
    if class == 'npc_monk' then
        ent:EmitSound('vo/ravenholm/monk_death07.wav', 80, 100, 1.0, CHAN_VOICE)
    end
end

local function NemesisDisable()
    --remove nemesis if it's spawned
    local class = class_to_spawn:GetString()
    for _,ent in ipairs(ents.FindByName('nemesis')) do
        if IsValid(ent) then ent:Remove() print ('nemesis removed!') end
    end

    --remove the timer
    timer.Remove('nemesis_spawn_timer')
    print('nemesis timer removed!')
end





--hooks
hook.Add('PlayerInitialSpawn', 'nemesis_spawn', function()
    local should_start = enable_on_start:GetBool()
    if should_start then
        NemesisStart()
    end
end)


--concommands
concommand.Add('nemesis_start', function()
    NemesisStart()
    print('nemesis timers started...')
end)

concommand.Add('nemesis_stop', function() 
    NemesisDisable()
end)

concommand.Add('nemesis_force_spawn_now', function()
	NemesisSpawn()
    print('nemesis force spawned...')
end)