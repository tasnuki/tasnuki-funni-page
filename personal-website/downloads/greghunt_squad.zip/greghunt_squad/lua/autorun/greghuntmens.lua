player_manager.AddValidModel("greghunt_player1", "models/greghunt/player_1.mdl")
player_manager.AddValidModel("greghunt_player2", "models/greghunt/player_2.mdl")
player_manager.AddValidModel("greghunt_player3", "models/greghunt/player_3.mdl")
player_manager.AddValidModel("greghunt_player4", "models/greghunt/player_4.mdl")

player_manager.AddValidHands("greghunt_player1", "models/weapons/c_arms_greghunt_player1.mdl", 0,100000, false )
player_manager.AddValidHands("greghunt_player2", "models/weapons/c_arms_greghunt_player2.mdl", 0,100000, false )
player_manager.AddValidHands("greghunt_player3", "models/weapons/c_arms_greghunt_player3.mdl", 0,100000, false )
player_manager.AddValidHands("greghunt_player4", "models/weapons/c_arms_greghunt_player4.mdl", 0,100000, false )